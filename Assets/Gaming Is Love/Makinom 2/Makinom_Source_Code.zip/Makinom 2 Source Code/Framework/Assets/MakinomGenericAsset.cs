﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public static class MakinomGenericAssetCache
	{
		private static List<IMakinomGenericAsset> cache = new List<IMakinomGenericAsset>();

		public static void Cache(IMakinomGenericAsset asset)
		{
			cache.Add(asset);
		}

		public static void Clear()
		{
			for(int i = 0; i < cache.Count; i++)
			{
				if(cache[i] != null)
				{
					cache[i].ClearData();
				}
			}
			cache.Clear();
		}
	}

	public interface IMakinomGenericAsset : ISubData
	{
		int Index
		{
			get;
			set;
		}

		bool SortAtEnd
		{
			get;
			set;
		}

		string DataName
		{
			get;
		}

		BaseIndexData EditorSettings
		{
			get;
		}

		string GetEditorPopupName(bool addType);

		void SetData(DataObject data);

		void LoadData();

		void ClearData();

		void SaveData(DataFile saveFile, bool encrypt, DataFile.SaveFormatType format);

		bool MarkedForSaving
		{
			get;
			set;
		}

		bool HasChanged(bool encrypt, DataFile.SaveFormatType format, out DataFile file);

		void ReplaceTextCodes(ref string text);
	}

	public interface IHasTypeAsset
	{
		IMakinomGenericAsset TypeAsset
		{
			get;
		}
	}

	public abstract class MakinomGenericAsset<T> : ScriptableObject, IMakinomGenericAsset where T : BaseIndexData, new()
	{
		[HideInInspector]
		[SerializeField]
		protected DataFile data;

		protected bool markedForSaving = false;

		[Tooltip("This asset will be sorted at the end of the list when opening the Makinom editor the next time.\n" +
			"If multiple assets are sorted at the end, they'll be added at the end and sorted by their index.")]
		public bool sortAtEnd = false;


		// loaded data
		[HideInInspector]
		[System.NonSerialized]
		protected T settings;


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public T Settings
		{
			get
			{
				if(this.settings == null)
				{
					this.LoadData();
				}
				return this.settings;
			}
			set { this.settings = value; }
		}

		public BaseIndexData EditorSettings
		{
			get { return this.Settings; }
		}

		public int Index
		{
			get { return this.Settings.ID; }
			set { this.Settings.ID = value; }
		}

		public bool SortAtEnd
		{
			get { return this.sortAtEnd; }
			set { this.sortAtEnd = value; }
		}

		public abstract string DataName
		{
			get;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void SetData(DataObject data)
		{
			this.settings = new T();
			this.settings.SetData(data);
		}

		public void LoadData()
		{
			this.settings = new T();

			if(this.data != null)
			{
				this.settings.SetData(this.data.ToDataObject());
				if(Application.isEditor &&
					Application.isPlaying)
				{
					MakinomGenericAssetCache.Cache(this);
				}
			}
		}

		public void ClearData()
		{
			if(this.data != null)
			{
				this.data.ClearDataObject();
				this.settings = null;
			}
		}

		public void SaveData(DataFile saveFile, bool encrypt, DataFile.SaveFormatType format)
		{
			this.markedForSaving = false;
			if(saveFile != null)
			{
				this.data = saveFile;
			}
			else if(this.settings != null)
			{
				this.data = this.settings.GetData().GetDataFile("settings", encrypt, format);
			}
			else
			{
				this.data = null;
			}
		}

		public bool MarkedForSaving
		{
			get { return this.markedForSaving; }
			set { this.markedForSaving = value; }
		}

		public bool HasChanged(bool encrypt, DataFile.SaveFormatType format, out DataFile file)
		{
			file = this.settings.GetData().GetDataFile("settings", encrypt, format);
			return this.data == null ||
				!this.data.CompareTo(file);
		}


		/*
		============================================================================
		Text code functions
		============================================================================
		*/
		public virtual void ReplaceTextCodes(ref string text)
		{
			int used = 0;
			TextCodeAttribute textCode = Maki.ReflectionHandler.GetTextCode(this.Settings.GetType());
			IContent settings = this.Settings as IContent;
			if(settings != null)
			{
				if(textCode.textCodes.Length >= 3 &&
					text.Contains(textCode.baseTextCode) &&
					text.Contains(this.Settings.GUID))
				{
					used = 5;

					TextHelper.ReplaceContentInformation(ref text, settings, this.Settings.GUID,
						textCode.textCodes[0], textCode.textCodes[1], textCode.textCodes[2],
						textCode.textCodes[3], textCode.textCodes[4]);

					// type content
					if(textCode.textCodes.Length >= used + 5 &&
						this.Settings is ITypeContent)
					{
						IContent typeContent = TypeContentHelper.Get(settings);
						if(typeContent != null)
						{
							TextHelper.ReplaceContentInformation(ref text, typeContent, this.Settings.GUID,
								textCode.textCodes[used], textCode.textCodes[used + 1], textCode.textCodes[used + 2],
								textCode.textCodes[used + 3], textCode.textCodes[used + 4]);
						}
						used += 5;
					}

					// sub data content
					if(textCode.textCodes.Length >= used + 5 &&
						this.Settings is ISubData)
					{
						ISubData subData = (ISubData)this.Settings;
						int count = subData.GetSubDataCount();
						for(int i = 0; i < count; i++)
						{
							IContent subContent = subData.GetSubDataContent(i);
							if(subContent != null)
							{
								TextHelper.ReplaceContentInformation(ref text, subContent, this.Settings.GUID,
									textCode.textCodes[used], textCode.textCodes[used + 1], textCode.textCodes[used + 2],
									textCode.textCodes[used + 3], textCode.textCodes[used + 4]);
							}
						}
						used += 5;
					}
				}
			}
			ITextCode other = this.Settings as ITextCode;
			if(other != null)
			{
				for(int i = used; i < textCode.textCodes.Length; i++)
				{
					text = text.Replace(
						textCode.textCodes[i] + this.Settings.GUID + TextCode.CloseTag,
						other.GetTextCode(i));
				}
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public virtual string GetEditorPopupName(bool addType)
		{
			return this.Settings.ID + ": " + this.Settings.EditorName;
		}

		public virtual string[] GetEditorSubDataNames()
		{
			if(this.Settings is ISubData)
			{
				return ((ISubData)this.Settings).GetEditorSubDataNames();
			}
			return new string[0];
		}

		public virtual int GetSubDataCount()
		{
			if(this.Settings is ISubData)
			{
				return ((ISubData)this.Settings).GetSubDataCount();
			}
			return 0;
		}

		public virtual IContent GetSubDataContent(int index)
		{
			if(this.Settings is ISubData)
			{
				return ((ISubData)this.Settings).GetSubDataContent(index);
			}
			return null;
		}
	}

	public abstract class MakinomGenericAssetWithType<T, V> : MakinomGenericAsset<T>, IHasTypeAsset where T : BaseIndexData, ITypeAsset<V>, new() where V : IMakinomGenericAsset
	{
		public IMakinomGenericAsset TypeAsset
		{
			get { return this.Settings.TypeAsset; }
		}

		public override string GetEditorPopupName(bool addType)
		{
			if(addType &&
				this.TypeAsset != null)
			{
				return this.Settings.ID + ": " + this.Settings.EditorName +
					"\n<i>" + this.TypeAsset.EditorSettings.EditorName + "</i>";
			}
			return this.Settings.ID + ": " + this.Settings.EditorName;
		}
	}
}
