﻿
using UnityEngine;
using GamingIsLove.Makinom.IO;
using System.Collections.Generic;
using System.IO;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Persistent Data Path", "The file is stored in 'Application.persistentDataPath'.")]
	public class PersistentDataPathTextFileHandler : BaseTextFileHandler
	{
		[EditorHelp("Save Folder", "Optionally define a folder that will be used (in the persistent data path) to store save games in.", "")]
		[EditorWidth(true)]
		public string saveFolder = "";

		public PersistentDataPathTextFileHandler()
		{

		}

		public override string ToString()
		{
			return "Persistent Data Path";
		}

		private string GetPath()
		{
			if(string.IsNullOrEmpty(this.saveFolder))
			{
				return Application.persistentDataPath + "/";
			}
			else
			{
				return Application.persistentDataPath + "/" + this.saveFolder + "/";
			}
		}

		public override void SaveFile(string fileName, string data)
		{
			string path = this.GetPath();
			if(!Directory.Exists(path))
			{
				Directory.CreateDirectory(path);
			}
			StreamWriter writer = new StreamWriter(path + fileName);
			writer.Write(data);
			writer.Flush();
			writer.Close();
		}

		public override string LoadFile(string fileName)
		{
			StreamReader reader = new StreamReader(
				this.GetPath() + fileName);
			string data = reader.ReadToEnd();
			reader.Close();
			return data;
		}

		public override void DeleteFile(string fileName)
		{
			File.Delete(this.GetPath() + fileName);
		}

		public override bool FileExists(string fileName)
		{
			return File.Exists(this.GetPath() + fileName);
		}
	}
}
