﻿
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Custom", "A custom control script is used.")]
	public class CustomInputIDKeySetting : BaseInputIDKeySetting
	{
		[EditorTitleLabel("Custom Button Function")]
		[EditorLabel("Calls a static function using reflection - the function must return a bool value.\n" +
			"Uses the player as game object (e.g. when using a formula or object variables).")]
		public CallFunction<GameObjectSelection> customButton = new CallFunction<GameObjectSelection>();

		[EditorSeparator]
		[EditorTitleLabel("Custom Axis Function")]
		[EditorLabel("Calls a static function using reflection - the function must return a float value.\n" +
			"Uses the player as game object (e.g. when using a formula or object variables).")]
		public CallFunction<GameObjectSelection> customAxis = new CallFunction<GameObjectSelection>();

		public CustomInputIDKeySetting()
		{

		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			DataCall call = this.customButton.NeedsCall || this.customAxis.NeedsCall ?
				new DataCall(inputKey.inputID) : null;

			object value = this.customButton.GetReturnValue(null, call, true);
			if(value is bool)
			{
				inputKey.InputReceived = (bool)value;
			}

			object value2 = this.customAxis.GetReturnValue(null, call, true);
			if(value2 is float)
			{
				inputKey.UpdateAxis = (float)value2;
			}
		}
	}
}
