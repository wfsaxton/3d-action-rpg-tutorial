
using UnityEngine;
using System.Collections.Generic;
using System.Text;

namespace GamingIsLove.Makinom
{
	public class GameStateCondition : BaseData
	{
		[EditorHelp("Needed", "Either all or only one game states must be valid.", "")]
		public Needed needed = Needed.One;

		[EditorArray("Add Game State", "Adds a game state check that must be valid.", "",
			"Remove", "Removes this game state check.", "",
			isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Game State Check", "Define the game state check.", ""
		})]
		public GameStateConditionCheck[] gameState = new GameStateConditionCheck[0];

		public GameStateCondition()
		{

		}

		public bool Check()
		{
			if(this.gameState.Length > 0)
			{
				for(int i = 0; i < this.gameState.Length; i++)
				{
					if(this.gameState[i].Check())
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				return Needed.All == this.needed;
			}
			return true;
		}

		public override string ToString()
		{
			StringBuilder builder = new StringBuilder();
			for(int i = 0; i < this.gameState.Length; i++)
			{
				if(builder.Length > 0)
				{
					builder.Append(", ");
				}
				builder.Append(this.gameState[i].ToString());
			}
			return builder.ToString();
		}
	}
}
