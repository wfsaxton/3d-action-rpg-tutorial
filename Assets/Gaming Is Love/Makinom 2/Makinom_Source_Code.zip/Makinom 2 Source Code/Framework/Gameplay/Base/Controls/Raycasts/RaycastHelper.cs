
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public static class RaycastHelper
	{
		/*
		============================================================================
		Single raycast functions
		============================================================================
		*/
		public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastOutput output)
		{
			return RaycastHelper.Raycast(Maki.GameSettings.raycastType, origin, direction, false, out output);
		}

		public static bool Raycast(RaycastType raycastType,
			Vector3 origin, Vector3 direction, out RaycastOutput output)
		{
			return RaycastHelper.Raycast(raycastType, origin, direction, false, out output);
		}

		public static bool Raycast(RaycastType raycastType,
			Vector3 origin, Vector3 direction, bool storeCoords, out RaycastOutput output)
		{
			if(RaycastType.Only3D == raycastType)
			{
				RaycastHit hit;
				if(Physics.Raycast(origin, direction, out hit))
				{
					output = new RaycastOutput(hit, storeCoords);
					return true;
				}
			}
			else if(RaycastType.Only2D == raycastType)
			{
				RaycastHit2D hit2D = Physics2D.Raycast(origin, direction);
				if(hit2D.collider != null)
				{
					output = new RaycastOutput(hit2D);
					return true;
				}
			}
			else if(RaycastType.First3D == raycastType)
			{
				// 3D
				RaycastHit hit;
				if(Physics.Raycast(origin, direction, out hit))
				{
					output = new RaycastOutput(hit, storeCoords);
					return true;
				}
				// 2D
				RaycastHit2D hit2D = Physics2D.Raycast(origin, direction);
				if(hit2D.collider != null)
				{
					output = new RaycastOutput(hit2D);
					return true;
				}
			}
			else if(RaycastType.First2D == raycastType)
			{
				// 2D
				RaycastHit2D hit2D = Physics2D.Raycast(origin, direction);
				if(hit2D.collider != null)
				{
					output = new RaycastOutput(hit2D);
					return true;
				}
				// 3D
				RaycastHit hit;
				if(Physics.Raycast(origin, direction, out hit))
				{
					output = new RaycastOutput(hit, storeCoords);
					return true;
				}
			}

			output = new RaycastOutput();
			return false;
		}

		public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastOutput output,
			float distance, LayerMask layerMask)
		{
			return RaycastHelper.Raycast(Maki.GameSettings.raycastType, origin, direction, out output, distance, layerMask, false);
		}

		public static bool Raycast(RaycastType raycastType,
			Vector3 origin, Vector3 direction, out RaycastOutput output,
			float distance, LayerMask layerMask)
		{
			return RaycastHelper.Raycast(raycastType, origin, direction, out output, distance, layerMask, false);
		}

		public static bool Raycast(RaycastType raycastType,
			Vector3 origin, Vector3 direction, out RaycastOutput output,
			float distance, LayerMask layerMask, bool storeCoords)
		{
			if(RaycastType.Only3D == raycastType)
			{
				RaycastHit hit;
				if(Physics.Raycast(origin, direction, out hit, distance, layerMask))
				{
					output = new RaycastOutput(hit, storeCoords);
					return true;
				}
			}
			else if(RaycastType.Only2D == raycastType)
			{
				RaycastHit2D hit2D = Physics2D.Raycast(origin, direction, distance, layerMask);
				if(hit2D.collider != null)
				{
					output = new RaycastOutput(hit2D);
					return true;
				}
			}
			else if(RaycastType.First3D == raycastType)
			{
				// 3D
				RaycastHit hit;
				if(Physics.Raycast(origin, direction, out hit, distance, layerMask))
				{
					output = new RaycastOutput(hit, storeCoords);
					return true;
				}
				// 2D
				RaycastHit2D hit2D = Physics2D.Raycast(origin, direction, distance, layerMask);
				if(hit2D.collider != null)
				{
					output = new RaycastOutput(hit2D);
					return true;
				}
			}
			else if(RaycastType.First2D == raycastType)
			{
				// 2D
				RaycastHit2D hit2D = Physics2D.Raycast(origin, direction, distance, layerMask);
				if(hit2D.collider != null)
				{
					output = new RaycastOutput(hit2D);
					return true;
				}
				// 3D
				RaycastHit hit;
				if(Physics.Raycast(origin, direction, out hit, distance, layerMask))
				{
					output = new RaycastOutput(hit, storeCoords);
					return true;
				}
			}

			output = new RaycastOutput();
			return false;
		}

		public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastOutput output,
			float distance, LayerMask layerMask, Transform ignore)
		{
			return RaycastHelper.Raycast(Maki.GameSettings.raycastType, origin, direction, out output, distance, layerMask, ignore, false);
		}

		public static bool Raycast(RaycastType raycastType, Vector3 origin, Vector3 direction, out RaycastOutput output,
			float distance, LayerMask layerMask, Transform ignore)
		{
			return RaycastHelper.Raycast(raycastType, origin, direction, out output, distance, layerMask, ignore, false);
		}

		public static bool Raycast(RaycastType raycastType, Vector3 origin, Vector3 direction, out RaycastOutput output,
			float distance, LayerMask layerMask, Transform ignore, bool storeCoords)
		{
			output = null;

			if(RaycastType.Only3D == raycastType)
			{
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					if(hit[i].transform.root != ignore.root)
					{
						RaycastOutput tmp = new RaycastOutput(hit[i], storeCoords);
						if(output == null ||
							tmp.distance < output.distance)
						{
							output = tmp;
						}
					}
				}
			}
			else if(RaycastType.Only2D == raycastType)
			{
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					if(hit2D[i].transform.root != ignore.root)
					{
						RaycastOutput tmp = new RaycastOutput(hit2D[i]);
						if(output == null ||
							tmp.distance < output.distance)
						{
							output = tmp;
						}
					}
				}
			}
			else if(RaycastType.First3D == raycastType)
			{
				// 3D
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					if(hit[i].transform.root != ignore.root)
					{
						RaycastOutput tmp = new RaycastOutput(hit[i], storeCoords);
						if(output == null ||
							tmp.distance < output.distance)
						{
							output = tmp;
						}
					}
				}
				// 2D
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					if(hit2D[i].transform.root != ignore.root)
					{
						RaycastOutput tmp = new RaycastOutput(hit2D[i]);
						if(output == null ||
							tmp.distance < output.distance)
						{
							output = tmp;
						}
					}
				}
			}
			else if(RaycastType.First2D == raycastType)
			{
				// 2D
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					if(hit2D[i].transform.root != ignore.root)
					{
						RaycastOutput tmp = new RaycastOutput(hit2D[i]);
						if(output == null ||
							tmp.distance < output.distance)
						{
							output = tmp;
						}
					}
				}
				// 3D
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					if(hit[i].transform.root != ignore.root)
					{
						RaycastOutput tmp = new RaycastOutput(hit[i], storeCoords);
						if(output == null ||
							tmp.distance < output.distance)
						{
							output = tmp;
						}
					}
				}
			}

			if(output != null)
			{
				return true;
			}
			else
			{
				output = new RaycastOutput();
				return false;
			}
		}


		/*
		============================================================================
		Multi raycast functions
		============================================================================
		*/
		public static List<RaycastOutput> RaycastAll(Vector3 origin, Vector3 direction, float distance, LayerMask layerMask)
		{
			return RaycastHelper.RaycastAll(Maki.GameSettings.raycastType, origin, direction, distance, layerMask, false);
		}

		public static List<RaycastOutput> RaycastAll(RaycastType raycastType,
			Vector3 origin, Vector3 direction, float distance, LayerMask layerMask)
		{
			return RaycastHelper.RaycastAll(raycastType, origin, direction, distance, layerMask, false);
		}

		public static List<RaycastOutput> RaycastAll(RaycastType raycastType,
			Vector3 origin, Vector3 direction, float distance, LayerMask layerMask, bool storeCoords)
		{
			List<RaycastOutput> output = new List<RaycastOutput>();
			if(RaycastType.Only3D == raycastType)
			{
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					output.Add(new RaycastOutput(hit[i], storeCoords));
				}
			}
			else if(RaycastType.Only2D == raycastType)
			{
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					output.Add(new RaycastOutput(hit2D[i]));
				}
			}
			else if(RaycastType.First3D == raycastType)
			{
				// 3D
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					output.Add(new RaycastOutput(hit[i], storeCoords));
				}
				// 2D
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					output.Add(new RaycastOutput(hit2D[i]));
				}
			}
			else if(RaycastType.First2D == raycastType)
			{
				// 2D
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					output.Add(new RaycastOutput(hit2D[i]));
				}
				// 3D
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					output.Add(new RaycastOutput(hit[i], storeCoords));
				}
			}

			// order output
			if(output.Count > 0)
			{
				output.Sort(new RaycastOutputSorter());
			}

			return output;
		}

		public static List<RaycastOutput> RaycastAll(Vector3 origin, Vector3 direction,
			float distance, LayerMask layerMask, Transform ignore)
		{
			return RaycastHelper.RaycastAll(Maki.GameSettings.raycastType, origin, direction, distance, layerMask, ignore, false);
		}

		public static List<RaycastOutput> RaycastAll(RaycastType raycastType, Vector3 origin, Vector3 direction,
			float distance, LayerMask layerMask, Transform ignore)
		{
			return RaycastHelper.RaycastAll(raycastType, origin, direction, distance, layerMask, ignore, false);
		}

		public static List<RaycastOutput> RaycastAll(RaycastType raycastType, Vector3 origin, Vector3 direction,
			float distance, LayerMask layerMask, Transform ignore, bool storeCoords)
		{
			List<RaycastOutput> output = new List<RaycastOutput>();
			if(RaycastType.Only3D == raycastType)
			{
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					if(hit[i].transform.root != ignore.root)
					{
						output.Add(new RaycastOutput(hit[i], storeCoords));
					}
				}
			}
			else if(RaycastType.Only2D == raycastType)
			{
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					if(hit2D[i].transform.root != ignore.root)
					{
						output.Add(new RaycastOutput(hit2D[i]));
					}
				}
			}
			else if(RaycastType.First3D == raycastType)
			{
				// 3D
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					if(hit[i].transform.root != ignore.root)
					{
						output.Add(new RaycastOutput(hit[i], storeCoords));
					}
				}
				// 2D
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					if(hit2D[i].transform.root != ignore.root)
					{
						output.Add(new RaycastOutput(hit2D[i]));
					}
				}
			}
			else if(RaycastType.First2D == raycastType)
			{
				// 2D
				RaycastHit2D[] hit2D = Physics2D.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit2D.Length; i++)
				{
					if(hit2D[i].transform.root != ignore.root)
					{
						output.Add(new RaycastOutput(hit2D[i]));
					}
				}
				// 3D
				RaycastHit[] hit = Physics.RaycastAll(origin, direction, distance, layerMask);
				for(int i = 0; i < hit.Length; i++)
				{
					if(hit[i].transform.root != ignore.root)
					{
						output.Add(new RaycastOutput(hit[i], storeCoords));
					}
				}
			}

			// order output
			if(output.Count > 0)
			{
				output.Sort(new RaycastOutputSorter());
			}

			return output;
		}
	}
}
