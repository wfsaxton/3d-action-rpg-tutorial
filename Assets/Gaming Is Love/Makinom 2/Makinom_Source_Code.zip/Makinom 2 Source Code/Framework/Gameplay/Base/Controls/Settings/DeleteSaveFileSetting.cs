﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class DeleteSaveFileSetting : BaseData
	{
		// delete key
		[EditorHelp("Delete Key", "Select the input key used to delete the currently selected save file.", "")]
		public AssetSelection<InputKeyAsset> deleteKey = new AssetSelection<InputKeyAsset>();

		[EditorFoldout("Delete Audio", "Select which audio clip of the UI box will be played when deleting a safe file.", "")]
		[EditorEndFoldout]
		public UIAudioSelection deleteAudio = new UIAudioSelection(UIBoxAudioType.Accept);

		[EditorFoldout("Delete Fail Audio", "Select which audio clip of the UI box will be played when deleting fails " +
			"(e.g. no save file selected).", "")]
		[EditorEndFoldout]
		public UIAudioSelection failAudio = new UIAudioSelection(UIBoxAudioType.Fail);


		// delete question
		[EditorHelp("Use Question Dialogue", "Use a question dialogue to allow the player to accept deleting the save file.", "")]
		[EditorFoldout("Delete File Question", "Optionally show a dialogue asking the player if the file should be deleted.\n" +
			"Use the '<filename>' text code to show the file name.", "")]
		public bool useQuestion = false;

		[EditorEndFoldout]
		[EditorCondition("useQuestion", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public QuestionControl question;


		// in-game
		private Notify deletedCallback;

		private Notify canceledCallback;

		private int lastFileIndex = -1;

		public DeleteSaveFileSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("audioType"))
			{
				UIBoxAudioType tmp = UIBoxAudioType.Accept;
				data.GetEnum<UIBoxAudioType>("audioType", ref tmp);
				this.deleteAudio = new UIAudioSelection(tmp);

				tmp = UIBoxAudioType.Fail;
				data.GetEnum<UIBoxAudioType>("failAudioType", ref tmp);
				this.failAudio = new UIAudioSelection(tmp);
			}
		}

		public bool CheckKey(int inputID)
		{
			return InputKey.GetButton(this.deleteKey.StoredAsset, inputID) &&
				(!this.useQuestion || !this.question.IsOpen);
		}

		public bool UseKey(IUIBox origin, int fileIndex, int inputID, Notify deletedCallback, Notify canceledCallback)
		{
			if(this.CheckKey(inputID))
			{
				this.DeleteFile(origin, fileIndex, inputID, deletedCallback, canceledCallback);
				return true;
			}
			return false;
		}

		public void DeleteFile(IUIBox origin, int fileIndex, int inputID, Notify deletedCallback, Notify canceledCallback)
		{
			if(Maki.SaveGame.FileExists(fileIndex))
			{
				this.deleteAudio.PlayClip(origin);

				if(this.useQuestion)
				{
					this.deletedCallback = deletedCallback;
					this.canceledCallback = canceledCallback;
					this.lastFileIndex = fileIndex;
					this.question.Show(Maki.SaveGame.GetFileNumberText(this.lastFileIndex),
						inputID, this.QuestionClosed);
				}
				else
				{
					Maki.SaveGame.DeleteFile(fileIndex);
					if(deletedCallback != null)
					{
						deletedCallback();
					}
				}
			}
			else
			{
				this.failAudio.PlayClip(origin);
			}
		}

		public void QuestionClosed(bool accepted)
		{
			Notify tmpCallback = null;
			if(accepted)
			{
				Maki.SaveGame.DeleteFile(this.lastFileIndex);
				tmpCallback = this.deletedCallback;
			}
			else
			{
				tmpCallback = this.canceledCallback;
			}
			this.deletedCallback = null;
			this.canceledCallback = null;
			if(tmpCallback != null)
			{
				tmpCallback();
			}
		}
	}
}
