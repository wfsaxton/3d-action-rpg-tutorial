﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ToggleKeySetting : BaseData
	{
		[EditorHelp("Start Toggle State", "If enabled, the toggle state will be on when starting the game.\n" +
			"If disabled, the toggle state will be off when starting the game.\n" +
			"When using 'Only While Key', the toggle state will be inversed, " +
			"i.e. if enabled, the toggle state will be on when the input key is not valid, " +
			"if disabled, the toggle state will be on when the input key is valid.", "")]
		public bool toggleStartState = true;

		[EditorHelp("Use Toggle Key", "Use a toggle key", "")]
		public bool useKey = false;

		[EditorHelp("Only While Key", "The toggle state is only changed while the selected toggle input key " +
			"is valid and returned to the original state when the key is invalid " +
			"(e.g. use a 'Hold' input key to have the key valid while holding it).\n" +
			"This depends on the 'Start Toggle State' setting, i.e. " +
			"if enabled, the toggle state will be on when the input key is not valid, " +
			"if disabled, the toggle state will be on when the input key is valid.", "")]
		[EditorCondition("useKey", true)]
		public bool onlyWhileKey = false;

		[EditorHelp("Toggle Key", "Select the input key used to toggle on/off.", "")]
		public AssetSelection<InputKeyAsset> toggleKey = new AssetSelection<InputKeyAsset>();


		// audio settings
		[EditorHelp("Audio Clip", "Select the audio clip that will be played when using the toggle key.", "")]
		[EditorAutoInit]
		public AssetSource<AudioClip> audioClip;

		[EditorHelp("Sound Channel", "Define the sound channel that will used.\n" +
			"The default channel is 0.", "")]
		[EditorCondition("audioClip.HasAsset", true)]
		[EditorLimit(0, false)]
		public int channel = 0;

		[EditorHelp("Volume", "The volume used to play the audio clip (between 0 and 1).", "")]
		[EditorEndCondition(2)]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		public float volume = 1f;

		public ToggleKeySetting()
		{

		}

		public void GetToggleState(ref bool state)
		{
			this.GetToggleState(ref state, Maki.Control.InputID);
		}

		public void GetToggleState(ref bool state, int inputID)
		{
			if(this.useKey)
			{
				if(this.onlyWhileKey)
				{
					bool newState = this.toggleStartState ?
						!InputKey.GetButton(this.toggleKey.StoredAsset, inputID) :
						InputKey.GetButton(this.toggleKey.StoredAsset, inputID);
					if(state != newState)
					{
						this.PlayClip();
						state = newState;
					}
				}
				else if(InputKey.GetButton(this.toggleKey.StoredAsset, inputID))
				{
					this.PlayClip();
					state = !state;
				}
			}
		}

		public virtual void PlayClip()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.audioClip, this.volume);
		}
	}
}
