﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Clear Selected Data", "Clears/removes selected data.\n" +
		"Either removes all data of a defined data key, or removes all data.", "")]
	[NodeInfo("Selected Data")]
	public class ClearSelectedDataNode : BaseFormulaNode
	{
		[EditorHelp("Clear All", "Clears/removes all data.\n" +
			"If disabled, only the selected data of a defined key is cleared/removed.", "")]
		public bool all = false;

		[EditorCondition("all", true)]
		public SelectedDataOrigin<FormulaObjectSelection> allSelectedData = new SelectedDataOrigin<FormulaObjectSelection>();

		[EditorElseCondition]
		[EditorEndCondition]
		public SelectedData<FormulaObjectSelection> selectedData = new SelectedData<FormulaObjectSelection>();

		public ClearSelectedDataNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.all)
			{
				this.allSelectedData.Clear(call);
			}
			else
			{
				this.selectedData.Clear(call, this.selectedData.key.GetValue(call));
			}

			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? this.allSelectedData.ToString() : this.selectedData.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Selected Data Count", "Checks how many data is stored in a selected data list or uses the count to change the formula value.\n" +
		"When checking and if the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Selected Data")]
	public class SelectedDataCountNode : BaseFormulaCheckNode
	{
		// use as value
		[EditorHelp("Use As Value", "Use the selected data count as a value to change the formula value instead of checking the count.", "")]
		public bool useAsValue = false;

		[EditorCondition("useAsValue", true)]
		[EditorEndCondition]
		public FloatOperator floatOperator = new FloatOperator();


		// selected data
		public SelectedData<FormulaObjectSelection> selectedData = new SelectedData<FormulaObjectSelection>();


		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		[EditorCondition("useAsValue", false)]
		[EditorEndCondition]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public SelectedDataCountNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.useAsValue)
			{
				this.floatOperator.Use(ref call.result, this.selectedData.GetCount(call));
				return this.next;
			}
			else
			{
				if(this.check.Check(this.selectedData.GetCount(call), call))
				{
					return this.next;
				}
				else
				{
					return this.nextFail;
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useAsValue ? (this.floatOperator + " " + this.selectedData.ToString()) :
				(this.selectedData.ToString() + " " + this.check.ToString());
		}

		public override int GetNextCount()
		{
			return this.useAsValue ? 1 : 2;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Selected Data", "Uses the first, last, a random or all content from another selected data as selected data.\n" +
		"E.g. select a random content from a list of data.\n" +
		"If something was stored, 'Success' will be executed, otherwise (i.e. nothing left to store) 'Failed'.", "")]
	[NodeInfo("Selected Data")]
	public class SelectSelectedDataNode : BaseFormulaCheckNode
	{
		// store
		[EditorFoldout("Store Selected Data", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> storeSelectedData = new SelectedDataChange<FormulaObjectSelection>();


		// source
		[EditorFoldout("Source Selected Data", "The source of the selected data.", "")]
		[EditorCondition("storeSelectedData.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public SelectedData<FormulaObjectSelection> sourceSelectedData = new SelectedData<FormulaObjectSelection>();

		[EditorHelp("Select Type", "Define which content of the selected data will be stored:\n" +
			"- First: The first content in the selected data.\n" +
			"- Last: The last content in the selected data.\n" +
			"- Random: A random content from the selected data.\n" +
			"- All: All content from the selected data.", "")]
		[EditorSeparator]
		public ListSelectionType selectionType = ListSelectionType.Random;

		[EditorHelp("Remove", "Removes the content from the selected data.", "")]
		[EditorEndCondition]
		[EditorEndFoldout]
		public bool remove = false;

		public SelectSelectedDataNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool stored = false;

			if(ListChangeType.Clear == this.storeSelectedData.changeType)
			{
				this.storeSelectedData.Change(null, call, true);
			}
			else
			{
				string sourceKey = this.sourceSelectedData.key.GetValue(call);
				List<object> list = this.sourceSelectedData.GetSelectedData(call, sourceKey);

				if(list != null)
				{
					if(ListSelectionType.First == this.selectionType)
					{
						if(list.Count > 0)
						{
							this.StoreSingle(call, list[0], ref stored, list);
						}
					}
					else if(ListSelectionType.Last == this.selectionType)
					{
						if(list.Count > 0)
						{
							this.StoreSingle(call, list[list.Count - 1], ref stored, list);
						}
					}
					else if(ListSelectionType.Random == this.selectionType)
					{
						if(list.Count > 0)
						{
							this.StoreSingle(call, list[Random.Range(0, list.Count)], ref stored, list);
						}
					}
					else if(ListSelectionType.All == this.selectionType)
					{
						if(list.Count > 0)
						{
							stored = true;
							this.storeSelectedData.Change(list, call, true);

							if(this.remove)
							{
								this.sourceSelectedData.Clear(call, sourceKey);
							}
						}
					}
				}
			}

			if(stored)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		private void StoreSingle(FormulaCall call, object newData, ref bool stored, List<object> list)
		{
			if(newData != null)
			{
				stored = true;
				this.storeSelectedData.Change(newData, call, true);

				if(this.remove)
				{
					list.Remove(newData);
					this.sourceSelectedData.Change(call, list, ListChangeType.Set);
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.storeSelectedData.IsClear)
			{
				return this.storeSelectedData.ToString();
			}
			return this.storeSelectedData.ToString() + ": " +
				this.selectionType + " " + this.sourceSelectedData.ToString() +
				(this.remove ? " (remove)" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Variable Handlers", "Uses variable handlers to change selected data.\n" +
		"A variable handler stores all variables of an origin, e.g. the global variables or object variables of a game object.", "")]
	[NodeInfo("Selected Data")]
	public class SelectVariableHandlersNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();

		[EditorFoldout("Variable Handler Settings", "Define which variable handler will be used.", "")]
		[EditorEndFoldout]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		[EditorEndCondition]
		public VariableOrigin<FormulaObjectSelection> variable = new VariableOrigin<FormulaObjectSelection>();

		public SelectVariableHandlersNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				List<VariableHandler> list = this.variable.GetHandlers(call);
				this.dataChange.Change(list, call, true);
				Maki.Pooling.VariableHandlerLists.Add(list);
			}

			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " + this.variable.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Select Components", "Uses components to change selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectComponentsNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> dataChange = new SelectedDataChange<FormulaObjectSelection>();

		[EditorHelp("Component Name", "The name of the component that will be used.", "")]
		[EditorFoldout("Component Settings", "Define which components will be used.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		[EditorCondition("dataChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		public string componentName = "";

		[EditorHelp("Scope", "Select the scope of components that will be used:\n" +
			"- Single: A single component attached to the game object.\n" +
			"- In Children: A single component attached to the game object or any child object.\n" +
			"- In Parent: A single component attached to the game object or any parent object.\n" +
			"- From Root: A single component attached to the game object's root or any child object (from the root).\n" +
			"- All: All components attached to the game object.\n" +
			"- All In Children: All components attached to the game object and child objects.\n" +
			"- All In Parent: All components attached to the game object and parent objects.\n" +
			"- All From Root: All components attached to the game object's root and child objects (from the root).", "")]
		public ComponentScope scope = ComponentScope.Single;

		[EditorSeparator]
		[EditorEndFoldout]
		[EditorTitleLabel("From Game Object")]
		[EditorLabel("Components of the selected game object(s) will be used.")]
		[EditorEndCondition]
		public FormulaObjectSelection usedObject = new FormulaObjectSelection();

		public SelectComponentsNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.dataChange.changeType)
			{
				this.dataChange.Change(null, call, true);
			}
			else
			{
				if(this.componentName != "")
				{
					List<Component> list = this.usedObject.GetAllComponents(
						call, this.scope, this.componentName);
					this.dataChange.Change(list, call, true);
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.dataChange.IsClear)
			{
				return this.dataChange.ToString();
			}
			return this.dataChange.ToString() + ": " +
				this.componentName + ", " + this.usedObject.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Select Game Objects", "Uses game objects to change selected data.", "")]
	[NodeInfo("Selected Data")]
	public class SelectGameObjectsNode : BaseFormulaNode
	{
		[EditorFoldout("Selected Data Settings", "Define which selected data will be changed.", "")]
		[EditorEndFoldout]
		public SelectedDataChange<FormulaObjectSelection> objectChange = new SelectedDataChange<FormulaObjectSelection>();


		// game object
		[EditorFoldout("Game Object Settings", "Define which game objects will be used.", "")]
		[EditorEndFoldout]
		[EditorCondition("objectChange.changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		[EditorEndCondition]
		public FormulaObjectSelection usedObject = new FormulaObjectSelection();

		public SelectGameObjectsNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.objectChange.IsClear)
			{
				this.objectChange.Change(null, call, true);
			}
			else
			{
				List<GameObject> list = this.usedObject.GetObjects(call);
				this.objectChange.Change(list, call, true);
				Maki.Pooling.GameObjectLists.Add(list);
			}

			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.objectChange.IsClear)
			{
				return this.objectChange.ToString();
			}
			return this.objectChange.ToString() + ": " + this.usedObject.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}
