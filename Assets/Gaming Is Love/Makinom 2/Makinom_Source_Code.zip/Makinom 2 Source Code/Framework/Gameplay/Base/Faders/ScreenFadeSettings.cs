﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ScreenFadeSettings : BaseData
	{
		// screen fade out
		[EditorHelp("Fade Out", "Fade the screen out before changing scenes.")]
		[EditorFoldout("Screen Fade Out", "Optionally fade the screen out before changing scenes.", "")]
		public bool useFadeOut = true;

		[EditorEndFoldout]
		[EditorCondition("useFadeOut", true)]
		[EditorEndCondition]
		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1, true);


		// screen fade in
		[EditorHelp("Fade In", "Fade the screen in after changing scenes.")]
		[EditorFoldout("Screen Fade In", "Optionally fade the screen in after changing scenes.", "")]
		public bool useFadeIn = true;

		[EditorHelp("Wait For Fade", "Wait for fading in to finish before unblocking player/camera controls and finishing the scene change.")]
		[EditorCondition("useFadeIn", true)]
		public bool waitFadeIn = false;

		[EditorEndFoldout]
		[EditorEndCondition]
		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0, true);

		public ScreenFadeSettings()
		{

		}
	}
}
