
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	public abstract class BaseFormulaNode : BaseNode
	{
		[EditorHelp("Enabled", "This node is enabled and will be executed.\n" +
			"If disabled, the node won't execute and the next node ('Next') will be executed.", "")]
		[EditorInfo(isToggleLeft=true)]
		[EditorHide]
		[EditorWidth(150)]
		public bool active = true;

		[EditorHide]
		public int next = -1;

		public abstract int Calculate(FormulaCall call);

		public virtual int CalculatePreview(FormulaCall call)
		{
			return this.Calculate(call);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Next";
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.next;
		}

		public override void SetNext(int index, int next)
		{
			this.next = next;
		}


		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get { return this.active; }
			set { this.active = value; }
		}

		public override bool ShowEnableToggle
		{
			get { return true; }
		}
	}

	public abstract class BaseFormulaCheckNode : BaseFormulaNode
	{
		[EditorHide]
		public int nextFail = -1;


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}

		public override int GetNextCount()
		{
			return 2;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
}
