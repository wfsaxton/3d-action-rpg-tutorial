﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class AutoStopInteractionSettings : BaseData
	{
		[EditorHelp("Only In Control", "Only use auto stop if the player control is not blocked.\n" +
			"I.e. interactions will only be stopped if the player can be controlled.")]
		public bool onlyInControl = true;

		[EditorHelp("Auto Stop Distance", "The distance in world units the player must at least have to the interaction to stop it.\n" +
			"The distance is checked greater equal.", "")]
		[EditorLimit(0)]
		public float distance = 10;

		[EditorHelp("Ignore Distance", "The distance along the enabled axes will be ignored, " +
			"e.g. enabling Y will ignore the height difference for the distance check.", "")]
		public AxisBool ignoreDistance = new AxisBool();

		[EditorHelp("Ignore Radius", "The radius of the game objects will be ignored for the distance check.", "")]
		public bool ignoreRadius = false;

		public AutoStopInteractionSettings()
		{

		}

		public virtual bool Check(GameObject interaction)
		{
			return (!this.onlyInControl || !Maki.Control.Blocked) &&
				VectorHelper.Distance(interaction, Maki.Game.Player.GameObject, this.ignoreDistance, this.ignoreRadius) >= this.distance;
		}
	}
}
