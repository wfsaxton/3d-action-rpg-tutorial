
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStateCheck : BaseData
	{
		[EditorHelp("Game State", "Select the game state that will be checked.", "")]
		public AssetSelection<GameStateAsset> state = new AssetSelection<GameStateAsset>();

		[EditorHelp("Check State", "Check if the game state is active or inactive.", "")]
		public ActiveType check = ActiveType.Active;

		public GameStateCheck()
		{

		}

		public bool Check()
		{
			return this.state.StoredAsset != null &&
				this.state.StoredAsset.Settings.IsActive == (ActiveType.Active == this.check);
		}

		public override string ToString()
		{
			return this.state.ToString() + " is " + this.check;
		}
	}
}
