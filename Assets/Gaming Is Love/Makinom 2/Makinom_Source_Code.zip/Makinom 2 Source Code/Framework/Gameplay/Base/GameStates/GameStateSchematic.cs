﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStateSchematic : BaseData
	{
		[EditorHelp("Initialization Use", "Execute the schematic when the game state is initialized or reinitialized.")]
		public bool initializationUse = false;

		[EditorHelp("Schematic Asset", "Select the schematic asset that'll be used by the game state's change.")]
		public AssetSource<MakinomSchematicAsset> schematicAsset = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Update Type", "Select in which frame update function the machine will be updated.")]
		public MachineUpdateType updateType = MachineUpdateType.Update;

		[EditorHelp("In Pause", "The machine will also be upated when the game is paused.", "")]
		public bool inPause = false;

		[EditorHelp("Set Priority", "Set a priority for this machine.")]
		public bool setPriority = false;

		[EditorHelp("Priority", "The priority of this machine.\n" +
			"The priority of machines decides which machine will be performed before other machines.\n" +
			"Machines are sorted descending by their priority, " +
			"i.e. the highest priority number will be the first machine to execute.")]
		[EditorCondition("setPriority", true)]
		[EditorEndCondition]
		public int priority = 0;


		// input ID
		[EditorSeparator]
		[EditorTitleLabel("Input ID")]
		public InputID inputID = new InputID();

		public GameStateSchematic()
		{

		}

		public void PlaySchematic()
		{
			if(this.schematicAsset.StoredAsset != null)
			{
				Schematic tmpSchematic = new Schematic(this.schematicAsset.StoredAsset);
				tmpSchematic.InPause = this.inPause;
				if(this.setPriority)
				{
					tmpSchematic.PlaySchematic(this.priority, this, null, null, null, false, this.updateType, this.inputID.GetInputID());
				}
				else
				{
					tmpSchematic.PlaySchematic(this, null, null, null, false, this.updateType, this.inputID.GetInputID());
				}
			}
		}
	}
}
