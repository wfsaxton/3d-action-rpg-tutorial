
namespace GamingIsLove.Makinom
{
	public class FormulaTypeAsset : MakinomGenericAsset<FormulaType>
	{
		public FormulaTypeAsset()
		{

		}

		public override string DataName
		{
			get { return "Formula Type"; }
		}
	}

	public class FormulaType : BaseIndexData
	{
		[EditorHelp("Name", "The name of the formula type.\n" +
			"Formula types are only used to filter formulas.", "")]
		[EditorFoldout("Formula Type Settings", "Set the name of the formula type.\n"+
			"Formula types are only used to filter formulas.", "")]
		[EditorEndFoldout]
		[EditorWidth(true)]
		public string name = "";

		public FormulaType()
		{

		}

		public FormulaType(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}

