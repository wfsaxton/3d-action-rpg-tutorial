﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Sphere 3D", "Casts a sphere into the scene (uses 'Collider').")]
	public class Sphere3DShapecastType<T> : BaseShapecastType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Origin")]
		[EditorLabel("The center of the sphere at the start of the sweep.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorHelp("Radius", "The radius of the sphere.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Radius")]
		public FloatValue<T> radius = new FloatValue<T>();

		public Sphere3DShapecastType()
		{

		}

		public override string ToString()
		{
			return "Sphere 3D";
		}

		public override bool CastSingle(out RaycastOutput hit, IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit tmpHit;
			if(Physics.SphereCast(this.origin.GetValue(call),
				this.radius.GetValue(call), direction, out tmpHit, maxDistance, layerMask))
			{
				hit = new RaycastOutput(tmpHit, storeCoords);
				return true;
			}
			else
			{
				hit = null;
				return false;
			}
		}

		public override RaycastOutput[] CastAll(IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit[] tmpHit = Physics.SphereCastAll(this.origin.GetValue(call),
				this.radius.GetValue(call), direction, maxDistance, layerMask);

			if(tmpHit != null)
			{
				RaycastOutput[] hit = new RaycastOutput[tmpHit.Length];
				for(int i = 0; i < tmpHit.Length; i++)
				{
					hit[i] = new RaycastOutput(tmpHit[i], storeCoords);
				}
				return hit;
			}
			return null;
		}
	}
}
