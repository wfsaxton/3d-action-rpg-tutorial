﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseMovementComponentSetting : BaseTypeData
	{
		public abstract IMovementComponent Init(GameObject gameObject);
	}
}
