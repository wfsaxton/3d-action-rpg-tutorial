﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.Makinom
{
	public class MoveSpeed<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Speed Type", "Select the speed used to move:\n" +
			"- Walk: The game object's walk speed.\n" +
			"- Run: The game object's run speed.\n" +
			"- Sprint: The game object's sprint speed.\n" +
			"- Value: A defined value.\n" +
			"If the game object doesn't have a move speed component (or implementation of the 'IMoveSpeed' interface), " +
			"the defined speed will be used as a fallback.", "")]
		public MoveSpeedType type = MoveSpeedType.Value;

		[EditorHelp("Speed", "The speed in world units per second used to move.\n" +
			"If the game object doesn't have a move speed component (or implementation of the 'IMoveSpeed' interface), " +
			"the defined speed will be used as a fallback.", "")]
		public FloatValue<T> speed = new FloatValue<T>();

		public MoveSpeed()
		{

		}

		public MoveSpeed(MoveSpeedType type)
		{
			this.type = type;
		}

		public MoveSpeed(float value)
		{
			this.speed = new FloatValue<T>(value);
		}

		public MoveSpeed(MoveSpeedType type, float value)
		{
			this.type = type;
			this.speed = new FloatValue<T>(value);
		}

		public override string ToString()
		{
			return MoveSpeedType.Value == this.type ?
				this.speed.ToString() :
				this.type.ToString();
		}


		/*
		============================================================================
		Speed functions
		============================================================================
		*/
		public virtual float GetSpeed(GameObject gameObject, IDataCall call)
		{
			if(MoveSpeedType.Value != this.type &&
				gameObject != null)
			{
				IMoveSpeed moveSpeed = gameObject.GetComponentInChildren<IMoveSpeed>();
				if(moveSpeed != null)
				{
					return moveSpeed.GetMoveSpeed(this.type);
				}
			}
			return this.speed.GetValue(call);
		}
	}
}
