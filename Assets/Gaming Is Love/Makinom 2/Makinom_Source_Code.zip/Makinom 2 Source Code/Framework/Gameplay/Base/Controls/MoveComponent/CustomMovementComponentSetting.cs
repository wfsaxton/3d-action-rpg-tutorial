﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom.Reflection;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Custom", "A custom component is used.")]
	public class CustomMovementComponentSetting : BaseMovementComponentSetting
	{
		[EditorHelp("Add Component", "A 'Nav Mesh Agent' component will be added to the game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the game object.", "")]
		public bool compAdd = false;

		[EditorHelp("Component Name", "The name of the custom component used to move the game object.\n" +
			"If the component is in a namespace, you must define the full path (e.g. MyNamespace.ComponentName).", "")]
		[EditorWidth(true)]
		public string compName = "";

		[EditorHelp("Move Method Name", "The name of the method used to move the game object.\n" +
			"Requires a method that takes a Vector3 value as parameter (the movement change).", "")]
		[EditorWidth(true)]
		public string compMoveMethod = "";

		[EditorHelp("Speed Method Name", "The name of the method used to set the move speed.\n" +
			"Requires a method that takes a float value as parameter (the speed value).", "")]
		[EditorWidth(true)]
		public string compSpeedMethod = "";

		[EditorHelp("Move Position Method Name", "The name of the method used to set the move position.\n" +
			"Requires a method that takes a Vector3 value as parameter (the position to move to).", "")]
		[EditorWidth(true)]
		public string compPositionMethod = "";

		[EditorHelp("Set Position Method Name", "The name of the method used to set the position.\n" +
			"Requires a method that takes a Vector3 value as parameter (the position).", "")]
		[EditorWidth(true)]
		public string compSetPositionMethod = "";

		[EditorHelp("Stop Method Name", "The name of the method used to stop the movement.\n" +
			"Requires a method that takes no parameters.", "")]
		[EditorWidth(true)]
		public string compStopMethod = "";

		public CustomMovementComponentSetting()
		{

		}

		public override IMovementComponent Init(GameObject gameObject)
		{
			return new MoveComponent(gameObject, this);
		}

		public class MoveComponent : IMovementComponent
		{
			private Component customComponent;

			private MethodInstance customMoveMethod;

			private MethodInstance customSpeedMethod;

			private MethodInstance customMovePositionMethod;

			private MethodInstance customSetPositionMethod;

			private MethodInstance customStopMethod;

			public MoveComponent(GameObject gameObject, CustomMovementComponentSetting setting)
			{
				System.Type type = Maki.ReflectionHandler.GetTypeOrInterface(setting.compName, typeof(Component));
				if(type != null)
				{
					this.customComponent = gameObject.transform.root.GetComponentInChildren(type);
					if(this.customComponent == null &&
						setting.compAdd)
					{
						this.customComponent = gameObject.AddComponent(type);
					}
				}
				if(this.customComponent != null)
				{
					if(setting.compMoveMethod != "")
					{
						this.customMoveMethod = new MethodInstance(this.customComponent);
						System.Type instanceType = this.customComponent.GetType();
						Maki.ReflectionHandler.GetMethod(
							setting.compMoveMethod,
							new System.Type[] { typeof(Vector3) },
							ref this.customMoveMethod.instance, ref instanceType);
					}
					if(setting.compSpeedMethod != "")
					{
						this.customSpeedMethod = new MethodInstance(this.customComponent);
						System.Type instanceType = this.customComponent.GetType();
						Maki.ReflectionHandler.GetMethod(
							setting.compSpeedMethod,
							new System.Type[] { typeof(float) },
							ref this.customSpeedMethod.instance, ref instanceType);
					}
					if(setting.compPositionMethod != "")
					{
						this.customMovePositionMethod = new MethodInstance(this.customComponent);
						System.Type instanceType = this.customComponent.GetType();
						Maki.ReflectionHandler.GetMethod(
							setting.compPositionMethod,
							new System.Type[] { typeof(Vector3) },
							ref this.customMovePositionMethod.instance, ref instanceType);
					}
					if(setting.compSetPositionMethod != "")
					{
						this.customSetPositionMethod = new MethodInstance(this.customComponent);
						System.Type instanceType = this.customComponent.GetType();
						Maki.ReflectionHandler.GetMethod(
							setting.compSetPositionMethod,
							new System.Type[] { typeof(Vector3) },
							ref this.customSetPositionMethod.instance, ref instanceType);
					}
					if(setting.compStopMethod != "")
					{
						this.customStopMethod = new MethodInstance(this.customComponent);
						System.Type instanceType = this.customComponent.GetType();
						Maki.ReflectionHandler.GetMethod(
							setting.compStopMethod,
							new System.Type[] { },
							ref this.customStopMethod.instance, ref instanceType);
					}
				}
			}

			public virtual void Move(Vector3 change)
			{
				// set position
				if(this.customMoveMethod != null)
				{
					this.customMoveMethod.Invoke(new object[] { change });
				}
			}

			public virtual bool MoveTo(ref Vector3 position, float speed)
			{
				// set speed
				if(this.customSpeedMethod != null)
				{
					this.customSpeedMethod.Invoke(new object[] { speed });
				}
				// set position
				if(this.customMovePositionMethod != null)
				{
					this.customMovePositionMethod.Invoke(new object[] { position });
					return true;
				}
				return false;
			}

			public virtual void SetPosition(Vector3 position)
			{
				// set position
				if(this.customSetPositionMethod != null)
				{
					this.customSetPositionMethod.Invoke(new object[] { position });
				}
			}

			public virtual void Stop()
			{
				if(this.customStopMethod != null)
				{
					this.customStopMethod.Invoke(null);
				}
			}
		}
	}
}
