﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Box 3D", "Casts a box into the scene (uses 'Collider').")]
	public class Box3DShapecastType<T> : BaseShapecastType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Center")]
		[EditorLabel("The centre/origin of the box.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Half Extents")]
		[EditorLabel("The extents of the box into each direction (i.e. half size of the box).")]
		public Vector3Value<T> size = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Orientation")]
		[EditorLabel("The orientation of the box.")]
		public Vector3Value<T> orientation = new Vector3Value<T>();

		public Box3DShapecastType()
		{

		}

		public override string ToString()
		{
			return "Box 3D";
		}

		public override bool CastSingle(out RaycastOutput hit, IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit tmpHit;
			if(Physics.BoxCast(this.origin.GetValue(call), this.size.GetValue(call),
				direction, out tmpHit,
				Quaternion.Euler(this.orientation.GetValue(call)),
				maxDistance, layerMask))
			{
				hit = new RaycastOutput(tmpHit, storeCoords);
				return true;
			}
			else
			{
				hit = null;
				return false;
			}
		}

		public override RaycastOutput[] CastAll(IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit[] tmpHit = Physics.BoxCastAll(
				this.origin.GetValue(call), this.size.GetValue(call),
				direction, Quaternion.Euler(this.orientation.GetValue(call)),
				maxDistance, layerMask);

			if(tmpHit != null)
			{
				RaycastOutput[] hit = new RaycastOutput[tmpHit.Length];
				for(int i = 0; i < tmpHit.Length; i++)
				{
					hit[i] = new RaycastOutput(tmpHit[i], storeCoords);
				}
				return hit;
			}
			return null;
		}
	}
}
