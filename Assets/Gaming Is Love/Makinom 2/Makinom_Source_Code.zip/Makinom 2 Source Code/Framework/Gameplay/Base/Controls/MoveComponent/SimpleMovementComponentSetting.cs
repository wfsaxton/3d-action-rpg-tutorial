﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Default", "A simple movement component that will move directly to the destination.\n" +
		"3D: Uses a 'Character Controller' component for movement.\n" +
		"2D: Uses a 'Rigidbody 2D' component for movement.")]
	public class SimpleMovementComponentSetting : BaseMovementComponentSetting
	{
		[EditorHelp("Add Component", "The component will be added to the game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the game object.", "")]
		public bool compAdd = false;

		[EditorLabel("The settings will only be used if the component is added (i.e. not already attached).")]
		[EditorSeparator]
		[EditorCondition("compAdd", true)]
		[EditorEndCondition]
		public SimpleMove.Settings settings = new SimpleMove.Settings();

		public SimpleMovementComponentSetting()
		{

		}

		public override IMovementComponent Init(GameObject gameObject)
		{
			return new MoveComponent(gameObject, this);
		}

		public class MoveComponent : IMovementComponent
		{
			private SimpleMove simpleMove;

			public MoveComponent(GameObject gameObject, SimpleMovementComponentSetting setting)
			{
				if(this.simpleMove == null)
				{
					this.simpleMove = gameObject.transform.root.GetComponentInChildren<SimpleMove>();
					if(this.simpleMove == null &&
						setting.compAdd)
					{
						this.simpleMove = gameObject.AddComponent<SimpleMove>();
						this.simpleMove.settings = setting.settings;
					}
				}
			}

			public virtual void Move(Vector3 change)
			{
				if(this.simpleMove != null)
				{
					this.simpleMove.Move(change);
				}
			}

			public virtual bool MoveTo(ref Vector3 position, float speed)
			{
				if(this.simpleMove != null)
				{
					this.simpleMove.MoveTo(speed, position);
					return true;
				}
				return false;
			}

			public virtual void SetPosition(Vector3 position)
			{
				if(this.simpleMove != null)
				{
					this.simpleMove.SetPosition(position);
				}
			}

			public virtual void Stop()
			{
				if(this.simpleMove != null)
				{
					this.simpleMove.Stop();
				}
			}
		}
	}
}
