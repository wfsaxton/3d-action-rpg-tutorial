﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Key Code", "The key mapped to the selected key code is used.")]
	public class KeyCodeInputIDKeySetting : BaseInputIDKeySetting
	{
		// key code
		[EditorHelp("Positive Key", "Select the Key Code of the key used for the positive axis value.\n" +
			"If this key isn't used for axis input (e.g. horizontal selection), you only need to define a positive key.")]
		public KeyCode positiveKey = KeyCode.None;

		[EditorHelp("Negative Key", "Select the Key Code of the key used for the negative axis value.\n" +
			"If this key isn't used for axis input (e.g. horizontal selection), you only need to define a positive key.")]
		public KeyCode negativeKey = KeyCode.None;


		// input handling
		[EditorHelp("Input Handling", "Select when the input will be recognized:\n" +
			"- Down: When the key is pressed down.\n" +
			"- Hold: While the key is held down.\n" +
			"- Up: When the key is released.\n" +
			"- Any: When the key is pressed down, held down or released.")]
		[EditorSeparator]
		public InputHandling handling = InputHandling.Down;

		[EditorHelp("Timeout (s)", "The time in seconds between recognizing two inputs.\n" +
			"Set to 0 to recognize the input every frame.")]
		[EditorLimit(0.0f, false)]
		public float inputTimeout = 0;

		[EditorHelp("Hold Time (s)", "The time in seconds the input has to be held to recognize the input.\n" +
			"Set to 0 to recognize the input immediately.")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("handling", InputHandling.Down)]
		[EditorElseCondition]
		[EditorDefaultValue(0.0f)]
		public float inputHoldTime = 0;

		[EditorHelp("Max Hold Time (s)", "The maximum time in seconds the input can be held to recognize the input.\n" +
			"Holding the input for longer will stop recognizing it as input.\n" +
			"Set to 0 to not use a maximum hold time.")]
		[EditorLimit(0.0f, false)]
		[EditorEndCondition]
		[EditorDefaultValue(0.0f)]
		public float inputMaxHoldTime = 0;

		public KeyCodeInputIDKeySetting()
		{

		}

		public KeyCodeInputIDKeySetting(KeyCode positiveKey, KeyCode negativeKey, InputHandling handling)
		{
			this.positiveKey = positiveKey;
			this.negativeKey = negativeKey;
			this.handling = handling;
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override float InputTimeout
		{
			get { return this.inputTimeout; }
		}

		public override float InputHoldTime
		{
			get { return this.inputHoldTime; }
		}

		public override float InputMaxHoldTime
		{
			get { return this.inputMaxHoldTime; }
		}

		public override InputHandling Handling
		{
			get { return this.handling; }
		}

		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if((this.inputHoldTime > 0 ||
					this.inputMaxHoldTime > 0) &&
				(Input.GetKeyUp(this.positiveKey) ||
					Input.GetKeyUp(this.negativeKey)))
			{
				inputKey.ReleaseDownTime();
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			// set input down time
			if(this.inputHoldTime > 0 ||
				this.inputMaxHoldTime > 0)
			{
				if(Input.GetKeyDown(this.positiveKey) || Input.GetKeyDown(this.negativeKey))
				{
					inputKey.SetDownTime();
					return;
				}
				else if(Input.GetKeyUp(this.positiveKey) || Input.GetKeyUp(this.negativeKey))
				{
					inputKey.ReleaseDownTime();
					if(InputHandling.Hold == this.handling)
					{
						return;
					}
				}
			}

			// positive key
			if((InputHandling.Down == this.handling && Input.GetKeyDown(this.positiveKey)) ||
				(InputHandling.Hold == this.handling && Input.GetKey(this.positiveKey)) ||
				(InputHandling.Up == this.handling && Input.GetKeyUp(this.positiveKey)) ||
				(InputHandling.Any == this.handling &&
					(Input.GetKeyDown(this.positiveKey) || Input.GetKey(this.positiveKey) ||
					Input.GetKeyUp(this.positiveKey))))
			{
				inputKey.Timeout = Time.realtimeSinceStartup + this.inputTimeout;
				inputKey.UpdateAxis = 1;
				inputKey.InputReceived = true;
			}
			// negative key
			else if((InputHandling.Down == this.handling && Input.GetKeyDown(this.negativeKey)) ||
				(InputHandling.Hold == this.handling && Input.GetKey(this.negativeKey)) ||
				(InputHandling.Up == this.handling && Input.GetKeyUp(this.negativeKey)) ||
				(InputHandling.Any == this.handling &&
					(Input.GetKeyDown(this.negativeKey) || Input.GetKey(this.negativeKey) ||
					Input.GetKeyUp(this.negativeKey))))
			{
				inputKey.Timeout = Time.realtimeSinceStartup + this.inputTimeout;
				inputKey.UpdateAxis = -1;
				inputKey.InputReceived = true;
			}
		}
	}
}
