﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/UI/Navigation Marker")]
	public class NavigationMarkerComponent : SerializedBehaviour<NavigationMarkerComponent.Settings>
	{
		// in-game
		protected bool isAdded = false;

		protected virtual void OnEnable()
		{
			if(Maki.Initialized)
			{
				this.AddMarker();
			}
		}

		protected virtual void Start()
		{
			this.AddMarker();
		}

		protected virtual void OnDisable()
		{
			this.RemoveMarker();
		}


		/*
		============================================================================
		HUD functions
		============================================================================
		*/
		public virtual void AddMarker()
		{
			if(!this.isAdded)
			{
				this.isAdded = true;

				Maki.Game.Scene.SetNavigationMarker(this.settings.name,
					new NavigationMarker(this.settings.markerType, this.gameObject));
			}
		}

		public virtual void RemoveMarker()
		{
			if(this.isAdded)
			{
				this.isAdded = false;
				Maki.Game.Scene.RemoveNavigationMarker(this.settings.name);
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Marker Name", "The name of the marker.\n" +
				"The name is used to identify the marker - " +
				"if you add another marker with the same name, the old marker will be overridden.", "")]
			[EditorWidth(true)]
			[EditorLabel("Shows a navigation marker for this game object as long as it's enabled/alive.\n" + 
				"E.g. upon changing the scene, this marker will be removed.")]
			public string name = "";

			[EditorHelp("Marker Type", "Define the type of the marker.\n" +
				"Navigation HUDs use marker types to distinguish between " +
				"different markers and display them with different labels.")]
			[EditorWidth(true)]
			public string markerType = "";

			public Settings()
			{

			}
		}
	}
}
