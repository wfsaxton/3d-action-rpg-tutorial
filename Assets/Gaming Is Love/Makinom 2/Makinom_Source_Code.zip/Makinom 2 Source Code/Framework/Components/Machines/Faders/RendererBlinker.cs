
using System.Collections.Generic;
using UnityEngine;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class RendererBlinker : MonoBehaviour
	{
		protected GetFloat deltaTime;


		// components
		protected Renderer rendererSingle;

		protected Projector projectorSingle;

		protected Renderer[] renderers;

		protected Projector[] projectors;


		// blinking
		protected bool currentState = false;

		protected int currentCount = 0;

		protected int blinkCount = 1;

		protected float currentTime = 0;

		protected float visibleTime = 0.5f;

		protected float invisibleTime = 0.5f;


		// options
		protected bool isBlinking = false;

		public virtual void Clear()
		{
			this.isBlinking = false;
			this.currentTime = 0;
			this.currentCount = 0;

			this.deltaTime = null;
			this.rendererSingle = null;
			this.projectorSingle = null;
			this.renderers = null;
			this.projectors = null;
		}

		protected virtual void IsBlinking(bool blink)
		{
			this.isBlinking = blink;
			this.enabled = blink;
		}


		/*
		============================================================================
		Blink functions
		============================================================================
		*/
		public virtual void Blink(bool startState, int blinkCount, float visibleTime, float invisibleTime,
			ComponentScope scope, GetFloat deltaTime)
		{
			this.Clear();

			this.blinkCount = blinkCount;
			this.visibleTime = visibleTime;
			this.invisibleTime = invisibleTime;
			this.deltaTime = deltaTime;

			if(ComponentHelper.IsSingleScope(scope))
			{
				this.rendererSingle = ComponentHelper.GetSingle<Renderer>(this.gameObject, scope);
				this.projectorSingle = ComponentHelper.GetSingle<Projector>(this.gameObject, scope);
			}
			else
			{
				this.renderers = ComponentHelper.GetAll<Renderer>(this.gameObject, scope);
				this.projectors = ComponentHelper.GetAll<Projector>(this.gameObject, scope);
			}

			this.DoBlink(startState);

			this.IsBlinking(true);
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.isBlinking && !Maki.Game.Paused)
			{
				this.currentTime += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();

				if((this.currentState && this.currentTime >= this.visibleTime) ||
					(!this.currentState && this.currentTime >= this.invisibleTime))
				{
					this.DoBlink(!this.currentState);
					this.currentTime = 0;
					this.currentCount++;

					if(this.currentCount >= this.blinkCount)
					{
						this.IsBlinking(false);
					}
				}
			}
		}

		protected virtual void DoBlink(bool isVisible)
		{
			// renderer
			if(this.rendererSingle != null)
			{
				this.rendererSingle.enabled = isVisible;
			}
			else if(this.renderers != null)
			{
				for(int i = 0; i < this.renderers.Length; i++)
				{
					this.renderers[i].enabled = isVisible;
				}
			}
			// projector
			if(this.projectorSingle != null)
			{
				this.projectorSingle.enabled = isVisible;
			}
			else if(this.projectors != null)
			{
				for(int i = 0; i < this.projectors.Length; i++)
				{
					this.projectors[i].enabled = isVisible;
				}
			}
			this.currentState = isVisible;
		}
	}
}
