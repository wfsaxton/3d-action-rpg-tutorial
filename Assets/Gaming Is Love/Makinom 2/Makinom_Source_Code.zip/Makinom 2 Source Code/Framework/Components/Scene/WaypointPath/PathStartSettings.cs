
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PathStartSettings : BaseData
	{
		[EditorHelp("Start Position", "Select where the game object will start following the path:\n" +
			"- Start: At the start of the path (i.e. the first path point).\n" +
			"- End: At the end of the path (i.e. the last path point).\n" +
			"- Nearest: At the path position closest to the game object.\n" +
			"- Path Point: At a defined path point.", "")]
		public PathStartType type = PathStartType.Start;

		[EditorHelp("Reverse Direction", "Reverse the direction in which the path is followed, " +
			"i.e. move from highest to lowest path point index.\n" +
			"If disabled, the path is followed from lowest to highest path point index.", "")]
		public bool reverseDirection = false;


		// path point
		[EditorHelp("Path Point Index", "Define the index of the path point.\n" +
			"If the index exceeds the number of path points, the last path point will be used.", "")]
		[EditorLimit(0)]
		[EditorCondition("type", PathStartType.PathPoint)]
		public int pointIndex = 0;

		[EditorHelp("Path Value (0-1)", "The position on the path point's length, " +
			"where 0 is the position of the current path point and 1 is the position of the next path point.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorEndCondition]
		public float pathValue = 0;


		// path end
		[EditorHelp("Path End", "Select what will happen at the path's end:\n" +
			"- Stop: The game object will stop at the end.\n" +
			"- Loop: The game object will continue following the path.\n" +
			"- Reverse: The game object will reverse direction and continue following the path.", "")]
		public PathEndType endType = PathEndType.Stop;

		public PathStartSettings()
		{

		}

		public void GetStartPoint(WaypointPathComponent path, Vector3 userPosition, ref int index, ref float value)
		{
			if(PathStartType.Start == this.type)
			{
				index = 0;
				value = 0;
			}
			else if(PathStartType.End == this.type)
			{
				index = path.pathPoint.Length - 1;
				value = 0;
			}
			else if(PathStartType.Nearest == this.type)
			{
				Vector3 tmp = Vector3.zero;
				path.FindNearestPosition(userPosition, ref index, ref value, ref tmp);
			}
			else if(PathStartType.PathPoint == this.type)
			{
				index = Mathf.Min(this.pointIndex, path.pathPoint.Length - 1);
				if(index == path.pathPoint.Length - 1 && !path.loopPath)
				{
					value = 0;
				}
				else
				{
					value = this.pathValue;
				}
			}
		}
	}
}
