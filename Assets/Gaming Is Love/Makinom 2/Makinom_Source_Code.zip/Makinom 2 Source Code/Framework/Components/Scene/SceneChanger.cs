
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	public delegate void SceneChangeInfoNotify(bool inOldScene, bool beforeFade, GlobalMachineSceneChangeType loadType, string customType);

	[AddComponentMenu("Makinom/Scenes/Scene Changer")]
	public class SceneChanger : BaseInteractionComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected SceneTargetInstance target;

		protected bool delayLoaded = false;

		protected bool check = false;

		protected DataObject saveGameData = null;

		protected Vector3 spawnOffset = Vector3.zero;


		// notify
		protected Notify notifySceneLoaded;

		protected Notify notifyFinished;

		protected GameObject startingObject;

		protected ISchematicStarter starter;

		protected bool spawnStarterObject = false;

		protected virtual void Reset()
		{
			this.startSettings.triggerStartSetting.isTriggerEnter = true;
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public virtual void NotifySceneLoaded(Notify notify)
		{
			this.notifySceneLoaded = notify;
		}

		public virtual void NotifyFinished(Notify notify)
		{
			this.notifyFinished = notify;
		}

		public virtual void SetStarter(ISchematicStarter starter, bool spawnStarterObject)
		{
			this.starter = starter;
			this.spawnStarterObject = spawnStarterObject;
		}

		public virtual bool DelayLoaded
		{
			get { return this.delayLoaded; }
			set { this.delayLoaded = value; }
		}

		public virtual SceneTargetInstance Target
		{
			get { return this.target; }
			set { this.target = value; }
		}


		/*
		============================================================================
		Load game functions
		============================================================================
		*/
		public virtual void LoadSaveGame(string sceneName, DataObject data, int spawnID)
		{
			this.target = new SceneTargetInstance(sceneName, spawnID);
			this.target.loadType = Maki.SaveGameSettings.loadType;
			this.saveGameData = data;
			this.settings.ownScreenFade = Maki.SaveGameSettings.ownScreenFade;
			this.settings.screenFade = Maki.SaveGameSettings.screenFade;
		}


		/*
		============================================================================
		Scene change functions
		============================================================================
		*/
		public override void StartInteraction(GameObject startingObject)
		{
			if(!this.isStarted)
			{
				this.DoTurns(startingObject);

				this.CancelAutoDestroy();
				this.isStarted = true;
				this.startingObject = startingObject;

				if(this.saveGameData != null)
				{
					Maki.Control.Clear();
				}
				this.StartCoroutine(this.ChangeScene(startingObject));
			}
		}

		protected virtual IEnumerator ChangeScene(GameObject startingObject)
		{
			if(this.target == null)
			{
				int index = UnityWrapper.Range(0, this.settings.target.Length);
				this.target = this.settings.target[index].Create(this.settings.target[index].NeedsCall ? 
					new DataCall(this.gameObject, startingObject) : null);
			}

			if(this.target != null &&
				this.target.Exists)
			{
				Maki.Control.SetChangingScene(1);

				if(startingObject == null)
				{
					startingObject = Maki.Game.Player.GameObject;
				}

				if(this.settings.useSpawnOffset &&
					startingObject != null)
				{
					this.spawnOffset = startingObject.transform.position - this.transform.position;
					if(this.settings.ignoreOffsetAxes.x)
					{
						this.spawnOffset.x = 0;
					}
					if(this.settings.ignoreOffsetAxes.y)
					{
						this.spawnOffset.y = 0;
					}
					if(this.settings.ignoreOffsetAxes.z)
					{
						this.spawnOffset.z = 0;
					}
				}

				this.transform.SetParent(null);
				GameObject.DontDestroyOnLoad(this.transform.root);

				if(this.settings.blockPlayerControl)
				{
					Maki.Control.SetBlockPlayer(1, true);
				}
				if(this.settings.blockCameraControl)
				{
					Maki.Control.SetBlockCamera(1, true);
				}

				// play audio
				if(this.settings.audioClip != null &&
					ComponentHelper.PlayOneShot(this.gameObject, this.settings.audioClip, this.settings.volume) &&
					this.settings.waitForAudio)
				{
					yield return new WaitForSeconds(this.settings.audioClip.length);
				}

				// load type
				GlobalMachineSceneChangeType loadType = GlobalMachineSceneChangeType.SceneChange;
				if(this.saveGameData != null)
				{
					loadType = GlobalMachineSceneChangeType.LoadGame;
				}
				else if(this.settings.useCustomChangeType)
				{
					loadType = GlobalMachineSceneChangeType.Custom;
				}
				Maki.Control.FireSceneChangeInfo(true, true, loadType, this.settings.customChangeType);

				// fade screen
				if(this.settings.ownScreenFade &&
					this.settings.screenFade != null)
				{
					if(this.settings.screenFade.useFadeOut &&
						this.settings.screenFade.fadeOut != null)
					{
						Maki.UI.ScreenFader.FadeScreen(this.settings.screenFade.fadeOut);
						yield return new WaitForSeconds(this.settings.screenFade.fadeOut.time);
					}
				}
				else if(Maki.GameSettings.defaultScreenFade.useFadeOut &&
					Maki.GameSettings.defaultScreenFade.fadeOut != null)
				{
					Maki.UI.ScreenFader.FadeScreen(Maki.GameSettings.defaultScreenFade.fadeOut);
					yield return new WaitForSeconds(Maki.GameSettings.defaultScreenFade.fadeOut.time);
				}
				this.check = true;

				Maki.Control.FireSceneChangeInfo(true, false, loadType, this.settings.customChangeType);

				yield return null;

				if(Maki.GameControls.player.sceneChangeDestroyPlayer &&
					Maki.Game.Player.GameObject != null)
				{
					UnityWrapper.Destroy(Maki.Game.Player.GameObject);
				}

				// load scene
				if(this.target.LoadScene())
				{
					this.delayLoaded = true;
					this.StartCoroutine(this.OnSceneLoaded2());
					Maki.Instance.FireSceneLoaded();
				}
				else
				{
					Maki.Instance.SceneLoaded += this.OnSceneLoaded;
				}
			}
			else
			{
				this.isStarted = false;
			}
		}

		protected virtual void OnSceneLoaded()
		{
			if(this.target != null &&
				this.target.IsLoaded)
			{
				Maki.Instance.SceneLoaded -= this.OnSceneLoaded;
				this.StartCoroutine(this.OnSceneLoaded2());
			}
		}

		protected virtual IEnumerator OnSceneLoaded2()
		{
			if(this.check)
			{
				if(this.notifySceneLoaded != null)
				{
					this.notifySceneLoaded();
				}
				if(this.delayLoaded)
				{
					yield return null;
				}

				GlobalMachineSceneChangeType loadType = GlobalMachineSceneChangeType.SceneChange;
				if(this.saveGameData != null)
				{
					loadType = GlobalMachineSceneChangeType.LoadGame;
					Maki.SaveGame.Loaded(this.saveGameData);
					Maki.Game.Running = true;
				}
				else if(this.settings.useCustomChangeType)
				{
					loadType = GlobalMachineSceneChangeType.Custom;
				}

				if(this.settings.changeAfterSetting.HasVariables)
				{
					this.settings.changeAfterSetting.SetVariables(
						new DataCall(this.gameObject, Maki.Game.Player.GameObject));
				}

				if(this.starter is Schematic &&
					this.spawnStarterObject &&
					((Schematic)this.starter).MachineObject != null)
				{
					Schematic schematic = (Schematic)this.starter;

					this.target.Spawn(schematic.MachineObject.GetFirst(schematic),
						this.settings.useSpawnOffset ? this.spawnOffset : Vector3.zero);
				}
				else
				{
					this.target.SpawnPlayer(
						this.settings.useSpawnOffset ? this.spawnOffset : Vector3.zero);
				}

				if(this.settings.ownScreenFade && this.settings.screenFade != null ?
					(!this.settings.screenFade.useFadeIn ||
						this.settings.screenFade.fadeIn == null ||
						!this.settings.screenFade.waitFadeIn) :
					(!Maki.GameSettings.defaultScreenFade.useFadeIn ||
						Maki.GameSettings.defaultScreenFade.fadeIn == null ||
						!Maki.GameSettings.defaultScreenFade.waitFadeIn))
				{
					if(this.settings.blockPlayerControl)
					{
						Maki.Control.SetBlockPlayer(-1, true);
					}
					if(this.settings.blockCameraControl)
					{
						Maki.Control.SetBlockCamera(-1, true);
					}
				}

				Maki.Control.FireSceneChangeInfo(false, true, loadType, this.settings.customChangeType);

				// fade in
				if(this.settings.ownScreenFade &&
					this.settings.screenFade != null)
				{
					if(this.settings.screenFade.useFadeIn &&
						this.settings.screenFade.fadeIn != null)
					{
						Maki.UI.ScreenFader.FadeScreen(this.settings.screenFade.fadeIn);
						if(this.settings.screenFade.waitFadeIn)
						{
							yield return new WaitForSeconds(this.settings.screenFade.fadeIn.time);
							if(this.settings.blockPlayerControl)
							{
								Maki.Control.SetBlockPlayer(-1, true);
							}
							if(this.settings.blockCameraControl)
							{
								Maki.Control.SetBlockCamera(-1, true);
							}
						}
					}
				}
				else if(Maki.GameSettings.defaultScreenFade.useFadeIn &&
					Maki.GameSettings.defaultScreenFade.fadeIn != null)
				{
					Maki.UI.ScreenFader.FadeScreen(Maki.GameSettings.defaultScreenFade.fadeIn);
					if(Maki.GameSettings.defaultScreenFade.waitFadeIn)
					{
						yield return new WaitForSeconds(Maki.GameSettings.defaultScreenFade.fadeIn.time);
						if(this.settings.blockPlayerControl)
						{
							Maki.Control.SetBlockPlayer(-1, true);
						}
						if(this.settings.blockCameraControl)
						{
							Maki.Control.SetBlockCamera(-1, true);
						}
					}
				}

				Maki.Control.FireSceneChangeInfo(false, false, loadType, this.settings.customChangeType);

				yield return null;

				Maki.Control.SetChangingScene(-1);

				if(this.notifyFinished != null)
				{
					this.notifyFinished();
				}
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.SchematicFinished(null);
				}

				UnityWrapper.Destroy(this.gameObject);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/SceneChanger Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// control blocks
			[EditorHelp("Block Player Control", "Block the player controls while changing scenes.")]
			[EditorFoldout("Scene Settings", "Define which scene will be changed to.", "")]
			public bool blockPlayerControl = true;

			[EditorHelp("Block Camera Control", "Block the camera controls while changing scenes.")]
			public bool blockCameraControl = true;


			// scene settings
			[EditorHelp("Use Spawn Offset", "Optionally use the offset from the player " +
				"to the scene changer when spawning in the new scene.")]
			[EditorSeparator]
			public bool useSpawnOffset = false;

			[EditorHelp("Ignore Offset", "Ignore the offset on the enabled axes.")]
			[EditorLabel("The offset from the player to the scene changer " +
				"will be added to the spawn position in the new scene (both in world space).")]
			[EditorCondition("useSpawnOffset", true)]
			[EditorEndCondition]
			public AxisBool ignoreOffsetAxes = new AxisBool();

			[EditorHelp("Use Custom Change Type", "Use a custom scene change type.\n" +
				"This can be used by global machines with the 'Scene' global machine type to start automatically.")]
			[EditorSeparator]
			public bool useCustomChangeType = false;

			[EditorHelp("Custom Type", "Define the custom type.\n" +
				"Global machine with the same custom type will be started.")]
			[EditorWidth(true)]
			[EditorIndent]
			[EditorCondition("useCustomChangeType", true)]
			[EditorEndCondition]
			public string customChangeType = "";

			[EditorArray("Add Target Scene", "Adds a target scene.", "",
				"Remove", "Removes this target scene.", "",
				isCopy=true, isMove=true, noRemoveCount=1,
				foldout=true, foldoutText=new string[] {
					"Target Scene", "Define the target scene and load type.", ""
				})]
			public SceneTarget<GameObjectSelection>[] target = new SceneTarget<GameObjectSelection>[] {
				new SceneTarget<GameObjectSelection>()
			};


			// audio
			[EditorHelp("Audio Clip", "Select an audio clip that will be played when changing scenes.\n" +
				"Uses an 'AudioSource' component attached to the same game object.")]
			[EditorTitleLabel("Audio Settings")]
			[EditorSeparator]
			public AudioClip audioClip;

			[EditorHelp("Volume", "The volume used to play the audio clip.")]
			[EditorLimit(0.0f, 1.0f, isSlider=true)]
			[EditorCondition("audioClip", null)]
			[EditorElseCondition]
			public float volume = 1;

			[EditorHelp("Wait For Audio", "Wait for the audio clip to finish before changing scenes.")]
			[EditorEndFoldout]
			[EditorEndCondition]
			public bool waitForAudio = false;


			// screen fade
			[EditorHelp("Own Screen Fade", "Use different screen fade settings for this scene changer.\n" +
				"If disabled, it'll use the default screen fade settings defined in the game settings.")]
			[EditorFoldout("Screen Fade Settings", "Optionally use a different screen fading for this scene changer.", "")]
			public bool ownScreenFade = false;

			[EditorEndFoldout]
			[EditorCondition("ownScreenFade", true)]
			[EditorAutoInit]
			[EditorEndCondition]
			public ScreenFadeSettings screenFade;


			// change after scene change
			[EditorFoldout("Change After Load", "Optionally change variables after changing scenes.", "")]
			[EditorEndFoldout]
			public MachineChangeAfterSetting changeAfterSetting = new MachineChangeAfterSetting();

			public Settings()
			{

			}
		}
	}
}