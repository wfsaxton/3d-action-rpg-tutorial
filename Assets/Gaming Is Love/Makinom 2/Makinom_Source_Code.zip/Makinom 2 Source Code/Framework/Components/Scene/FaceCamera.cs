﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Face Camera (2D, UI)")]
	public class FaceCamera : MonoBehaviour
	{
		[Tooltip("Face the camera currently registered by Makinom as the main camera.\n" +
			"Otherwise uses 'Camera.main'.")]
		public bool makinomCamera = true;

		protected virtual void LateUpdate()
		{
			Camera camera = this.makinomCamera && Maki.Game.Camera != null ? 
				Maki.Game.Camera : Camera.main;
			if(camera != null)
			{
				this.transform.forward = camera.transform.forward;
			}
		}
	}
}
