﻿
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class PrefabSaverComponent : MonoBehaviour, ISaveData
	{
		// in-game
		protected string sceneName = "";

		public static List<PrefabSaverComponent> Registered = new List<PrefabSaverComponent>();

		protected PrefabSaver prefabSaver;

		protected virtual void Awake()
		{
			this.sceneName = SceneManager.GetActiveScene().name;
		}

		public virtual PrefabSaver PrefabSaver
		{
			get { return this.prefabSaver; }
			set
			{
				if(this.prefabSaver != value)
				{
					this.prefabSaver = value;
					if(this.prefabSaver != null)
					{
						PrefabSaverComponent.Registered.Add(this);
					}
					else
					{
						PrefabSaverComponent.Registered.Remove(this);
					}
				}
			}
		}

		protected virtual void OnDestroy()
		{
			if(this.prefabSaver != null)
			{
				if(Maki.Initialized &&
					Maki.Game.Running &&
					Maki.SaveGame != null &&
					!Maki.SaveGame.IsLoading)
				{
					this.Save();
				}
				PrefabSaverComponent.Registered.Remove(this);
			}
		}

		public static void Remove(GameObject instance, bool removeComponent)
		{
			PrefabSaverComponent saver = instance.GetComponent<PrefabSaverComponent>();
			if(saver != null)
			{
				saver.PrefabSaver = null;
				if(removeComponent)
				{
					GameObject.Destroy(saver);
				}
			}
		}

		public static void RemoveAll()
		{
			List<PrefabSaverComponent> list = new List<PrefabSaverComponent>(PrefabSaverComponent.Registered);
			for(int i=0; i<list.Count; i++)
			{
				list[i].PrefabSaver = null;
				GameObject.Destroy(list[i]);
			}
		}

		public static void RemoveAll(PrefabSaver prefabSaver)
		{
			List<PrefabSaverComponent> list = new List<PrefabSaverComponent>(PrefabSaverComponent.Registered);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].prefabSaver == prefabSaver)
				{
					list[i].PrefabSaver = null;
					GameObject.Destroy(list[i]);
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual void Save()
		{
			if(this.prefabSaver != null)
			{
				Maki.Game.Scene.AddPrefabSaverData(this.sceneName, this.prefabSaver, this.SaveGame());
			}
		}

		public virtual DataObject SaveGame()
		{
			if(this.prefabSaver != null)
			{
				return this.prefabSaver.saveSettings.SaveGame(this.gameObject);
			}
			return null;
		}

		public virtual void LoadGame(DataObject data)
		{
			if(this.prefabSaver != null)
			{
				this.prefabSaver.saveSettings.LoadGame(this.gameObject, data);
			}
		}
	}
}
