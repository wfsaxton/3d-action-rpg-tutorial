﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Controls/Is Makinom Camera")]
	public class IsMakinomCamera : MonoBehaviour
	{
		public Camera cameraComponent;

		protected virtual void Reset()
		{
			this.cameraComponent = this.GetComponentInChildren<Camera>();
		}

		public virtual void SetCamera()
		{
			if(Maki.Initialized)
			{
				Maki.Game.Camera = this.cameraComponent;
			}
		}

		protected virtual void OnEnable()
		{
			this.SetCamera();
		}

		protected virtual void Start()
		{
			this.SetCamera();
		}
	}
}
