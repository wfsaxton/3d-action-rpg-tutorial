
using UnityEngine;
using UnityEngine.Audio;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicFieldCheck : BaseData
	{
		// field
		[EditorHelp("Field Name", "The name of the field that will be checked.", "")]
		[EditorHide]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Field, typeof(Component))]
		public string fieldName = "";

		[EditorHelp("Is Property", "Check the value of a property.\n" +
			"If disabled, the value of a field will be checked.", "")]
		public bool isProperty = false;

		[EditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[EditorHelp("Array Index", "The index of the array that will be used.", "")]
		[EditorCondition("isArray", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public FloatValue<SchematicObjectSelection> arrayIndex;

		[EditorHelp("Field Type", "Select the type of the field or proparty:\n" +
			"- String: A string value.\n" +
			"- Bool: A bool value.\n" +
			"- Int: An integer value.\n" +
			"- Float: A float value.\n" +
			"- Vector2: A Vector2 value (uses a Vector3, but only the X and Y axes).\n" +
			"- Vector3: A Vector3 value.\n" +
			"- Quaternion: A Quaternion value (uses a Vector3 as euler angles).\n" +
			"- Color: A color.\n" +
			"- Layer Mask: A layer mask.\n" +
			"- Game Object: A game object.\n" +
			"- Prefab: A prefab.\n" +
			"- Audio Clip: An audio clip.\n" +
			"- Audio Mixer: An audio mixer.\n" +
			"- Audio Mixer Group: An audio mixer group.\n" +
			"- Sprite: A sprite.\n" +
			"- Texture: A texture.\n" +
			"- Material: A material.\n" +
			"- Physic Material: A physic material.\n" +
			"- Physics Material 2D: A 2D physics material.\n" +
			"- Component: A component (attached to a game object).\n" +
			"- Enum: An enumeration.\n" +
			"- Transform: The transform of a game object.", "")]
		public ParameterType type = ParameterType.String;


		// values
		// string
		[EditorHelp("String Value", "Define the string that will be used.", "")]
		[EditorCondition("type", ParameterType.String)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StringValue<SchematicObjectSelection> stringValue;


		// bool
		[EditorTitleLabel("Bool Value")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.Bool)]
		[EditorEndCondition]
		[EditorAutoInit]
		public BoolValue<SchematicObjectSelection> boolValue;


		// enum
		[EditorHelp("Enum Name", "The name of the enumeration.\n" +
			"An int value will be used as the enum value.", "")]
		[EditorCondition("type", ParameterType.Enum)]
		[EditorEndCondition]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Enum)]
		public string enumName = "";


		// int, float
		[EditorHelp("Int/Float Value", "Define the int/float value that will be used.", "")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.Int)]
		[EditorCondition("type", ParameterType.Float)]
		[EditorCondition("type", ParameterType.Enum)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<SchematicObjectSelection> floatValue;


		// vector3, vector3, quaternion
		[EditorTitleLabel("Vector2/Vector3/Quaternion Value")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.Vector2)]
		[EditorCondition("type", ParameterType.Vector3)]
		[EditorCondition("type", ParameterType.Quaternion)]
		[EditorEndCondition]
		[EditorAutoInit]
		public Vector3Value<SchematicObjectSelection> vector3Value;


		// color
		[EditorHelp("Color", "Select the color that will be used.", "")]
		[EditorCondition("type", ParameterType.Color)]
		[EditorEndCondition]
		public Color color = Color.white;


		// layer mask
		[EditorHelp("Layer Mask", "Select the layers that will be used.", "")]
		[EditorCondition("type", ParameterType.LayerMask)]
		[EditorEndCondition]
		public LayerMask layerMask = -1;


		// game object, component, transform
		[EditorTitleLabel("Game Object")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.GameObject)]
		[EditorCondition("type", ParameterType.Component)]
		[EditorCondition("type", ParameterType.Transform)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicObjectSelection gameObject;

		// component
		[EditorHelp("Component Name", "The name of the component.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		[EditorCondition("type", ParameterType.Component)]
		public string componentName = "";

		[EditorHelp("Scope", "Select the scope of the component that will be used:\n" +
			"- In Object: A component attached to the game object.\n" +
			"- In Children: A component attached to the game object or any child object.\n" +
			"- In Parent: A component attached to the game object or any parent object.\n" +
			"- From Root: A component attached to the game object's root or any child object (from the root).", "")]
		[EditorEndCondition]
		public ComponentScopeSingle componentScope = ComponentScopeSingle.InObject;


		// prefab
		[EditorHelp("Prefab", "Select the prefab that will be used.", "")]
		[EditorInfo(isTabPopup=true, tabPopupID=2)]
		[EditorCondition("type", ParameterType.Prefab)]
		[EditorEndCondition]
		public int prefab;


		// audio clip
		[EditorHelp("Audio Clip", "Select the audio clip that will be used.", "")]
		[EditorCondition("type", ParameterType.AudioClip)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicAudioClipSelection audioClip;


		// audio mixer
		[EditorHelp("Audio Mixer", "Select the audio mixer that will be used.", "")]
		[EditorCondition("type", ParameterType.AudioMixer)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicAudioMixerSelection audioMixer;


		// audio mixer group
		[EditorHelp("Audio Mixer Group", "Select the audio mixer group that will be used.", "")]
		[EditorCondition("type", ParameterType.AudioMixerGroup)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicAudioMixerGroupSelection audioMixerGroup;


		// sprite
		[EditorHelp("Sprite", "Select the sprite that will be used.", "")]
		[EditorCondition("type", ParameterType.Sprite)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicSpriteSelection sprite;


		// texture
		[EditorHelp("Texture", "Select the texture that will be used.", "")]
		[EditorCondition("type", ParameterType.Texture)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicTextureSelection texture;


		// material
		[EditorHelp("Material", "Select the material that will be used.", "")]
		[EditorCondition("type", ParameterType.Material)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicMaterialSelection material;


		// physic material
		[EditorHelp("Physic Material", "Select the physic material that will be used.", "")]
		[EditorCondition("type", ParameterType.PhysicMaterial)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicPhysicMaterialSelection physicMaterial;


		// physics material 2d
		[EditorHelp("Physics Material 2D", "Select the 2d physics material that will be used.", "")]
		[EditorCondition("type", ParameterType.PhysicsMaterial2D)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SchematicPhysicsMaterial2DSelection physicMaterial2D;

		public SchematicFieldCheck()
		{

		}

		public object GetValue(Schematic schematic)
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue(schematic);
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue.GetValue(schematic);
			}
			else if(ParameterType.Int == this.type)
			{
				return (int)this.floatValue.GetValue(schematic);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(schematic);
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return (Vector2)this.vector3Value.GetValue(schematic);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vector3Value.GetValue(schematic);
			}
			else if(ParameterType.Quaternion == this.type)
			{
				return Quaternion.Euler(this.vector3Value.GetValue(schematic));
			}
			else if(ParameterType.Color == this.type)
			{
				return this.color;
			}
			else if(ParameterType.LayerMask == this.type)
			{
				return this.layerMask;
			}
			else if(ParameterType.GameObject == this.type)
			{
				return this.gameObject.GetObject(schematic);
			}
			else if(ParameterType.Prefab == this.type)
			{
				return schematic.GetPrefab(this.prefab);
			}
			else if(ParameterType.AudioClip == this.type)
			{
				return this.audioClip.GetAudioClip(schematic);
			}
			else if(ParameterType.AudioMixer == this.type)
			{
				return this.audioMixer.GetAudioMixer(schematic);
			}
			else if(ParameterType.AudioMixerGroup == this.type)
			{
				return this.audioMixerGroup.GetAudioMixerGroup(schematic);
			}
			else if(ParameterType.Sprite == this.type)
			{
				return this.sprite.GetSprite(schematic);
			}
			else if(ParameterType.Texture == this.type)
			{
				return this.texture.GetTexture(schematic);
			}
			else if(ParameterType.Material == this.type)
			{
				return this.material.GetMaterial(schematic);
			}
			else if(ParameterType.PhysicMaterial == this.type)
			{
				return this.physicMaterial.GetPhysicMaterial(schematic);
			}
			else if(ParameterType.PhysicsMaterial2D == this.type)
			{
				return this.physicMaterial2D.GetPhysicsMaterial2D(schematic);
			}
			else if(ParameterType.Component == this.type)
			{
				List<GameObject> list = this.gameObject.GetObjects(schematic);
				Component component = ComponentHelper.Get(list, this.componentScope, this.componentName);
				Maki.Pooling.GameObjectLists.Add(list);
				return component;
			}
			else if(ParameterType.Enum == this.type)
			{
				return (int)this.floatValue.GetValue(schematic);
			}
			else if(ParameterType.Transform == this.type)
			{
				GameObject tmpObject = this.gameObject.GetObject(schematic);
				if(tmpObject != null)
				{
					return tmpObject.transform;
				}
			}
			return null;
		}

		private bool CheckArrayValue(Schematic schematic, object value)
		{
			System.Array array = value as System.Array;
			if(array != null)
			{
				object checkValue = ParameterType.Enum == this.type ?
					(int)array.GetValue((int)this.arrayIndex.GetValue(schematic)) :
					array.GetValue((int)this.arrayIndex.GetValue(schematic));
				return checkValue != null && checkValue.Equals(this.GetValue(schematic));
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					object checkValue = ParameterType.Enum == this.type ?
						(int)list[(int)this.arrayIndex.GetValue(schematic)] :
						list[(int)this.arrayIndex.GetValue(schematic)];
					return checkValue != null && checkValue.Equals(this.GetValue(schematic));
				}
			}
			return false;
		}

		public bool Check(object instance, System.Type instanceType, Schematic schematic, bool isStatic)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
						this.fieldName, ref instance, ref instanceType);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(schematic,
									propertyInfo.GetValue(isStatic ? null : instance, null));
							}
							else
							{
								object value = ParameterType.Enum == this.type ?
									(int)propertyInfo.GetValue(isStatic ? null : instance, null) :
									propertyInfo.GetValue(isStatic ? null : instance, null);
								return value != null && value.Equals(this.GetValue(schematic));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
						this.fieldName, ref instance, ref instanceType);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(schematic,
									fieldInfo.GetValue(isStatic ? null : instance));
							}
							else
							{
								object value = ParameterType.Enum == this.type ?
									(int)fieldInfo.GetValue(isStatic ? null : instance) :
									fieldInfo.GetValue(isStatic ? null : instance);
								return value != null && value.Equals(this.GetValue(schematic));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
			return false;
		}

		public override string ToString()
		{
			if(ParameterType.String == this.type)
			{
				return this.fieldName + " == " + this.stringValue.ToString();
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.fieldName + " == " + this.boolValue.ToString();
			}
			else if(ParameterType.Int == this.type ||
				ParameterType.Float == this.type)
			{
				return this.fieldName + " == " + this.floatValue.ToString();
			}
			else if(ParameterType.Vector2 == this.type ||
				ParameterType.Vector3 == this.type ||
				ParameterType.Quaternion == this.type)
			{
				return this.fieldName + " == " + this.vector3Value.ToString();
			}
			else if(ParameterType.Color == this.type)
			{
				return this.fieldName + " == Color";
			}
			else if(ParameterType.LayerMask == this.type)
			{
				return this.fieldName + " == Layer Mask";
			}
			else if(ParameterType.GameObject == this.type ||
				ParameterType.Transform == this.type)
			{
				return this.fieldName + " == " + this.gameObject.ToString();
			}
			else if(ParameterType.Prefab == this.type)
			{
				return this.fieldName + " == " + "Prefab " + this.prefab;
			}
			else if(ParameterType.AudioClip == this.type)
			{
				return this.fieldName + " == " + this.audioClip.ToString();
			}
			else if(ParameterType.AudioMixer == this.type)
			{
				return this.fieldName + " == " + this.audioMixer.ToString();
			}
			else if(ParameterType.AudioMixerGroup == this.type)
			{
				return this.fieldName + " == " + this.audioMixerGroup.ToString();
			}
			else if(ParameterType.Sprite == this.type)
			{
				return this.fieldName + " == " + this.sprite.ToString();
			}
			else if(ParameterType.Texture == this.type)
			{
				return this.fieldName + " == " + this.texture.ToString();
			}
			else if(ParameterType.Material == this.type)
			{
				return this.fieldName + " == " + this.material.ToString();
			}
			else if(ParameterType.PhysicMaterial == this.type)
			{
				return this.fieldName + " == " + this.physicMaterial.ToString();
			}
			else if(ParameterType.PhysicsMaterial2D == this.type)
			{
				return this.fieldName + " == " + this.physicMaterial2D.ToString();
			}
			else if(ParameterType.Component == this.type)
			{
				return this.fieldName + "== " + this.componentName +
					"(" + this.gameObject.ToString() + ")";
			}
			else if(ParameterType.Enum == this.type)
			{
				return this.fieldName + " == " + this.enumName +
					" " + this.floatValue.ToString();
			}
			return "";
		}
	}
}
