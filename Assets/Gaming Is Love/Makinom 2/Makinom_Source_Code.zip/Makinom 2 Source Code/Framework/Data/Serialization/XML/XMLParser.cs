
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.IO
{
	public class XMLParser
	{
		private string xmlData;

		private AssetLookUp lookUp;

		private int start = 0;

		private int end = 0;

		private int pos = 0;

		private int pos2 = 0;

		private int space = 0;

		private static System.Globalization.CultureInfo cultureInfo = System.Globalization.CultureInfo.InvariantCulture;

		public XMLParser(string xml, AssetLookUp lu)
		{
			this.xmlData = xml;
			this.lookUp = lu;
		}


		/*
		============================================================================
		Parse functions
		============================================================================
		*/
		public DataObject Parse()
		{
			System.Globalization.CultureInfo tmp = System.Threading.Thread.CurrentThread.CurrentCulture;
			System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
			DataObject data = this.DoParse();
			System.Threading.Thread.CurrentThread.CurrentCulture = tmp;
			return data;
		}

		private DataObject DoParse()
		{
			DataObject data = new DataObject();

			try
			{
				if(this.NextNode())
				{
					this.start++;
					space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
					string name = "";
					string exitName = "/" + this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

					// int
					if(space > this.start)
					{
						do
						{
							this.start = space + 1;
							space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
							if(space != -1)
							{
								// key (pos), value (pos2)
								pos = this.xmlData.IndexOf('=', this.start, space - this.start);
								pos2 = pos + 2;
								data.Set(this.xmlData.Substring(this.start, pos - this.start),
									int.Parse(this.xmlData.Substring(pos2, space - 1 - pos2)));
							}
						} while(space != -1);
					}

					while(this.start != -1)
					{
						if(this.NextNode())
						{
							this.start++;
							// name
							space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
							name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

							// sub
							if(name[0] == '_')
							{
								if(space > this.start)
								{
									// bool
									//if(name == XMLName.BOOL)
									if(name[1] == 'b')
									{
										do
										{
											this.start = space + 1;
											space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
											if(space != -1)
											{
												// key (pos), value (pos2)
												pos = this.xmlData.IndexOf('=', this.start, space - this.start);
												pos2 = pos + 2;
												data.Set(this.xmlData.Substring(this.start, pos - this.start),
													bool.Parse(this.xmlData.Substring(pos2, space - 1 - pos2)));
											}
										} while(space != -1);
									}
									// float
									else if(name[1] == 'f')
									{
										do
										{
											this.start = space + 1;
											space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
											if(space != -1)
											{
												// key (pos), value (pos2)
												pos = this.xmlData.IndexOf('=', this.start, space - this.start);
												pos2 = pos + 2;
												data.Set(this.xmlData.Substring(this.start, pos - this.start),
													float.Parse(this.xmlData.Substring(pos2, space - 1 - pos2), cultureInfo));
											}
										} while(space != -1);
									}
									// assets
									else if(name[1] == 'a')
									{
										do
										{
											this.start = space + 1;
											space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
											if(space != -1)
											{
												// key (pos), value (pos2)
												pos = this.xmlData.IndexOf('=', this.start, space - this.start);
												pos2 = pos + 2;
												if(lookUp != null)
												{
													data.SetAsset(this.xmlData.Substring(this.start, pos - this.start),
														lookUp.GetAsset(int.Parse(this.xmlData.Substring(pos2, space - 1 - pos2))));
												}
											}
										} while(space != -1);
									}
									// sub
									else
									{
										this.start--;
										this.end = this.start;
										data.Set(name, this.DoParse());
									}
								}
								else if(name[1] == 's')
								{
									// sub arrays
									//else if(name == XMLName.SUB_ARRAYS)
									if(name.Length == 10)//[2] == 'u')
									{
										do
										{
											if(this.NextNode())
											{
												this.start++;
												// name
												space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
												name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

												if(name != XMLName.SUB_ARRAYS_CL)
												{
													string subName = name;
													string closeName = "/" + name;
													List<DataObject> dataObjectArray = new List<DataObject>();
													do
													{
														if(this.NextNode())
														{
															this.start++;
															// name
															space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
															name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

															if(name != closeName)
															{
																this.start--;
																this.end = this.start;
																dataObjectArray.Add(this.DoParse());
															}
														}
														else
														{
															break;
														}
													} while(name[0] != '/');
													data.Set(subName, dataObjectArray.ToArray());
												}
											}
											else
											{
												break;
											}
										} while(name[0] != '/' || name != XMLName.SUB_ARRAYS_CL);
									}
									// strings
									//else if(name == XMLName.STRING)
									else if(name.Length == 7)
									{
										do
										{
											if(this.NextNode())
											{
												this.start++;
												// name
												space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
												name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

												if(name[0] != '/')
												{
													if(this.NextNode())
													{
														// start at the end of <![CDATA[
														this.start += 9;
														this.end = this.xmlData.IndexOf("]]>", this.start, System.StringComparison.Ordinal);
														data.Set(name,
															this.xmlData.Substring(this.start, this.end - this.start));
														this.end += 3;
														this.NextNode();
													}
												}
											}
											else
											{
												break;
											}
										} while(name[0] != '/');
									}
									// string arrays
									//else if(name == XMLName.STRING_ARRAYS)
									else
									{
										do
										{
											if(this.NextNode())
											{
												this.start++;
												// name
												space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
												name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

												if(name != XMLName.STRING_ARRAYS_CL)
												{
													string subName = name;
													string closeName = "/" + name;
													List<string> stringArray = new List<string>();
													do
													{
														if(this.NextNode())
														{
															this.start++;
															// name
															space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
															name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

															if(name != closeName)
															{
																if(this.NextNode())
																{
																	// start at the end of <![CDATA[
																	this.start += 9;
																	this.end = this.xmlData.IndexOf("]]>", this.start, System.StringComparison.Ordinal);
																	stringArray.Add(this.xmlData.Substring(this.start, this.end - this.start));
																	this.end += 3;
																	this.NextNode();
																}
															}
														}
														else
														{
															break;
														}
													} while(name[0] != '/');
													data.Set(subName, stringArray.ToArray());
												}
											}
											else
											{
												break;
											}
										} while(name[0] != '/' || name != XMLName.STRING_ARRAYS_CL);
									}
								}
								// float arrays
								//else if(name == XMLName.FLOAT_ARRAYS)
								else if(name[1] == 'f')
								{
									do
									{
										if(this.NextNode())
										{
											this.start++;
											// name
											space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
											name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

											if(name[0] != '/')
											{
												if(space < this.end - 2)
												{
													List<float> floatArray = new List<float>();
													do
													{
														this.start = space + 1;
														space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
														if(space != -1)
														{
															floatArray.Add(float.Parse(this.xmlData.Substring(this.start, space - this.start), cultureInfo));
														}
													} while(space != -1);
													data.Set(name, floatArray.ToArray());
												}
												else
												{
													this.start = space + 1;
													data.Set(name, new float[0]);
												}
											}
										}
										else
										{
											break;
										}
									} while(name[0] != '/');
								}
								// int arrays
								//else if(name == XMLName.INT_ARRAYS)
								else if(name[1] == 'i')
								{
									do
									{
										if(this.NextNode())
										{
											this.start++;
											// name
											space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
											name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

											if(name[0] != '/')
											{
												if(space < this.end - 2)
												{
													List<int> intArray = new List<int>();
													do
													{
														this.start = space + 1;
														space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
														if(space != -1)
														{
															intArray.Add(int.Parse(this.xmlData.Substring(this.start, space - this.start)));
														}
													} while(space != -1);
													data.Set(name, intArray.ToArray());
												}
												else
												{
													this.start = space + 1;
													data.Set(name, new int[0]);
												}
											}
										}
										else
										{
											break;
										}
									} while(name[0] != '/');
								}
								// bool arrays
								//else if(name == XMLName.BOOL_ARRAYS)
								else if(name[1] == 'b')
								{
									do
									{
										if(this.NextNode())
										{
											this.start++;
											// name
											space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
											name = this.xmlData.Substring(this.start, ((space == -1) ? this.end : space) - this.start);

											if(name[0] != '/')
											{
												if(space < this.end - 2)
												{
													List<bool> boolArray = new List<bool>();
													do
													{
														this.start = space + 1;
														space = this.xmlData.IndexOf(' ', this.start, this.end - this.start);
														if(space != -1)
														{
															boolArray.Add(bool.Parse(this.xmlData.Substring(this.start, space - this.start)));
														}
													} while(space != -1);
													data.Set(name, boolArray.ToArray());
												}
												else
												{
													this.start = space + 1;
													data.Set(name, new bool[0]);
												}
											}
										}
										else
										{
											break;
										}
									} while(name[0] != '/');
								}
								// sub
								else
								{
									this.start--;
									this.end = this.start;
									data.Set(name, this.DoParse());
								}
							}
							// exit
							//else if(name == exitName)
							else if(name[0] == '/')
							{
								break;
							}
							// sub
							else
							{
								this.start--;
								this.end = this.start;
								data.Set(name, this.DoParse());
							}
						}
					}
				}
			}
			catch(System.Exception e)
			{
				Debug.LogError("Error while parsing XML data: " + e.StackTrace);
			}
			return data;
		}


		/*
		============================================================================
		Help functions
		============================================================================
		*/
		/// <summary>
		/// Nexts the node.
		/// </summary>
		/// <returns>
		/// True if next node exists.
		/// </returns>
		private bool NextNode()
		{
			if(this.end >= 0 && this.end < this.xmlData.Length)
			{
				this.start = this.xmlData.IndexOf('<', this.end);
				this.end = this.xmlData.IndexOf('>', this.end + 1);
				return this.start < this.end;
			}
			return false;
		}
	}
}
