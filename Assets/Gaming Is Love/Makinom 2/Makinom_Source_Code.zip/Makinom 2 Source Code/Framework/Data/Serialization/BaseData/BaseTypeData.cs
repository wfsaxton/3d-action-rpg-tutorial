﻿
namespace GamingIsLove.Makinom
{
	/// <summary>
	/// Data serialization implementation including namespace/class information.
	/// </summary>
	public class BaseTypeData : IBaseData
	{
		/// <summary>
		/// Gets a <see cref="GamingIsLove.Makinom.DataObject"/> representing the class.
		/// </summary>
		/// <returns>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </returns>
		public virtual DataObject GetData()
		{
			DataObject data = DataSerializer.GetDataObject(this);
			data.Set(DataSerializer.TYPE, ReflectionTypeHandler.GetGenericTypeName(this.GetType()));
			return data;
		}

		/// <summary>
		/// Sets the variables of the class using a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the data.
		/// </param>
		public virtual void SetData(DataObject data)
		{
			DataSerializer.SetDataObject(data, this);
		}

		/// <summary>
		/// Called for the field defined using the <c>settingAutoSetup</c> option of the <see cref="GamingIsLove.Makinom.EditorInfoAttribute"/>.
		/// </summary>
		/// <param name="fieldName">The name of the field the function is called for.</param>
		public virtual void EditorAutoSetup(string fieldName)
		{

		}

		/// <summary>
		/// Checks if the setting is of a defined type.
		/// </summary>
		/// <param name="type">The class type of string, consisting of namespace and class name.</param>
		/// <returns><c>true</c> if the type matches.</returns>
		public virtual bool IsType(string type)
		{
			return ReflectionTypeHandler.GetGenericTypeName(this.GetType()) == type;
		}

		public virtual string GetGenericTypeName()
		{
			return ReflectionTypeHandler.GetGenericTypeName(this.GetType());
		}
	}
}
