
using UnityEngine;
using GamingIsLove.Makinom.IO;

namespace GamingIsLove.Makinom
{
	[System.Serializable]
	public class DataFile
	{
		public enum SaveFormatType { ByteArray, XMLString }

		public string name = "";

		[SerializeField]
		[HideInInspector]
		protected byte[] byteData = null;

		[SerializeField]
		[HideInInspector]
		protected string xmlData = null;

		[SerializeField]
		[HideInInspector]
		protected AssetLookUp lookUp = new AssetLookUp();

		[SerializeField]
		[HideInInspector]
		protected bool encrypted = false;

		[System.NonSerialized]
		protected DataObject dataObject;

		public DataFile(string name, bool encrypted)
		{
			this.name = name;
			this.encrypted = encrypted;
		}

		public bool IsEncrypted
		{
			get { return this.encrypted; }
		}

		public virtual void SetData(byte[] data)
		{
			this.dataObject = null;
			this.byteData = data;
			this.xmlData = null;
		}

		public virtual void SetXMLData(string data)
		{
			this.dataObject = null;
			this.byteData = null;
			this.xmlData = this.encrypted ? Maki.SecurityHandler.SaveData(data) : data;
		}

		public virtual string GetXMLData()
		{
			if(this.xmlData != null)
			{
				return this.encrypted ? Maki.SecurityHandler.LoadData(this.xmlData) : this.xmlData;
			}
			else
			{
				return "";
			}
		}

		public AssetLookUp LookUp
		{
			get { return this.lookUp; }
		}

		public void ClearDataObject()
		{
			this.dataObject = null;
		}

		public virtual DataObject ToDataObject()
		{
			if(this.dataObject == null)
			{
				if(string.IsNullOrEmpty(this.xmlData))
				{
					this.dataObject = this.byteData == null || this.byteData.Length == 0 ?
						new DataObject() :
						new DataObject(this.byteData, this.encrypted, this);
				}
				else
				{
					this.dataObject = new XMLParser(this.GetXMLData(), this.lookUp).Parse();
				}
			}
			return this.dataObject;
		}

		public bool CompareTo(DataFile file)
		{
			if(file != null &&
				this.CompareData(file) &&
				this.lookUp.CompareTo(file.lookUp))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		protected bool CompareData(DataFile file)
		{
			if((this.byteData == null || this.byteData.Length == 0) &&
				(file.byteData == null || file.byteData.Length == 0))
			{
				bool thisXML = string.IsNullOrEmpty(this.xmlData);
				bool otherXML = string.IsNullOrEmpty(file.xmlData);
				if(thisXML != otherXML)
				{
					return false;
				}
				else if(!thisXML)
				{
					return this.GetXMLData() == file.GetXMLData();
				}
				return true;
			}
			else if((this.byteData != null && file.byteData == null) ||
				(this.byteData == null && file.byteData != null) ||
				this.byteData.Length != file.byteData.Length)
			{
				return false;
			}
			for(int i = 0; i < this.byteData.Length; i++)
			{
				if(this.byteData[i] != file.byteData[i])
				{
					return false;
				}
			}
			return true;
		}
	}
}
