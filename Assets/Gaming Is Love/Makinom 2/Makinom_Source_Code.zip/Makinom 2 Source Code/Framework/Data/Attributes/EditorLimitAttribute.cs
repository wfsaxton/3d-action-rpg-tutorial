
using UnityEngine;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorLimitAttribute : System.Attribute
	{
		public bool isSlider = false;

		public float minimum = float.MinValue;

		public float maximum = float.MaxValue;


		// limit by field
		public bool isLimitByField = false;

		public string limitFieldName = "";

		public bool fieldMaxLimit = false;

		public EditorLimitAttribute(float min, float max)
		{
			this.minimum = min;
			this.maximum = max;
		}

		public EditorLimitAttribute(string fieldName, bool isMax)
		{
			this.isLimitByField = true;
			this.limitFieldName = fieldName;
			this.fieldMaxLimit = isMax;
		}

		public EditorLimitAttribute(float min)
		{
			this.minimum = min;
		}

		public EditorLimitAttribute(float value, bool isMax)
		{
			if(isMax)
			{
				this.maximum = value;
			}
			else
			{
				this.minimum = value;
			}
		}

		public void Limit(ref int value)
		{
			if(value < this.minimum)
			{
				value = (int)this.minimum;
			}
			else if(value > this.maximum)
			{
				value = (int)this.maximum;
			}
		}

		public void Limit(ref float value)
		{
			if(value < this.minimum)
			{
				value = this.minimum;
			}
			else if(value > this.maximum)
			{
				value = this.maximum;
			}
		}
	}
}

