
using UnityEngine;
using System.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PluginsSettings : GenericAssetListSettings<PluginAsset, PluginSetting>
	{
		public PluginsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Plugins"; }
		}


		/*
		============================================================================
		Plugin functions
		============================================================================
		*/
		public virtual T GetPlugin<T>() where T : BasePlugin
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.settings is T)
				{
					return this.assets[i].Settings.settings as T;
				}
			}
			return null;
		}

		public virtual void OnInitialize()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.settings != null)
				{
					this.assets[i].Settings.settings.OnInitialize();
				}
			}
		}

		public virtual void OnNewGame()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.settings != null)
				{
					this.assets[i].Settings.settings.OnNewGame();
				}
			}
		}

		public virtual void OnLoadGame()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.settings != null)
				{
					this.assets[i].Settings.settings.OnLoadGame();
				}
			}
		}

		public virtual void Register()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.settings != null)
				{
					if(this.assets[i].Settings.useTick)
					{
						Maki.Instance.Tick += this.assets[i].Settings.settings.Tick;
					}
					if(this.assets[i].Settings.useGUITick)
					{
						Maki.Instance.GUITick += this.assets[i].Settings.settings.GUITick;
					}
					if(this.assets[i].Settings.useSceneLoaded)
					{
						Maki.Instance.SceneLoaded += this.assets[i].Settings.settings.SceneLoaded;
						Maki.Instance.SceneNameLoaded += this.assets[i].Settings.settings.SceneNameLoaded;
					}
				}
			}
		}

		public virtual void Unregister()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.settings != null)
				{
					if(this.assets[i].Settings.useTick)
					{
						Maki.Instance.Tick -= this.assets[i].Settings.settings.Tick;
					}
					if(this.assets[i].Settings.useGUITick)
					{
						Maki.Instance.GUITick -= this.assets[i].Settings.settings.GUITick;
					}
					if(this.assets[i].Settings.useSceneLoaded)
					{
						Maki.Instance.SceneLoaded -= this.assets[i].Settings.settings.SceneLoaded;
					}
				}
			}
		}
	}
}
