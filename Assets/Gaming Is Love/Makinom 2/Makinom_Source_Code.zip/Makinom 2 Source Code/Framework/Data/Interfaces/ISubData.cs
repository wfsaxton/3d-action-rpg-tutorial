﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface ISubData
	{
		string[] GetEditorSubDataNames();

		int GetSubDataCount();

		IContent GetSubDataContent(int index);
	}

	public static class SubDataContentHelper
	{
		public static IContent Get(object content, int index)
		{
			if(content is ISubData)
			{
				return ((ISubData)content).GetSubDataContent(index);
			}
			return null;
		}
	}
}
