﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SavePointComponent))]
public class SavePointComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as SavePointComponent);
	}

	private void ComponentSetup(SavePointComponent target)
	{
		Undo.RecordObject(target, "Change to 'Save Point' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Save Point Settings", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}