﻿
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class GeneralConditionTemplatesTab : GenericAssetListTab<GeneralConditionTemplateAsset, GeneralConditionTemplate>
	{
		public GeneralConditionTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "General Condition Templates"; }
		}

		public override string HelpText
		{
			get { return "Set up reusable templates for general condition checks."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}

