
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class GameStateConditionTemplatesTab : GenericAssetListTab<GameStateConditionTemplateAsset, GameStateConditionTemplate>
	{
		public GameStateConditionTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Game State Condition Templates"; }
		}

		public override string HelpText
		{
			get { return "Set up reusable templates for game state condition checks."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/game-states/"; }
		}
	}
}
