
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class UILayersTab : GenericAssetListTab<UILayerAsset, UILayerSetting>
	{
		public UILayersTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.UILayers.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.UILayers.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(UILayersTab.CreateAsset("Flying Texts", "FlyingTexts", false, true));
				this.assetList.Add(UILayersTab.CreateAsset("Layer 1", "Layer1", false, false));
				this.assetList.Add(UILayersTab.CreateAsset("Screen Fader", "ScreenFader", true, false));
			}
		}

		protected static UILayerAsset CreateAsset(string name, string guid, bool isScreenFader, bool isFlyingText)
		{
			UILayerAsset asset = ScriptableObject.CreateInstance<UILayerAsset>();
			asset.Settings = new UILayerSetting(name);
			asset.Settings.GUID = guid;
			asset.Settings.isScreenFader = isScreenFader;
			asset.Settings.isFlyingText = isFlyingText;
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "UI Layers"; }
		}

		public override string HelpText
		{
			get
			{
				return "UI layers are used to organize UI boxes and HUDs.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/ui-system/ui-layers/"; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "check:uilayersettings")
			{
				if(this.assetList.AssetExists(this.index))
				{
					if(this.assetList.Assets[this.index].Settings.isScreenFader)
					{
						for(int i = 0; i < this.assetList.Count; i++)
						{
							if(i != this.index)
							{
								this.assetList.Assets[i].Settings.isScreenFader = false;
							}
						}
					}
					if(this.assetList.Assets[this.index].Settings.isFlyingText)
					{
						for(int i = 0; i < this.assetList.Count; i++)
						{
							if(i != this.index)
							{
								this.assetList.Assets[i].Settings.isFlyingText = false;
							}
						}
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

