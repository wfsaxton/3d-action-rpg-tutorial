
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class HUDsTab : GenericAssetListTab<HUDAsset, HUDSetting>
	{
		public HUDsTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.HUDs.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.HUDs.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "HUDs"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up HUDs to display content to the player (e.g. health or interaction information), " +
					"or to interact with the player (e.g. 'Control' HUDs or starting machines when clicking on them).";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/ui-system/huds/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings that are used by all individual HUDs.\n" +
					"The default settings can optionally be overridden by each HUD individually.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return Maki.HUDs; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return Maki.HUDs;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
