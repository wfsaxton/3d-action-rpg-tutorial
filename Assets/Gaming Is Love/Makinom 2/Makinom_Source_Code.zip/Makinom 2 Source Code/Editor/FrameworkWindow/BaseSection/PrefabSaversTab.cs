﻿
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class PrefabSaversTab : GenericAssetListTab<PrefabSaverAsset, PrefabSaver>
	{
		public PrefabSaversTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.PrefabSavers.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.PrefabSavers.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Prefab Savers"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up prefabs that can be saved between scenes and in save games.\n" +
					"Spawning prefabs in schematics using 'Spawn Prefab' nodes can mark the instance to be saved.\n" +
					"Destroying an instance in schematics using 'Destroy Prefab' or 'Destroy Object' nodes will remove it from saving.\n" +
					"If data from prefab savers is saved with save games is defined in 'UI > Save Game Settings'.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/saving-game-objects/"; }
		}
	}
}
