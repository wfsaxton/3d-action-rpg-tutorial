
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class GameSettingsTab : BaseEditorTab
	{
		// asset source
		private bool updateSchematics = false;

		private string schematicUpdateFolder = "";

		private bool setBundlePath = false;

		private AssetBundleSettings assetBundlePath = new AssetBundleSettings(true);

		public GameSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Game Settings"; }
		}

		public override string HelpText
		{
			get
			{
				return "Change basic game settings, e.g. raycasting, random chance limits, " +
					"start volumes, initial variables or the player.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.GameSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.GameSettings; }
		}


		/*
		============================================================================
		Settings functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].GameSettings != null)
				{
					EditorAutomation.Automate(EditorContent.Extensions[i].GameSettings, this);
				}
			}
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "button:loadassetbundles")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Add All Asset Bundles to Load",
					"Adds all asset bundles that are found in the Unity project to the load asset bundles list.", ""))
				{
					string[] bundles = AssetDatabase.GetAllAssetBundleNames();

					for(int i = 0; i < bundles.Length; i++)
					{
						ArrayHelper.Add(ref Maki.GameSettings.assetSettings.loadAssetBundle,
							new AssetBundleSettings(bundles[i]));
					}
				}
			}
			else if(info == "button:assetsources")
			{
				if(this.BeginFoldout("Asset Source Changes", "You can optionally change the source of all assets used in the project and schematic assets.\n" +
					"Only assets that qualify for the change will be changed, " +
					"e.g. changing to use 'Resources' will only change assets that are stored in a 'Resources' folder or " +
					"'Asset Bundle' will only change assets that are part of an asset bundle.", "", true))
				{
					this.updateSchematics = EditorGUILayout.Toggle("Update Schematics", this.updateSchematics);
					if(this.updateSchematics)
					{
						EditorGUILayout.HelpBox("Schematic assets will also udpate their asset sources.\n" +
							"These changes will be saved to the schematic assets immediately, i.e. you can't undo them.",
							MessageType.Info);
						this.schematicUpdateFolder = EditorGUILayout.TextField("Folder (in Assets)", this.schematicUpdateFolder, EditorTool.W_EXPAND);
					}
					EditorGUILayout.Separator();

					// reference
					if(EditorTool.Button("Change To 'Reference'",
						"Updates all assets to use 'Reference' asset source, " +
						"saving a direct reference to the used assets.", ""))
					{
						if(EditorUtility.DisplayDialog("Change To Reference",
							"All assets will be changed to 'Reference' asset source.", "Change"))
						{
							AssetSourceEditor.UpdateSource(typeof(ReferenceAssetSource<>), null, this);
							if(this.updateSchematics)
							{
								AssetSourceEditor.UpdateSchematicsSource(this.schematicUpdateFolder, typeof(ReferenceAssetSource<>), null);
							}
						}
					}
					EditorGUILayout.Separator();

					// resources
					if(EditorTool.Button("Change To 'Resources'",
						"Updates all assets that are stored in a 'Resources' folder to use 'Resources' asset source, " +
						"saving the asset's path within the folder.", ""))
					{
						if(EditorUtility.DisplayDialog("Change To Resources",
							"All assets stored in a 'Resources' folder will be changed to 'Resources' asset source.", "Change"))
						{
							AssetSourceEditor.UpdateSource(typeof(ResourcesAssetSource<>), null, this);
							if(this.updateSchematics)
							{
								AssetSourceEditor.UpdateSchematicsSource(this.schematicUpdateFolder, typeof(ResourcesAssetSource<>), null);
							}
						}
					}
					EditorGUILayout.Separator();

					// asset bundle
					EditorTool.Field("Own Asset Bundle Path", ref this.setBundlePath,
						"Use a custom asset bundle path instead of the default path defined in the game settings.", "", null, this);
					if(this.setBundlePath)
					{
						EditorAutomation.Automate("path", this.assetBundlePath, this);
					}
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.Button("Change To 'Asset Bundle'",
						"Updates all assets that are assigned to an asset bundle to use 'Asset Bundle' asset source, " +
						"saving the asset bundle's information using the defined path.", ""))
					{
						if(EditorUtility.DisplayDialog("Change To Asset Bundle",
							"All assets assigned to an asset bundle will be changed to 'Asset Bundle' asset source.", "Change"))
						{
							AssetSourceEditor.UpdateSource(typeof(AssetBundleAssetSource<>),
								this.setBundlePath ? this.assetBundlePath.path : null, this);
							if(this.updateSchematics)
							{
								AssetSourceEditor.UpdateSchematicsSource(this.schematicUpdateFolder, typeof(AssetBundleAssetSource<>), null);
							}
						}
					}
					if(this.setBundlePath &&
						EditorTool.Button("Change Asset Bundle Path",
						"Updates the asset bundle path of all assets using the 'Asset Bundle' asset source with a custom asset bundle path.", ""))
					{
						if(EditorUtility.DisplayDialog("Change Asset Bundle Path",
							"All assets using the 'Asset Bundle' asset source with a custom asset bundle path will change their path to the defined path.", "Change"))
						{
							AssetSourceEditor.UpdateAssetBundlePath(this.assetBundlePath.path, this);
							if(this.updateSchematics)
							{
								AssetSourceEditor.UpdateSchematicsAssetBundlePath(this.schematicUpdateFolder, null);
							}
						}
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.Separator();
				}
				this.EndFoldout();
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
