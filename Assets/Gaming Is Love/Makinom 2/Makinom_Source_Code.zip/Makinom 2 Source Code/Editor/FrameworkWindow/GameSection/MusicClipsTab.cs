
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class MusicClipsTab : GenericAssetListTab<MusicClipAsset, MusicClipSetting>
	{
		protected float testPadding = 3;

		protected GameObject loopTestObject;

		protected AudioSource audioPlaying;

		protected AudioSource audioLoop;

		public MusicClipsTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.MusicClips.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.MusicClips.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Music"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up music clips to be used in 'Music Player' components and schematics.\n" +
					"You can set up different loops within a clip and fade between different music in the music player.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/audio-and-music/"; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		protected virtual void InitLoopTest()
		{
			if(this.loopTestObject == null)
			{
				this.loopTestObject = new GameObject("_MusicLoopTest");
				this.loopTestObject.hideFlags = HideFlags.HideAndDontSave;
				this.audioPlaying = this.loopTestObject.AddComponent<AudioSource>();
				this.audioLoop = this.loopTestObject.AddComponent<AudioSource>();
			}
		}

		public override void InstanceCallback(string info, System.Object instance)
		{
			if(info == "button:testloop")
			{
				MusicClipSetting musicSettings = this.CurrentSettings;
				if(musicSettings != null &&
					musicSettings.clip.StoredAsset != null)
				{
					MusicClipLoop loopSettings = instance as MusicClipLoop;
					if(loopSettings != null &&
						!loopSettings.endLoop)
					{
						EditorTool.Separator(2);
						this.testPadding = EditorGUILayout.Slider(
							new GUIContent("Test Padding (s)", "Time in seconds used to test the loop, added before and after looping."),
							this.testPadding, 1, 10, EditorTool.WIDTH);
						if(EditorTool.Button("Test Loop", "Test the defined loop of the music clip.\n" +
							"The 'Game' view has to be unmuted to actually hear the music.\n" +
							"Please note that due to playing in edit mode, the result might not be 100% accurate.", ""))
						{
							this.InitLoopTest();
							this.audioPlaying.Stop();
							this.audioLoop.Stop();

							this.audioPlaying.clip = musicSettings.clip.StoredAsset;
							this.audioLoop.clip = musicSettings.clip.StoredAsset;

							double duration = AudioSettings.dspTime;

							// pcm
							if(loopSettings.usePCM)
							{
								this.audioPlaying.timeSamples = loopSettings.checkPCM - (int)(this.testPadding * this.audioPlaying.clip.frequency);
								if(this.audioPlaying.timeSamples < 0)
								{
									this.audioPlaying.timeSamples = 0;
								}
								duration += (double)(loopSettings.checkPCM - this.audioPlaying.timeSamples) / this.audioPlaying.clip.frequency;
								this.audioLoop.timeSamples = loopSettings.setPCM;
							}
							// time
							else
							{
								this.audioPlaying.timeSamples = (int)((loopSettings.checkTime - this.testPadding) * this.audioPlaying.clip.frequency);
								if(this.audioPlaying.timeSamples < 0)
								{
									this.audioPlaying.timeSamples = 0;
								}
								duration += loopSettings.checkTime - (this.audioPlaying.timeSamples / this.audioPlaying.clip.frequency);
								this.audioLoop.timeSamples = (int)(loopSettings.setTime * this.audioPlaying.clip.frequency);
							}

							this.audioPlaying.Play();
							this.audioPlaying.PlayScheduled(AudioSettings.dspTime);
							this.audioPlaying.SetScheduledEndTime(duration);

							this.audioLoop.Stop();
							this.audioLoop.PlayScheduled(duration);
							this.audioLoop.SetScheduledEndTime(duration + this.testPadding);
						}
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
