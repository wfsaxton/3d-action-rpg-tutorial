
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Schematics.Nodes;
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class SchematicsTab : BaseEditorTab
	{
		private string fileName = "";

		private string lastPath = "";

		private MakinomSchematicAsset schematicAsset;

		private Schematic runtimeSchematic;


		// node editor
		private NodeEditor nodeEditor;


		// buttons
		private GUIContent deleteContent = new GUIContent("Delete Schematic");

		private GUIContent saveContent = new GUIContent("Save Schematic");

		private GUIContent saveAsContent = new GUIContent("Save Schematic As ...");


		// special popup lists
		public string[] popupList0 = new string[0];

		public string[] popupList1 = new string[0];

		public string[] popupList2 = new string[0];

		public string[] popupList3 = new string[0];

		public string[] popupList4 = new string[0];

		public string[] popupList5 = new string[0];

		public string[] popupList6 = new string[0];

		public string[] popupList7 = new string[0];

		public string[] popupList8 = new string[0];

		public string[] popupList9 = new string[0];

		public string[] popupList10 = new string[0];

		public string[] popupList11 = new string[0];

		public SchematicsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
			// create node editor
			this.nodeEditor = new NodeEditor(this,
				EditorContent.Instance.SchematicClipboard,
				this.AddNode, this.RemoveNode, this.AddNodeGroup, this.RemoveNodeGroup,
				this.AddLayer, this.AddContextMenuOption);

			this.nodeEditor.SetNodeInfos(typeof(BaseSchematicNode), typeof(SchematicGateNode));

			this.LoadFile(null, null);

			if(Application.isPlaying)
			{
				Maki.MachineHandler.IsDebugging = true;
			}
		}

		public void FirstShow()
		{
			if(this.runtimeSchematic == null)
			{
				if(EditorDataHandler.Instance.EditorAsset.RememberSchematic != null)
				{
					this.LoadFile(EditorDataHandler.Instance.EditorAsset.RememberSchematic, null);
					this.nodeEditor.RealNodeScroll = EditorDataHandler.Instance.EditorAsset.RememberSchematicScroll;
					this.nodeEditor.ZoomOffset = EditorDataHandler.Instance.EditorAsset.RememberSchematicZoomOffset;
					if(EditorDataHandler.Instance.EditorAsset.RememberSchematicFocusedNode >= 0 &&
						EditorDataHandler.Instance.EditorAsset.RememberSchematicFocusedNode < this.schematicAsset.Settings.node.Length)
					{
						this.nodeEditor.SelectNode(
							this.schematicAsset.Settings.node[EditorDataHandler.Instance.EditorAsset.RememberSchematicFocusedNode],
							false, -1);
					}
					this.nodeEditor.FirstFocus = false;
					// clear
					EditorDataHandler.Instance.EditorAsset.RememberSchematic = null;
					EditorDataHandler.Instance.EditorAsset.RememberSchematicScroll = Vector2.zero;
					EditorDataHandler.Instance.EditorAsset.RememberSchematicZoomOffset = Vector2.zero;
					EditorDataHandler.Instance.EditorAsset.RememberSchematicFocusedNode = -1;
				}
				else if(Maki.EditorSettings.openLastSchematic)
				{
					this.LoadFile(EditorDataHandler.Instance.EditorAsset.GetLastOpenedSchematic(), null);
				}
			}
		}

		public void RememberSchematic()
		{
			EditorDataHandler.Instance.EditorAsset.RememberSchematic = this.schematicAsset;
			EditorDataHandler.Instance.EditorAsset.RememberSchematicScroll = this.nodeEditor.RealNodeScroll;
			EditorDataHandler.Instance.EditorAsset.RememberSchematicZoomOffset = this.nodeEditor.ZoomOffset;
			EditorDataHandler.Instance.EditorAsset.RememberSchematicFocusedNode = this.nodeEditor.GetFocusedNodeIndex();
		}

		public override bool FocusSearchField()
		{
			this.nodeEditor.FocusSearchField();
			return true;
		}

		public override void GetLocalVariables(ref List<string> list, string searchvalue)
		{
			if(this.schematicAsset != null)
			{
				DataSerializer.GetVariables(this.schematicAsset.Settings, ref list, searchvalue);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Schematics"; }
		}

		public override string HelpText
		{
			get { return "Set up schematics in the node editor."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		public bool IsShowSettings
		{
			get { return this.nodeEditor.showSettings; }
		}

		protected override BaseSettings Settings
		{
			get { return null; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return null; }
		}

		public override int TextAreaType
		{
			get { return 1; }
		}

		protected override bool EnableSearchBarFoldoutButtons
		{
			get
			{
				if(this.schematicAsset != null &&
					this.nodeEditor.IsNodeSelected)
				{
					if(this.nodeEditor.Selected.Count > 1)
					{
						return true;
					}
					else if(this.nodeEditor.Selected.Count == 1 &&
						this.nodeEditor.Selected[0] == this.schematicAsset.Settings)
					{
						return true;
					}
				}
				return false;
			}
		}

		public NodeEditor NodeEditor
		{
			get { return this.nodeEditor; }
		}


		/*
		============================================================================
		Last schematic asset functions
		============================================================================
		*/
		private void AddLastSchematicsList(MakinomSchematicAsset schematicAsset)
		{
			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;

			List<MakinomSchematicAsset> list = editorAsset.LastSchematics;
			list.Remove(schematicAsset);
			list.Insert(0, schematicAsset);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] == null)
				{
					list.RemoveAt(i--);
				}
			}

			if(list.Count >= Maki.EditorSettings.lastOpenedSchematics)
			{
				list.RemoveRange(Maki.EditorSettings.lastOpenedSchematics,
					list.Count - Maki.EditorSettings.lastOpenedSchematics);
			}
			editorAsset.LastSchematics = list;

			MakinomAssetHelper.SaveEditorAsset(editorAsset);
		}

		public MakinomSchematicAsset ShowLastSchematicsList(System.Type type)
		{
			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;

			List<MakinomSchematicAsset> list = editorAsset.LastSchematics;
			if(list.Count > 0)
			{
				EditorGUILayout.Separator();
				EditorTool.BoldLabel("Last Opened Schematics");

				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(EditorTool.ShowButton(list[i].name, "Opens this schematic asset:\n" +
							AssetDatabase.GetAssetPath(list[i]),
							"", GUILayout.ExpandWidth(true)))
						{
							return list[i];
						}
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		Load/save functions
		============================================================================
		*/
		public void LoadFile(MakinomSchematicAsset schematicAsset, Schematic runtimeSchematic)
		{
			this.fileName = "";
			this.schematicAsset = null;
			this.runtimeSchematic = null;

			if(schematicAsset != null)
			{
				this.schematicAsset = schematicAsset;
			}
			else
			{
				this.schematicAsset = ScriptableObject.CreateInstance<MakinomSchematicAsset>();
			}
			if(!Application.isPlaying)
			{
				this.schematicAsset.LoadData();
			}
			EditorDataHandler.DataLoaded(this.schematicAsset.Settings);

			if(schematicAsset != null &&
				this.schematicAsset != null)
			{
				this.fileName = AssetDatabase.GetAssetPath(schematicAsset);

				// add schematic to last schematics list
				this.AddLastSchematicsList(schematicAsset);
			}

			this.DoChecks();

			if(this.schematicAsset != null)
			{
				this.nodeEditor.SelectNode(this.schematicAsset.Settings, false, -1);
				this.nodeEditor.Layer = this.schematicAsset.Settings.nodeLayer;
				this.nodeEditor.FirstFocus = true;

				if(Maki.EditorSettings.schematicAutoStartDebug &&
					runtimeSchematic == null &&
					Maki.MachineHandler.HasDebug)
				{
					List<SchematicDebug> list = Maki.MachineHandler.GetDebug(this.schematicAsset);
					if(list != null && list.Count > 0)
					{
						this.RuntimeSchematic = list[0].Schematic;
					}
					else
					{
						this.RuntimeSchematic = runtimeSchematic;
					}
				}
				else
				{
					this.RuntimeSchematic = runtimeSchematic;
				}
			}
		}

		public void ChangeEditorSchematic()
		{
			if(EditorDataHandler.Instance.HasDataChanges)
			{
				EditorDataHandler.Instance.UseDataChanges(this.schematicAsset.Settings);
			}
		}

		public void SaveFile()
		{
			if(this.fileName != "" && this.schematicAsset != null)
			{
				MakinomSchematicAsset tmpAsset = this.schematicAsset;
				this.schematicAsset = MakinomAssetHelper.SaveSchematic(this.schematicAsset, this.fileName);
				this.AddLastSchematicsList(this.schematicAsset);

				EditorVariables.Instance.UpdateSchematic(this.schematicAsset.Settings);

				if(tmpAsset != this.schematicAsset)
				{
					this.nodeEditor.ClearSelected();
				}
			}
		}

		private void SaveNewFile()
		{
			string path = this.lastPath == "" ?
				EditorUtility.SaveFilePanelInProject("Save Schematic Asset", "", "asset",
					"Please enter the name of the asset file that will be created.\n" +
					"Existing files will be replaced!") :
				EditorUtility.SaveFilePanelInProject("Save Schematic Asset", "", "asset",
					"Please enter the name of the asset file that will be created.\n" +
					"Existing files will be replaced!", this.lastPath);
			if(path.Length != 0)
			{
				this.fileName = path;
				this.lastPath = path;
				this.SaveFile();
			}
		}

		public string FileName
		{
			get { return this.fileName; }
		}

		public MakinomSchematicAsset SchematicAsset
		{
			get { return this.schematicAsset; }
		}

		public Schematic RuntimeSchematic
		{
			get { return this.runtimeSchematic; }
			set
			{
				if(this.runtimeSchematic != value &&
					(value == null || value.Asset == this.schematicAsset))
				{
					if(this.runtimeSchematic != null &&
						this.runtimeSchematic.Debug != null)
					{
						this.runtimeSchematic.Debug.Changed -= this.DebugChanged;
					}
					this.runtimeSchematic = value;
					if(this.runtimeSchematic != null)
					{
						if(this.runtimeSchematic.Debug != null)
						{
							this.runtimeSchematic.Debug.Changed += this.DebugChanged;
						}
						else if(Maki.MachineHandler.IsDebugging)
						{
							this.runtimeSchematic.InitDebug();
							this.runtimeSchematic.Debug.Changed += this.DebugChanged;
						}
					}
				}
			}
		}

		private void DebugChanged(bool isTime)
		{
			this.Editor.Repaint();
			if(!isTime &&
				this.schematicAsset != null &&
				this.runtimeSchematic != null &&
				this.runtimeSchematic.Debug != null &&
				this.runtimeSchematic.Debug.Nodes.Count > 0 &&
				this.schematicAsset.Settings.node[
					this.runtimeSchematic.Debug.Nodes[this.runtimeSchematic.Debug.Nodes.Count - 1].nodeIndex].isBreakpoint)
			{
				EditorApplication.isPaused = true;
			}
		}

		public void UnregisterDebug()
		{
			this.RuntimeSchematic = null;
		}


		/*
		============================================================================
		Node functions
		============================================================================
		*/
		public BaseNode[] AddNode(BaseNode node)
		{
			if(this.schematicAsset != null && node is BaseSchematicNode)
			{
				ArrayHelper.Add(ref this.schematicAsset.Settings.node, node as BaseSchematicNode);
				return this.schematicAsset.Settings.node;
			}
			return null;
		}

		public BaseNode[] RemoveNode(BaseNode node)
		{
			if(this.schematicAsset != null && node is BaseSchematicNode)
			{
				ArrayHelper.Remove(ref this.schematicAsset.Settings.node, node as BaseSchematicNode);
				return this.schematicAsset.Settings.node;
			}
			return null;
		}

		public NodeGroup[] AddNodeGroup(NodeGroup group)
		{
			if(this.schematicAsset != null)
			{
				ArrayHelper.Add(ref this.schematicAsset.Settings.group, group);
				return this.schematicAsset.Settings.group;
			}
			return null;
		}

		public NodeGroup[] RemoveNodeGroup(NodeGroup group)
		{
			if(this.schematicAsset != null)
			{
				ArrayHelper.Remove(ref this.schematicAsset.Settings.group, group);
				return this.schematicAsset.Settings.group;
			}
			return null;
		}

		public string[] AddLayer()
		{
			if(this.schematicAsset != null)
			{
				ArrayHelper.Add(ref this.schematicAsset.Settings.layer, "New Layer");
				return this.schematicAsset.Settings.layer;
			}
			return null;
		}

		public void AddContextMenuOption(List<ContextMenuPopup.Element> tree)
		{
			tree.Add(new ContextMenuPopup.SeparatorElement());
			tree.Add(new ContextMenuPopup.MenuElement("Open Dialogue Importer", "", this.OpenDialogueImporter));
		}

		public void OpenDialogueImporter()
		{
			this.parent.ShowCustomFullView(new DialogueImportEditor(this.parent, this.schematicAsset, this.nodeEditor));
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowTab()
		{

		}

		public void ShowSchematicSaveButtons()
		{
			if(this.saveContent.image == null)
			{
				this.saveContent.image = EditorContent.Instance.SaveIcon;
			}
			if(this.saveAsContent.image == null)
			{
				this.saveAsContent.image = EditorContent.Instance.SaveIcon;
			}
			if(this.deleteContent.image == null)
			{
				this.deleteContent.image = EditorContent.Instance.DeleteIcon;
			}

			EditorGUI.BeginDisabledGroup(this.fileName == "");
			if(EditorTool.ShowButton(this.deleteContent, "Deletes this schematic asset file.", "", GUILayout.ExpandWidth(true)))
			{
				if(EditorUtility.DisplayDialog("Delete Schematic",
					"Do you really want to delete this schematic?\n" + this.fileName,
					"Yes", "No"))
				{
					AssetDatabase.DeleteAsset(this.fileName);
					this.LoadFile(null, null);
				}
				this.Editor.Focus();
			}
			EditorGUI.EndDisabledGroup();
			if(EditorTool.ShowButton(this.saveContent, "Saves the schematic asset file.\n" +
				"If this is a new schematic (no asset file yet), a file dialog is used to define the file to save to.\n" +
				"If this file already exists, the file is saved using the existing file.", "", GUILayout.ExpandWidth(true)))
			{
				if(this.fileName == "")
				{
					this.SaveNewFile();
				}
				else
				{
					this.SaveFile();
				}
			}
			if(EditorTool.ShowButton(this.saveAsContent, "Saves the schematic asset file as a new file.\n" +
				"A file dialog is used to define the file to save to.", "", GUILayout.ExpandWidth(true)))
			{
				this.SaveNewFile();
			}
		}

		public void ShowNodeGrid(Rect rect)
		{
			if(this.schematicAsset != null)
			{
				EditorGUILayout.BeginVertical();
				this.nodeEditor.ShowNodes(rect, this.schematicAsset.Settings,
					this.schematicAsset.Settings.node,
					this.schematicAsset.Settings.group,
					this.runtimeSchematic != null && this.runtimeSchematic.Debug != null ?
						this.runtimeSchematic.Debug.Nodes : null,
					ref this.schematicAsset.Settings.layer);
				EditorGUILayout.EndVertical();
			}
		}

		public override void ShowSettings()
		{

		}

		public void ShowNodeSettings(bool setScrollHeight)
		{
			if(this.schematicAsset == null)
			{
				this.schematicAsset = ScriptableObject.CreateInstance<MakinomSchematicAsset>();
				if(this.schematicAsset != null)
				{
					this.nodeEditor.SelectNode(this.schematicAsset.Settings, false, -1);
					this.nodeEditor.Layer = this.schematicAsset.Settings.nodeLayer;
					this.nodeEditor.FirstFocus = true;
				}
			}
			if(this.schematicAsset != null)
			{
				EditorGUILayout.BeginVertical();
				this.ShowSearchSettings();

				// node settings
				if(setScrollHeight)
				{
					this.SettingsScroll = EditorGUILayout.BeginScrollView(this.SettingsScroll,
						GUILayout.Height(EditorDataHandler.Instance.EditorAsset.SchematicDrag));
				}
				else
				{
					this.SettingsScroll = EditorGUILayout.BeginScrollView(this.SettingsScroll);
				}

				if(this.nodeEditor.NewStartNode != null &&
					EditorTool.ShowButton("View All Nodes",
						"Exits the current limited node view and displays all nodes.", "", EditorTool.W_EXPAND))
				{
					this.nodeEditor.NewStartNode = null;
				}

				// node settings
				if(this.nodeEditor.IsNodeSelected)
				{
					for(int i = 0; i < this.nodeEditor.Selected.Count; i++)
					{
						if(this.nodeEditor.Selected[i] != null)
						{
							if(this.nodeEditor.Selected[i] == this.schematicAsset.Settings)
							{
								EditorAutomation.Automate(this.nodeEditor.Selected[i], this);
								this.DoChecks();
							}
							else
							{
								NodeInfo nodeInfo = this.nodeEditor.GetNodeInfo(this.nodeEditor.Selected[i].GetType());
								if(this.BeginFoldout(nodeInfo.content, nodeInfo.info, true))
								{
									nodeInfo.ShowSubMenuInfo();

									// options
									EditorGUILayout.BeginHorizontal();
									if(!(this.nodeEditor.Selected[i] is SchematicGateNode))
									{
										EditorAutomation.Automate("active", this.nodeEditor.Selected[i], this, true);
										if(this.nodeEditor.Selected[i].IsEnabled)
										{
											EditorAutomation.Automate("executeOnStop", this.nodeEditor.Selected[i], this, true);
										}
									}
									if(EditorTool.MicroButton("Focus", "Focus the node editor on this node.\n" +
										"Can also be done using the keyboard shortcut 'CTRL + F'.", ""))
									{
										this.nodeEditor.FocusNode(this.nodeEditor.Selected[i]);
									}
									GUILayout.FlexibleSpace();
									bool isBreakpoint = this.nodeEditor.Selected[i].IsBreakpoint;
									EditorAutomation.Automate("isBreakpoint", this.nodeEditor.Selected[i], this, true);
									EditorGUILayout.EndHorizontal();
									if(isBreakpoint != this.nodeEditor.Selected[i].IsBreakpoint &&
										!this.nodeEditor.Selected[i].IsBreakpoint &&
										EditorApplication.isPaused)
									{
										EditorApplication.isPaused = false;
									}

									// override name
									EditorGUILayout.BeginHorizontal();
									EditorAutomation.Automate("overrideNodeName", this.nodeEditor.Selected[i], this, true);
									EditorAutomation.Automate("nodeName", this.nodeEditor.Selected[i], this, true);
									GUILayout.FlexibleSpace();
									EditorGUILayout.EndHorizontal();

									if(this.runtimeSchematic != null && this.runtimeSchematic.Debug != null)
									{
										EditorAutomation.debugValues = this.runtimeSchematic.Debug.Values;

										EditorGUILayout.Separator();
										StringBuilder builder = new StringBuilder();
										for(int j = 0; j < this.runtimeSchematic.Debug.Nodes.Count; j++)
										{
											if(this.nodeEditor.Selected[i] == this.schematicAsset.Settings.node[this.runtimeSchematic.Debug.Nodes[j].nodeIndex])
											{
												if(builder.Length > 0)
												{
													builder.Append("\n\n");
												}
												builder.Append("Execution Index: ").Append(j);
												if(this.runtimeSchematic.Debug.Nodes[j].maxTime >= 0)
												{
													float tmpTime = this.runtimeSchematic.Debug.Nodes[j].maxTime - this.runtimeSchematic.Debug.Nodes[j].time;
													if(tmpTime > this.runtimeSchematic.Debug.Nodes[j].maxTime)
													{
														tmpTime = this.runtimeSchematic.Debug.Nodes[j].maxTime;
													}
													builder.Append(" (Duration: ").Append(tmpTime.ToString("0.00")).Append("/").
														Append(this.runtimeSchematic.Debug.Nodes[j].maxTime.ToString("0.00")).Append(")");
												}
												if(this.runtimeSchematic.Debug.Nodes[j].info != null)
												{
													for(int k = 0; k < this.runtimeSchematic.Debug.Nodes[j].info.Count; k++)
													{
														builder.Append("\n").Append(this.runtimeSchematic.Debug.Nodes[j].info[k]);
													}
												}
											}
										}
										if(builder.Length == 0)
										{
											builder.Append("Not executed.");
										}
										string debug = builder.ToString();
										EditorTool.BoldLabel("Debug Info");
										EditorGUILayout.BeginHorizontal();
										if(EditorTool.Button(EditorContent.Instance.CopyToClipboardContent, EditorTool.WIDTH_30))
										{
											EditorGUIUtility.systemCopyBuffer = debug;
										}
										EditorGUILayout.HelpBox(debug, MessageType.None);
										EditorGUILayout.EndHorizontal();
									}

									if(this.nodeEditor.Selected[i].IsEnabled)
									{
										EditorGUILayout.Separator();
										EditorGUILayout.Separator();
										EditorAutomation.Automate(this.nodeEditor.Selected[i], this);
									}
									EditorGUILayout.Separator();

									EditorAutomation.debugValues = null;
								}
								this.EndFoldout();
							}
						}
					}
				}
				// debug variables
				if(this.runtimeSchematic != null &&
					this.runtimeSchematic.Debug != null &&
					this.runtimeSchematic.HasVariables)
				{
					if(this.BeginFoldout("Local Variables (Debug)", "Show the local variables of the debugged schematic.", "", false))
					{
						this.VariableEditor.Show(this.runtimeSchematic.Variables);
					}
					this.EndFoldout();
				}
				this.CloseAllFoldouts();

				EditorGUILayout.EndScrollView();
				EditorGUILayout.EndVertical();

				this.UpdateFoldoutLimitList();
			}
		}


		/*
		============================================================================
		Callback functions
		============================================================================
		*/
		public override void InstanceCallback(string info, System.Object instance)
		{
			if(info == "buttons:randomnode")
			{
				if(instance is RandomNode)
				{
					if(EditorTool.Button("Add Node", "Adds a random node to the list.", ""))
					{
						ArrayHelper.Add(ref ((RandomNode)instance).random, -1);
					}
					if(((RandomNode)instance).random.Length > 1 &&
						EditorTool.Button("Remove Node", "Removes the last random node from the list.", ""))
					{
						ArrayHelper.RemoveAt(ref ((RandomNode)instance).random, ((RandomNode)instance).random.Length - 1);
					}
				}
			}
			else if(info == "setting:endslots")
			{
				if(instance is SchematicSettings)
				{
					SchematicSettings schematic = (SchematicSettings)instance;
					bool tmp = schematic.useEndSlots;
					EditorAutomation.Automate("useEndSlots", schematic, this, true);
					if(tmp != schematic.useEndSlots &&
						!schematic.useEndSlots)
					{
						schematic.stopIndex = -1;
						schematic.endIndex = -1;
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}

		public override void AutomationRemoveCallback(int arrayIndex, string info)
		{
			if(info == "actor")
			{
				this.RemoveActor(arrayIndex, this.schematicAsset.Settings);
			}
			else if(info == "prefab")
			{
				this.RemovePrefab(arrayIndex, this.schematicAsset.Settings);
			}
			else if(info == "audio")
			{
				this.RemoveResource(arrayIndex + 1, 3, this.schematicAsset.Settings);
			}
			else if(info == "audiomixer")
			{
				this.RemoveResource(arrayIndex + 1, 6, this.schematicAsset.Settings);
			}
			else if(info == "audiomixergroup")
			{
				this.RemoveResource(arrayIndex + 1, 7, this.schematicAsset.Settings);
			}
			else if(info == "sprite")
			{
				this.RemoveResource(arrayIndex + 1, 5, this.schematicAsset.Settings);
			}
			else if(info == "texture")
			{
				this.RemoveResource(arrayIndex + 1, 4, this.schematicAsset.Settings);
			}
			else if(info == "material")
			{
				this.RemoveResource(arrayIndex + 1, 8, this.schematicAsset.Settings);
			}
			else if(info == "physicmaterial")
			{
				this.RemoveResource(arrayIndex + 1, 9, this.schematicAsset.Settings);
			}
			else if(info == "physicsmaterial2D")
			{
				this.RemoveResource(arrayIndex + 1, 10, this.schematicAsset.Settings);
			}
			else
			{
				base.AutomationRemoveCallback(arrayIndex, info);
			}
		}

		private void RemoveActor(int index, IBaseData instance)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(typeof(SchematicObjectSelection).IsAssignableFrom(value.GetType()))
						{
							SchematicObjectSelection tmp = (SchematicObjectSelection)value;
							tmp.ActorRemoved(index);
							value = tmp;
							field[i].SetValue(instance, value);
						}
						else if(value is int)
						{
							EditorInfoAttribute attr = EditorAttributes.GetEditorInfo(field[i]);
							if(attr != null && attr.isTabPopup && attr.tabPopupID == 0)
							{
								int tmp = (int)value;
								if(tmp == index)
								{
									tmp = 0;
								}
								else if(tmp > index)
								{
									tmp--;
								}
								value = tmp;
								field[i].SetValue(instance, value);
							}
						}
						else if(typeof(IBaseData).IsAssignableFrom(value.GetType()))
						{
							this.RemoveActor(index, value as IBaseData);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.RemoveActor(index, tmp[j]);
							}
						}
					}
				}
			}
		}

		private void RemovePrefab(int index, IBaseData instance)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(typeof(SchematicObjectSelection).IsAssignableFrom(field[i].FieldType))
						{
							SchematicObjectSelection tmp = (SchematicObjectSelection)value;
							tmp.PrefabRemoved(index);
							value = tmp;
							field[i].SetValue(instance, value);
						}
						else if(value is int)
						{
							EditorInfoAttribute attr = EditorAttributes.GetEditorInfo(field[i]);
							if(attr != null && attr.isTabPopup && attr.tabPopupID == 2)
							{
								int tmp = (int)value;
								if(tmp == index)
								{
									tmp = 0;
								}
								else if(tmp > index)
								{
									tmp--;
								}
								value = tmp;
								field[i].SetValue(instance, value);
							}
						}
						else if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							this.RemovePrefab(index, value as IBaseData);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.RemovePrefab(index, tmp[j]);
							}
						}
					}
				}
			}
		}

		private void RemoveResource(int index, int popupID, IBaseData instance)
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is int)
						{
							EditorInfoAttribute attr = EditorAttributes.GetEditorInfo(field[i]);
							if(attr != null && attr.isTabPopup && attr.tabPopupID == popupID)
							{
								int tmp = (int)value;
								if(tmp == index)
								{
									tmp = 0;
								}
								else if(tmp > index)
								{
									tmp--;
								}
								value = tmp;
								field[i].SetValue(instance, value);
							}
						}
						else if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							this.RemoveResource(index, popupID, value as IBaseData);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.RemoveResource(index, popupID, tmp[j]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		private void DoChecks()
		{
			if(this.schematicAsset != null)
			{
				// remove empty nodes
				for(int i = 0; i < this.schematicAsset.Settings.node.Length; i++)
				{
					if(this.schematicAsset.Settings.node[i] == null)
					{
						CommentNode tmp = new CommentNode();
						tmp.comment = "null node loaded";
						this.schematicAsset.Settings.node[i] = tmp;
						Debug.LogWarning("Replacing null node at index " + i + " with comment node.\n" +
							"This can be the result of a custom node script that has been removed from the project.\n" +
							"Saving the schematic will also save the comment the node.");
					}
				}

				// tab popup list 0
				this.popupList0 = new string[this.schematicAsset.Settings.actor.Length];
				for(int i = 0; i < this.popupList0.Length; i++)
				{
					this.popupList0[i] = this.GetActorName(i, this.schematicAsset.Settings.actor[i]);
				}

				// tab popup list 2
				this.popupList2 = new string[this.schematicAsset.Settings.prefab.Length];
				for(int i = 0; i < this.popupList2.Length; i++)
				{
					if(this.schematicAsset.Settings.prefab[i].name != "")
					{
						this.popupList2[i] = new StringBuilder("Prefab ").Append(i).Append(": ").
							Append(this.schematicAsset.Settings.prefab[i].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder("Prefab ").Append(i);
						for(int j = 0; j < this.schematicAsset.Settings.prefab[i].prefab.Length; j++)
						{
							if(this.schematicAsset.Settings.prefab[i].prefab[j].prefab.settings.EditorAsset != null)
							{
								builder.Append(": ").Append(this.schematicAsset.Settings.prefab[i].prefab[j].prefab.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList2[i] = builder.ToString();
					}
				}

				// tab popup list 3
				this.popupList3 = new string[this.schematicAsset.Settings.audioClip.Length + 1];
				this.popupList3[0] = "Select Audio Clip";
				for(int i = 1; i < this.popupList3.Length; i++)
				{
					int clipIndex = i - 1;
					if(this.schematicAsset.Settings.audioClip[clipIndex].name != "")
					{
						this.popupList3[i] = new StringBuilder(clipIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.audioClip[clipIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(clipIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.audioClip[clipIndex].clip.Length; j++)
						{
							if(this.schematicAsset.Settings.audioClip[clipIndex].clip[j].clip.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.audioClip[clipIndex].clip[j].clip.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList3[i] = builder.ToString();
					}
				}

				// tab popup list 4
				this.popupList4 = new string[this.schematicAsset.Settings.texture.Length + 1];
				this.popupList4[0] = "Select Texture";
				for(int i = 1; i < this.popupList4.Length; i++)
				{
					int texIndex = i - 1;
					if(this.schematicAsset.Settings.texture[texIndex].name != "")
					{
						this.popupList4[i] = new StringBuilder(texIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.texture[texIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(texIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.texture[texIndex].texture.Length; j++)
						{
							if(this.schematicAsset.Settings.texture[texIndex].texture[j].texture.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.texture[texIndex].texture[j].texture.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList4[i] = builder.ToString();
					}
				}

				// tab popup list 5
				this.popupList5 = new string[this.schematicAsset.Settings.sprite.Length + 1];
				this.popupList5[0] = "Select Sprite";
				for(int i = 1; i < this.popupList5.Length; i++)
				{
					int spIndex = i - 1;
					if(this.schematicAsset.Settings.sprite[spIndex].name != "")
					{
						this.popupList5[i] = new StringBuilder(spIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.sprite[spIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(spIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.sprite[spIndex].sprite.Length; j++)
						{
							if(this.schematicAsset.Settings.sprite[spIndex].sprite[j].sprite.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.sprite[spIndex].sprite[j].sprite.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList5[i] = builder.ToString();
					}
				}

				// tab popup list 6
				this.popupList6 = new string[this.schematicAsset.Settings.audioMixer.Length + 1];
				this.popupList6[0] = "Select Audio Mixer";
				for(int i = 1; i < this.popupList6.Length; i++)
				{
					int mixerIndex = i - 1;
					if(this.schematicAsset.Settings.audioMixer[mixerIndex].name != "")
					{
						this.popupList6[i] = new StringBuilder(mixerIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.audioMixer[mixerIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(mixerIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.audioMixer[mixerIndex].mixer.Length; j++)
						{
							if(this.schematicAsset.Settings.audioMixer[mixerIndex].mixer[j].mixer.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.audioMixer[mixerIndex].mixer[j].mixer.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList6[i] = builder.ToString();
					}
				}

				// tab popup list 7
				this.popupList7 = new string[this.schematicAsset.Settings.audioMixerGroup.Length + 1];
				this.popupList7[0] = "Select Audio Mixer Group";
				for(int i = 1; i < this.popupList7.Length; i++)
				{
					int mixerGroupIndex = i - 1;
					if(this.schematicAsset.Settings.audioMixerGroup[mixerGroupIndex].name != "")
					{
						this.popupList7[i] = new StringBuilder(mixerGroupIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.audioMixerGroup[mixerGroupIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(mixerGroupIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.audioMixerGroup[mixerGroupIndex].mixerGroup.Length; j++)
						{
							if(this.schematicAsset.Settings.audioMixerGroup[mixerGroupIndex].mixerGroup[j].mixerGroup.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.audioMixerGroup[mixerGroupIndex].mixerGroup[j].mixerGroup.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList7[i] = builder.ToString();
					}
				}

				// tab popup list 8
				this.popupList8 = new string[this.schematicAsset.Settings.material.Length + 1];
				this.popupList8[0] = "Select Material";
				for(int i = 1; i < this.popupList8.Length; i++)
				{
					int materialIndex = i - 1;
					if(this.schematicAsset.Settings.material[materialIndex].name != "")
					{
						this.popupList8[i] = new StringBuilder(materialIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.material[materialIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(materialIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.material[materialIndex].material.Length; j++)
						{
							if(this.schematicAsset.Settings.material[materialIndex].material[j].material.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.material[materialIndex].material[j].material.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList8[i] = builder.ToString();
					}
				}

				// tab popup list 9
				this.popupList9 = new string[this.schematicAsset.Settings.physicMaterial.Length + 1];
				this.popupList9[0] = "Select Physic Material";
				for(int i = 1; i < this.popupList9.Length; i++)
				{
					int materialIndex = i - 1;
					if(this.schematicAsset.Settings.physicMaterial[materialIndex].name != "")
					{
						this.popupList9[i] = new StringBuilder(materialIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.physicMaterial[materialIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(materialIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.physicMaterial[materialIndex].material.Length; j++)
						{
							if(this.schematicAsset.Settings.physicMaterial[materialIndex].material[j].material.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.physicMaterial[materialIndex].material[j].material.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList9[i] = builder.ToString();
					}
				}

				// tab popup list 10
				this.popupList10 = new string[this.schematicAsset.Settings.physicsMaterial2D.Length + 1];
				this.popupList10[0] = "Select Physics Material 2D";
				for(int i = 1; i < this.popupList10.Length; i++)
				{
					int materialIndex = i - 1;
					if(this.schematicAsset.Settings.physicsMaterial2D[materialIndex].name != "")
					{
						this.popupList10[i] = new StringBuilder(materialIndex.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.physicsMaterial2D[materialIndex].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(materialIndex.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.physicsMaterial2D[materialIndex].material.Length; j++)
						{
							if(this.schematicAsset.Settings.physicsMaterial2D[materialIndex].material[j].material.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.physicsMaterial2D[materialIndex].material[j].material.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList10[i] = builder.ToString();
					}
				}



				// tab popup list 11
				this.popupList11 = new string[this.schematicAsset.Settings.texture.Length];
				for(int i = 0; i < this.popupList11.Length; i++)
				{
					if(this.schematicAsset.Settings.texture[i].name != "")
					{
						this.popupList11[i] = new StringBuilder(i.ToString()).Append(": ").
							Append(this.schematicAsset.Settings.texture[i].name).ToString();
					}
					else
					{
						StringBuilder builder = new StringBuilder(i.ToString()).Append(": ");
						for(int j = 0; j < this.schematicAsset.Settings.texture[i].texture.Length; j++)
						{
							if(this.schematicAsset.Settings.texture[i].texture[j].texture.settings.EditorAsset != null)
							{
								builder.Append(this.schematicAsset.Settings.texture[i].texture[j].texture.settings.EditorAsset.name);
								break;
							}
						}
						this.popupList11[i] = builder.ToString();
					}
				}
			}
		}

		private string GetActorName(int i, SchematicActor actor)
		{
			if(actor.setName)
			{
				return "Actor " + i + ": " + actor.actorName.Current;
			}
			return "Actor " + i + ": " + actor.settings.EditorName;
		}

		public override string[] GetPopupList(int id)
		{
			if(id == 0)
			{
				return this.popupList0;
			}
			else if(id == 1)
			{
				return this.popupList1;
			}
			else if(id == 2)
			{
				return this.popupList2;
			}
			else if(id == 3)
			{
				return this.popupList3;
			}
			else if(id == 4)
			{
				return this.popupList4;
			}
			else if(id == 5)
			{
				return this.popupList5;
			}
			else if(id == 6)
			{
				return this.popupList6;
			}
			else if(id == 7)
			{
				return this.popupList7;
			}
			else if(id == 8)
			{
				return this.popupList8;
			}
			else if(id == 9)
			{
				return this.popupList9;
			}
			else if(id == 10)
			{
				return this.popupList10;
			}
			else if(id == 11)
			{
				return this.popupList11;
			}
			return new string[0];
		}
	}
}
