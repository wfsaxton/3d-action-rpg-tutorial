﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class SceneWizard_BaseAddMachine
	{

	}

	[EditorSettingInfo("Animation Machine", "")]
	public class SceneWizard_AddMachine_AnimationMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<AnimationMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Application Machine", "")]
	public class SceneWizard_AddMachine_ApplicationMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<ApplicationMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Auto Machine", "")]
	public class SceneWizard_AddMachine_AutoMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<AutoMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Collision Machine", "")]
	public class SceneWizard_AddMachine_CollisionMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<CollisionMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Interaction Machine", "")]
	public class SceneWizard_AddMachine_InteractionMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<InteractionMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Render Machine", "")]
	public class SceneWizard_AddMachine_RenderMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<RenderMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Tagged Machine", "")]
	public class SceneWizard_AddMachine_TaggedMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<TaggedMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Template Machine", "")]
	public class SceneWizard_AddMachine_TemplateMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<TemplateMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Tick Machine", "")]
	public class SceneWizard_AddMachine_TickMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<TickMachineComponent>();
				}
			}
		}
	}

	[EditorSettingInfo("Trigger Machine", "")]
	public class SceneWizard_AddMachine_TriggerMachine : SceneWizard_BaseAddMachine
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<TriggerMachineComponent>();
				}
			}
		}
	}
}
