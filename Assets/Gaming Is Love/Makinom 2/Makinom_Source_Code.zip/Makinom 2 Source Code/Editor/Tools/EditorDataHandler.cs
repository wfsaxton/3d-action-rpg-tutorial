﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;
using System.Collections;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public delegate void EditorDataLoadedDelegate(object instance);

	public class EditorDataHandler
	{
		// instance
		private static EditorDataHandler instance;

		private static System.Object instanceLock = new System.Object();

		private MakinomEditorAsset editorAsset;

		private Dictionary<System.Type, IAssetList> assets = new Dictionary<System.Type, IAssetList>();

		private List<EditorDataChangeInformation> dataChanges = new List<EditorDataChangeInformation>();

		public List<Object> AllAssets = new List<Object>();


		// text codes
		private List<TextCodeAttribute> textCodes;

		private Dictionary<System.Type, TextCodeAttribute> textCodeLookup;

		private EditorDataHandler()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of EditorDataHandler!");
			}
			else
			{
				instance = this;
				this.FindAssets();
			}
		}

		public static EditorDataHandler Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							instance = new EditorDataHandler();
						}
					}
				}
				return instance;
			}
		}

		public MakinomEditorAsset EditorAsset
		{
			get
			{
				if(this.editorAsset == null)
				{
					this.editorAsset = MakinomAssetHelper.LoadEditorAsset(true);
				}
				return this.editorAsset;
			}
		}


		/*
		============================================================================
		Asset functions
		============================================================================
		*/
		public IMakinomGenericAsset GetAssetAtIndex(System.Type assetType, int index)
		{
			if(assetType != null)
			{
				IAssetList assetList;
				if(this.assets.TryGetValue(assetType, out assetList))
				{
					return assetList.GetAssetAt(index);
				}
			}
			return null;
		}

		public IMakinomGenericAsset GetAssetForGUID(System.Type assetType, string guid)
		{
			if(assetType != null)
			{
				IAssetList assetList;
				if(this.assets.TryGetValue(assetType, out assetList))
				{
					return assetList.GetAssetForGUID(guid);
				}
			}
			return null;
		}

		public string IndexToGUID(System.Type assetType, int index)
		{
			if(assetType != null)
			{
				IAssetList assetList;
				if(this.assets.TryGetValue(assetType, out assetList))
				{
					return assetList.IndexToGUID(index);
				}
			}
			return "";
		}

		public int AssetToIndex(System.Type assetType, IMakinomGenericAsset asset)
		{
			if(assetType != null)
			{
				IAssetList assetList;
				if(this.assets.TryGetValue(assetType, out assetList))
				{
					return assetList.AssetToIndex(asset);
				}
			}
			return 0;
		}

		public IMakinomGenericAsset Add(System.Type assetType)
		{
			if(assetType != null)
			{
				IAssetList assetList;
				if(this.assets.TryGetValue(assetType, out assetList))
				{
					return assetList.Add();
				}
			}
			return null;
		}


		/*
		============================================================================
		Asset list functions
		============================================================================
		*/
		public void FindAssets()
		{
			this.AllAssets.Clear();
			string[] guids = AssetDatabase.FindAssets("", MakinomAssetHelper.DATA_SEARCH_PATH);
			for(int i = 0; i < guids.Length; i++)
			{
				Object asset = AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(guids[i]), typeof(IMakinomGenericAsset));
				if(asset != null)
				{
					this.AllAssets.Add(asset);
				}
			}

			if(this.assets.Count == 0)
			{
				List<System.Type> assetTypes = EditorReflection.Instance.GetMakinomAssetTypes();
				System.Type listType = typeof(GenericAssetList<>);
				for(int i = 0; i < assetTypes.Count; i++)
				{
					if(assetTypes[i] != null)
					{
						IAssetList assetList = System.Activator.CreateInstance(
							listType.MakeGenericType(new System.Type[] { assetTypes[i] })) as IAssetList;
						if(assetList != null)
						{
							this.assets.Add(assetTypes[i], assetList);
						}
					}
				}
			}
			else
			{
				foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
				{
					pair.Value.FindAssets();
				}
			}
		}

		public IAssetList GetAssetList(System.Type type)
		{
			IAssetList list;
			if(type != null &&
				this.assets.TryGetValue(type, out list))
			{
				return list;
			}
			return null;
		}

		public GenericAssetList<T> GetAssets<T>() where T : ScriptableObject, IMakinomGenericAsset
		{
			System.Type type = typeof(T);
			if(type != null)
			{
				if(this.assets.ContainsKey(type))
				{
					return (GenericAssetList<T>)this.assets[type];
				}
				else
				{
					GenericAssetList<T> assetList = new GenericAssetList<T>();
					this.assets.Add(type, assetList);
					return assetList;
				}
			}
			return null;
		}

		public List<IMakinomGenericAsset> GetAssets(System.Type type)
		{
			List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
			if(type != null)
			{
				if(this.assets.ContainsKey(type))
				{
					this.assets[type].GetAssets(ref list);
				}
				else
				{
					string[] guids = AssetDatabase.FindAssets("t:" + type.Name, MakinomAssetHelper.DATA_SEARCH_PATH);
					for(int i = 0; i < guids.Length; i++)
					{
						UnityEngine.Object asset = AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(guids[i]), type);
						if(asset != null)
						{
							IMakinomGenericAsset tmp = (IMakinomGenericAsset)asset;
							if(!Application.isPlaying)
							{
								tmp.ClearData();
								tmp.LoadData();
							}
							EditorDataHandler.DataLoaded(tmp.EditorSettings);
							list.Add(tmp);
						}
					}
				}
			}
			return list;
		}

		public List<IMakinomGenericAsset> GetAllAssets()
		{
			List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.GetAssets(ref list);
			}
			return list;
		}

		public static List<IMakinomGenericAsset> FindAssets(System.Type type)
		{
			List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
			if(type != null)
			{
				string[] guids = AssetDatabase.FindAssets("t:" + type.Name, MakinomAssetHelper.DATA_SEARCH_PATH);
				for(int i = 0; i < guids.Length; i++)
				{
					UnityEngine.Object asset = AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(guids[i]), type);
					if(asset != null)
					{
						IMakinomGenericAsset tmp = (IMakinomGenericAsset)asset;
						if(!Application.isPlaying)
						{
							tmp.ClearData();
							tmp.LoadData();
						}
						EditorDataHandler.DataLoaded(tmp.EditorSettings);
						list.Add(tmp);
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Text code functions
		============================================================================
		*/
		public List<TextCodeAttribute> TextCodes
		{
			get
			{
				if(this.textCodes == null)
				{
					Dictionary<System.Type, TextCodeAttribute> list = ReflectionTypeHandler.Instance.GetTextCodes();
					this.textCodes = new List<TextCodeAttribute>(list.Values);
					this.textCodes.Sort(new TextCodeAttribute.Sorter());
				}
				return this.textCodes;
			}
		}

		public TextCodeAttribute GetTextCodeForAsset(System.Type assetType)
		{
			if(this.textCodeLookup == null)
			{
				this.textCodeLookup = new Dictionary<System.Type, TextCodeAttribute>();
				List<TextCodeAttribute> list = this.TextCodes;
				for(int i = 0; i < list.Count; i++)
				{
					this.textCodeLookup.Add(list[i].assetType, list[i]);
				}
			}
			if(this.textCodeLookup.ContainsKey(assetType))
			{
				return this.textCodeLookup[assetType];
			}
			return null;
		}


		/*
		============================================================================
		Data changes functions
		============================================================================
		*/
		public bool HasDataChanges
		{
			get { return this.dataChanges.Count > 0; }
		}

		public void AddDataChange(EditorDataChangeInformation change)
		{
			this.dataChanges.Add(change);
		}

		public void ClearDataChanges()
		{
			this.dataChanges.Clear();
		}

		public List<System.Type> GetChangeTypes()
		{
			List<System.Type> list = new List<System.Type>();
			if(this.dataChanges.Count > 0)
			{
				System.Type langType = typeof(LanguageAsset);

				for(int i = 0; i < this.dataChanges.Count; i++)
				{
					if(!list.Contains(this.dataChanges[i].assetType))
					{
						list.Add(this.dataChanges[i].assetType);
					}
				}
			}
			return list;
		}

		public bool UseDataChanges<T>(T instance)
		{
			bool changed = false;
			for(int i = 0; i < this.dataChanges.Count; i++)
			{
				if(EditorDataChangeInformationType.Remove == this.dataChanges[i].changeType)
				{
					this.DataRemoved(instance, this.dataChanges[i].assetType, this.dataChanges[i].asset,
						this.dataChanges[i].oldGUID, this.dataChanges[i].newGUID, ref changed);
				}
				else if(EditorDataChangeInformationType.SubDataRemoved == this.dataChanges[i].changeType)
				{
					this.SubDataRemoved(instance, this.dataChanges[i].assetType, this.dataChanges[i].asset,
						this.dataChanges[i].index, this.dataChanges[i].count, ref changed);
				}
				else if(EditorDataChangeInformationType.GUIDChange == this.dataChanges[i].changeType)
				{
					this.DataGUIDChanged(instance, this.dataChanges[i].assetType,
						this.dataChanges[i].oldGUID, this.dataChanges[i].newGUID, ref changed);
				}
				else if(EditorDataChangeInformationType.UISystemChange == this.dataChanges[i].changeType)
				{
					this.DataUISystemChanged(instance, ref changed);
				}
			}
			return changed;
		}


		/*
		============================================================================
		Save functions
		============================================================================
		*/
		public void GetFileDifferences(bool encrypt, DataFile.SaveFormatType format, ref List<string> list, ref Dictionary<IMakinomGenericAsset, DataFile> dataFiles)
		{
			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.GetFileDifferences(encrypt, format, ref list, ref dataFiles);
			}
		}

		public void SaveChanges(bool encrypt, DataFile.SaveFormatType format, string dataPath, bool saveAssetDatabase, string saveTime, Dictionary<IMakinomGenericAsset, DataFile> dataFiles)
		{
			for(int i = 0; i < this.dataChanges.Count; i++)
			{
				if(EditorDataChangeInformationType.Remove == this.dataChanges[i].changeType &&
					this.dataChanges[i].asset != null)
				{
					string path = AssetDatabase.GetAssetPath(this.dataChanges[i].asset as UnityEngine.Object);
					if(!string.IsNullOrEmpty(path))
					{
						AssetDatabase.DeleteAsset(path);
					}
				}
			}

			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.SaveChanges(encrypt, format, dataPath, saveAssetDatabase, saveTime, dataFiles);
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public void GetVariables(ref List<string> list)
		{
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				DataSerializer.GetVariables(setting[i], ref list);
			}

			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.GetVariables(ref list);
			}
		}

		public void ReplaceVariable(string oldKey, string newKey)
		{
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				DataSerializer.ReplaceVariable(setting[i], oldKey, newKey);
			}

			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.ReplaceVariable(oldKey, newKey);
			}
		}

		public void GetLanguageExport(bool resetExportIDs, GetInt getExportID, ref List<LanguageData.Export> export)
		{
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				DataSerializer.GetLanguageExport(setting[i], resetExportIDs, getExportID, "", ref export);
			}

			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.GetLanguageExport(resetExportIDs, getExportID, ref export);
			}
		}

		public void GetLanguageExport(bool resetExportIDs, GetInt getExportID, ref Dictionary<string, List<LanguageData.Export>> exportFiles)
		{
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				List<LanguageData.Export> export = new List<LanguageData.Export>();
				DataSerializer.GetLanguageExport(setting[i], resetExportIDs, getExportID, "", ref export);
				if(export.Count > 0)
				{
					exportFiles.Add(setting[i].Filename, export);
				}
			}

			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				List<LanguageData.Export> export = new List<LanguageData.Export>();
				pair.Value.GetLanguageExport(resetExportIDs, getExportID, ref export);
				if(export.Count > 0)
				{
					exportFiles.Add(pair.Key.Name, export);
				}
			}
		}

		public void SetLanguageImport(bool[] importLanguage, LanguageAsset[] languageAsset, Dictionary<int, LanguageData.Import> import)
		{
			bool hasImported = false;
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				DataSerializer.SetLanguageImport(setting[i], ref hasImported, importLanguage, languageAsset, import);
				this.CheckLanguageImportAssetReferences(setting[i]);
			}

			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				pair.Value.SetLanguageImport(importLanguage, languageAsset, import);
			}
		}

		public void CheckLanguageImportAssetReferences<T>(T instance) where T : IBaseData
		{
			if(instance is TextContent)
			{
				TextContent tmp = instance as TextContent;
				EditorTextAreaControl.CheckAssetReferences(ref tmp);
			}
			else if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					// other IBaseData classes
					if(value is IBaseData)
					{
						this.CheckLanguageImportAssetReferences((IBaseData)value);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								this.CheckLanguageImportAssetReferences(tmp[j]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Data change functions
		============================================================================
		*/
		public void Removed(System.Type assetType, IMakinomGenericAsset asset, string oldGUID)
		{
			if(assetType != null &&
				asset != null)
			{
				bool changed = false;
				string newGUID = this.IndexToGUID(assetType, 0);

				// update settings
				BaseSettings[] setting = Maki.Data.All;
				for(int i = 0; i < setting.Length; i++)
				{
					this.DataRemoved(setting[i], assetType, asset, oldGUID, newGUID, ref changed);
				}

				// update assets
				foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
				{
					List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
					pair.Value.GetAssets(ref list);
					for(int i = 0; i < list.Count; i++)
					{
						this.DataRemoved(list[i].EditorSettings, assetType, asset, oldGUID, newGUID, ref changed);
					}
				}

				this.AddDataChange(new EditorDataChangeInformation(
					EditorDataChangeInformationType.Remove, assetType, asset));
			}
		}

		public void SubDataRemoved(System.Type assetType, IMakinomGenericAsset asset, int index)
		{
			if(assetType != null &&
				asset != null)
			{
				bool changed = false;
				int count = asset.GetSubDataCount();

				// update settings
				BaseSettings[] setting = Maki.Data.All;
				for(int i = 0; i < setting.Length; i++)
				{
					this.SubDataRemoved(setting[i], assetType, asset, index, count, ref changed);
				}

				// update assets
				foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
				{
					List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
					pair.Value.GetAssets(ref list);
					for(int i = 0; i < list.Count; i++)
					{
						this.SubDataRemoved(list[i].EditorSettings, assetType, asset, index, count, ref changed);
					}
				}

				this.AddDataChange(new EditorDataChangeInformation(
					EditorDataChangeInformationType.SubDataRemoved, assetType, asset, index, count));
			}
		}

		public void GUIDChanged(System.Type assetType, string oldGUID, string newGUID)
		{
			if(assetType != null)
			{
				bool changed = false;

				// update settings
				BaseSettings[] setting = Maki.Data.All;
				for(int i = 0; i < setting.Length; i++)
				{
					this.DataGUIDChanged(setting[i], assetType, oldGUID, newGUID, ref changed);
				}

				// update assets
				foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
				{
					List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
					pair.Value.GetAssets(ref list);
					for(int i = 0; i < list.Count; i++)
					{
						this.DataGUIDChanged(list[i].EditorSettings, assetType, oldGUID, newGUID, ref changed);
					}
				}

				this.AddDataChange(new EditorDataChangeInformation(
					EditorDataChangeInformationType.GUIDChange, assetType, oldGUID, newGUID));
			}
		}


		/*
		============================================================================
		Automatic data update functions
		============================================================================
		*/
		public static void DataHandlerLoaded()
		{
			if(instance != null)
			{
				instance.FindAssets();
			}
			else
			{
				new EditorDataHandler();
			}
			for(int i = 0; i < Maki.Data.All.Length; i++)
			{
				EditorDataHandler.DataLoaded(Maki.Data.All[i]);
			}
		}

		public static void DataLoaded<T>(T instance)
		{
			if(instance != null)
			{
				EditorDataLoadedDelegate[] dataLoadedDelegate = EditorReflection.Instance.GetDataLoadedDelegates(instance.GetType());
				for(int i = 0; i < dataLoadedDelegate.Length; i++)
				{
					try
					{
						dataLoadedDelegate[i](instance);
					}
					catch(System.Exception ex)
					{
						// silent
					}
				}
			}
		}

		public static EditorDataLoadedDelegate CreateDataLoadedDelegate(FieldInfo field)
		{
			if(typeof(AssetSource).IsAssignableFrom(field.FieldType))
			{
				return delegate(object instance)
				{
					object value = field.GetValue(instance);
					if(value is AssetSource)
					{
						AssetSourceEditor.DataLoaded((AssetSource)value);
					}
				};
			}
			else if(typeof(IBaseData).IsAssignableFrom(field.FieldType))
			{
				return delegate(object instance)
				{
					object value = field.GetValue(instance);
					if(value is IBaseData)
					{
						EditorDataHandler.DataLoaded((IBaseData)value);
					}
				};
			}
			else if(typeof(IBaseData[]).IsAssignableFrom(field.FieldType))
			{
				return delegate (object instance)
				{
					object value = field.GetValue(instance);
					if(value is IBaseData[])
					{
						IBaseData[] tmp2 = (IBaseData[])value;
						for(int j = 0; j < tmp2.Length; j++)
						{
							EditorDataHandler.DataLoaded(tmp2[j]);
						}
					}
				};
			}
			return null;
		}

		public void DataRemoved<T>(T instance, System.Type assetType, IMakinomGenericAsset asset,
			string oldGUID, string newGUID, ref bool changed)
		{
			if(instance != null &&
				assetType != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is string)
						{
							string tmp = (string)value;
							this.ReplaceInString(ref tmp, assetType, oldGUID, newGUID);
							value = tmp;
							field[i].SetValue(instance, value);
							changed = true;
						}
						else if(value.GetType().IsArray)
						{
							EditorArrayAttribute arrayInfo = null;
							object[] attr = field[i].GetCustomAttributes(typeof(EditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as EditorArrayAttribute;
							}

							if(arrayInfo != null)
							{
								if(arrayInfo.removeCheckField != "")
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(tmp.Count > arrayInfo.noRemoveCount)
									{
										for(int j = 0; j < tmp.Count; j++)
										{
											if(tmp[j] != null)
											{
												object value2 = null;
												if(ReflectionTypeHandler.GetFieldValue(out value2, tmp[j], arrayInfo.removeCheckField) &&
													value2 is IAssetSelection)
												{
													AssetSource tmpSelection = value2 as AssetSource;
													if(tmpSelection != null &&
														assetType.Equals(tmpSelection.GetAssetType()) &&
														tmpSelection.Source.EditorAsset == asset)
													{
														tmp.RemoveAt(j--);
													}
												}
											}
										}
										value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
										field[i].SetValue(instance, value);
										changed = true;
									}
								}
								else if(typeof(IAssetSelection).IsAssignableFrom(value.GetType().GetElementType()))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									for(int j = 0; j < tmp.Count; j++)
									{
										AssetSource tmpSelection = tmp[j] as AssetSource;
										if(tmpSelection != null &&
											tmpSelection.Source.EditorAsset == asset)
										{
											tmp.RemoveAt(j--);
										}
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
									changed = true;
								}
							}
						}

						if(value is IAssetSelection)
						{
							AssetSource tmpSelection = value as AssetSource;
							if(tmpSelection != null &&
								tmpSelection.GetAssetType().Equals(assetType) &&
								tmpSelection.Source.EditorAsset == asset)
							{
								if(!tmpSelection.Source.GetType().Equals(typeof(ReferenceAssetSource<>)))
								{
									tmpSelection.SettingsType = ReflectionTypeHandler.GetGenericTypeName(typeof(ReferenceAssetSource<>));
								}
								tmpSelection.Source.EditorAsset = null;
								value = tmpSelection;
								field[i].SetValue(instance, value);
								changed = true;
							}
						}
						else if(value is IBaseData)
						{
							this.DataRemoved((IBaseData)value, assetType, asset, oldGUID, newGUID, ref changed);
						}
						else if(value is IBaseData[])
						{
							IBaseData[] tmp = (IBaseData[])value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.DataRemoved(tmp[j], assetType, asset, oldGUID, newGUID, ref changed);
							}
						}
					}
				}
			}
		}

		public void SubDataRemoved<T>(T instance, System.Type assetType, IMakinomGenericAsset asset, int index, int count, ref bool changed)
		{
			if(instance != null &&
				assetType != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is string)
						{
							string tmp = (string)value;
							this.ReplaceSubDataInString(ref tmp, assetType, asset.EditorSettings.GUID, index, count);
							value = tmp;
							field[i].SetValue(instance, value);
							changed = true;
						}
						else if(value is int)
						{
							EditorInfoAttribute info = null;
							object[] attr = field[i].GetCustomAttributes(typeof(EditorInfoAttribute), true);
							if(attr.Length > 0)
							{
								info = attr[0] as EditorInfoAttribute;
							}
							if(info != null &&
								info.isAssetSubDataPopup)
							{
								object fieldValue = null;
								if(ReflectionTypeHandler.GetFieldValue(out fieldValue, instance, info.assetSubDataField))
								{
									if(fieldValue is AssetSource)
									{
										AssetSource assetField = (AssetSource)fieldValue;
										if(assetField.Source.EditorAsset == asset)
										{
											int tmp = (int)value;
											if(tmp == index)
											{
												tmp = 0;
											}
											else if(tmp > index)
											{
												tmp--;
											}
											value = tmp;
											field[i].SetValue(instance, value);
											changed = true;
										}
									}
								}
							}
						}
						else if(value is IBaseData)
						{
							this.SubDataRemoved((IBaseData)value, assetType, asset, index, count, ref changed);
						}
						else if(value is IBaseData[])
						{
							IBaseData[] tmp = (IBaseData[])value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.SubDataRemoved(tmp[j], assetType, asset, index, count, ref changed);
							}
						}
					}
				}
			}
		}

		public void DataGUIDChanged<T>(T instance, System.Type assetType, string oldGUID, string newGUID, ref bool changed)
		{
			if(instance != null &&
				assetType != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						// update language strings
						if(value is string)
						{
							string tmp = (string)value;
							this.ReplaceInString(ref tmp, assetType, oldGUID, newGUID);
							value = tmp;
							field[i].SetValue(instance, value);
							changed = true;
						}
						else if(value is IBaseData)
						{
							this.DataGUIDChanged((IBaseData)value, assetType, oldGUID, newGUID, ref changed);
						}
						else if(value is IBaseData[])
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.DataGUIDChanged(tmp[j], assetType, oldGUID, newGUID, ref changed);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		UI system change functions
		============================================================================
		*/
		public void UISystemChanged()
		{
			bool changed = false;

			// update settings
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				this.DataUISystemChanged(setting[i], ref changed);
			}

			// update assets
			foreach(KeyValuePair<System.Type, IAssetList> pair in this.assets)
			{
				List<IMakinomGenericAsset> list = new List<IMakinomGenericAsset>();
				pair.Value.GetAssets(ref list);
				for(int i = 0; i < list.Count; i++)
				{
					this.DataUISystemChanged(list[i].EditorSettings, ref changed);
				}
			}

			this.AddDataChange(new EditorDataChangeInformation(
				EditorDataChangeInformationType.UISystemChange));
		}

		public void DataUISystemChanged<T>(T instance, ref bool changed)
		{
			if(instance != null)
			{
				IUISystemChanged change = instance as IUISystemChanged;
				if(change != null)
				{
					change.UISystemChanged();
					changed = true;
				}

				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value != null)
					{
						if(value is IBaseData)
						{
							this.DataUISystemChanged((IBaseData)value, ref changed);
						}
						else if(value is IBaseData[])
						{
							IBaseData[] tmp = (IBaseData[])value;
							for(int j = 0; j < tmp.Length; j++)
							{
								this.DataUISystemChanged(tmp[j], ref changed);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		private void SwapArrayList(ref ArrayList tmp, int index, bool down)
		{
			if(down ? index + 1 < tmp.Count : index < tmp.Count)
			{
				object obj = tmp[index];
				if(down)
				{
					tmp[index] = tmp[index + 1];
					tmp[index + 1] = obj;
				}
				else
				{
					tmp[index] = tmp[index - 1];
					tmp[index - 1] = obj;
				}
			}
		}

		private void ReplaceInString(ref string text, System.Type assetType, string oldGUID, string newGUID)
		{
			TextCodeAttribute textCodes = this.GetTextCodeForAsset(assetType);

			if(textCodes != null &&
				text.Contains(textCodes.baseTextCode))
			{
				// without 'TextCode.CloseTag' to also include text code options (e.g. icon size)
				for(int i = 0; i < textCodes.textCodes.Length; i++)
				{
					text = text.Replace(
						textCodes.textCodes[i] + oldGUID,
						textCodes.textCodes[i] + newGUID);
				}
			}
		}

		private void ReplaceSubDataInString(ref string text, System.Type assetType, string GUID, int index, int count)
		{
			TextCodeAttribute textCodes = this.GetTextCodeForAsset(assetType);

			if(textCodes != null &&
				text.Contains(textCodes.baseTextCode))
			{
				// without 'TextCode.CloseTag' to also include text code options (e.g. icon size)
				for(int i = 0; i < textCodes.textCodes.Length; i++)
				{
					text = text.Replace(
						textCodes.textCodes[i] + GUID + TextCode.SubData + index + TextCode.Quote,
						textCodes.textCodes[i] + GUID + TextCode.SubData + "0" + TextCode.Quote);
					for(int j = index + 1; j <= count; j++)
					{
						text = text.Replace(
							textCodes.textCodes[i] + GUID + TextCode.SubData + j + TextCode.Quote,
							textCodes.textCodes[i] + GUID + TextCode.SubData + (j - 1) + TextCode.Quote);
					}
				}
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public List<string> GetNames(System.Type assetType, bool addIndex)
		{
			IAssetList assetList = this.GetAssetList(assetType);
			if(assetList != null)
			{
				return assetList.GetNames(addIndex);
			}
			return new List<string>();
		}
	}
}
