
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	/// <summary>
	/// Editor GUI options and base editor functions.
	/// </summary>
	public static class EditorTool
	{
		public static readonly float SectionHeight = 34;

		public static readonly float SaveButtonHeight = 42;

		/*
		============================================================================
		Widths
		============================================================================
		*/

		/// <summary>
		/// GUILayoutOption width 15.
		/// </summary>
		public static GUILayoutOption WIDTH_15 = GUILayout.Width(15.0f);

		/// <summary>
		/// GUILayoutOption width 20.
		/// </summary>
		public static GUILayoutOption WIDTH_20 = GUILayout.Width(20.0f);

		/// <summary>
		/// GUILayoutOption width 25.
		/// </summary>
		public static GUILayoutOption WIDTH_25 = GUILayout.Width(25.0f);

		/// <summary>
		/// GUILayoutOption width 30.
		/// </summary>
		public static GUILayoutOption WIDTH_30 = GUILayout.Width(30.0f);

		/// <summary>
		/// GUILayoutOption width 45.
		/// </summary>
		public static GUILayoutOption WIDTH_45 = GUILayout.Width(45.0f);

		/// <summary>
		/// GUILayoutOption width 60.
		/// </summary>
		public static GUILayoutOption W_MICRO_BUTTON = GUILayout.Width(60.0f);

		/// <summary>
		/// GUILayoutOption width 100.
		/// </summary>
		public static GUILayoutOption W_SMALL_BUTTON = GUILayout.Width(100.0f);

		/// <summary>
		/// GUILayoutOption width 150.
		/// </summary>
		public static GUILayoutOption WIDTH_150 = GUILayout.Width(150.0f);

		/// <summary>
		/// GUILayoutOption width 200.
		/// </summary>
		public static GUILayoutOption W_MEDIUM_BUTTON = GUILayout.Width(200.0f);

		/// <summary>
		/// GUILayoutOption width 300.
		/// </summary>
		public static GUILayoutOption WIDTH = GUILayout.Width(300.0f);

		/// <summary>
		/// GUILayoutOption width 400.
		/// </summary>
		public static GUILayoutOption WIDTH_LONG = GUILayout.Width(400.0f);

		/// <summary>
		/// GUILayoutOption width 600.
		/// </summary>
		public static GUILayoutOption WIDTH_DOUBLE = GUILayout.Width(600.0f);

		/// <summary>
		/// GUILayoutOption width expand.
		/// </summary>
		public static GUILayoutOption W_EXPAND = GUILayout.ExpandWidth(true);

		/// <summary>
		/// GUILayoutOption width for title labels.
		/// </summary>
		public static GUILayoutOption WIDTH_LABEL
		{
			get { return GUILayout.Width(EditorGUIUtility.labelWidth - 2); }
		}


		/*
		============================================================================
		Heights
		============================================================================
		*/

		/// <summary>
		/// GUILayoutOption height 25.
		/// </summary>
		public static GUILayoutOption HEIGHT_OBJECT = GUILayout.Height(25);

		/// <summary>
		/// GUILayoutOption height 18.
		/// </summary>
		public static GUILayoutOption HEIGHT_18 = GUILayout.Height(18);


		/*
		============================================================================
		Settings highlighting
		============================================================================
		*/
		public static void BeginSettingsHighlight(int color)
		{
			if(Maki.EditorSettings.highlightValueFields)
			{
				if(color == 1)
				{
					EditorGUILayout.BeginVertical(EditorContent.Instance.SettingHighlightStyle1);
				}
				else if(color == 2)
				{
					EditorGUILayout.BeginVertical(EditorContent.Instance.SettingHighlightStyle2);
				}
				else if(color == 3)
				{
					EditorGUILayout.BeginVertical(EditorContent.Instance.SettingHighlightStyle3);
				}
				else if(color == 4)
				{
					EditorGUILayout.BeginVertical(EditorContent.Instance.SettingHighlightStyle4);
				}
				else if(color == 5)
				{
					EditorGUILayout.BeginVertical(EditorContent.Instance.SettingHighlightStyle5);
				}
				else
				{
					EditorGUILayout.BeginVertical(EditorContent.Instance.SettingHighlightStyle);
				}
			}
		}

		public static void EndSettingsHighlight()
		{
			if(Maki.EditorSettings.highlightValueFields)
			{
				EditorGUILayout.EndVertical();
			}
		}


		/*
		============================================================================
		Editor help text
		============================================================================
		*/
		/// <summary>
		/// Displays the editor help text at the lower left section of the editor window.
		/// </summary>
		/// <param name='scroll'>
		/// Reference to a Vector2 representing a scroll view used to display larger help texts.
		/// </param>
		public static void ShowEditorHelp(ref Vector2 scroll, float width, float height)
		{
			GUILayout.BeginVertical(EditorContent.Instance.BoxSlimStyle);

			GUIStyle tmp = new GUIStyle(EditorStyles.label);
			if(Maki.EditorSettings.setHelpTextColor)
			{
				tmp.normal.textColor = Maki.EditorSettings.helpTextColor;
			}
			tmp.fontStyle = FontStyle.Bold;
			tmp.wordWrap = true;
			tmp.alignment = TextAnchor.UpperLeft;
			tmp.richText = true;

			if(EditorContent.Instance.HelpHeader == "")
			{
				GUILayout.Label("Help", tmp);
			}
			else
			{
				GUILayout.Label(EditorContent.Instance.HelpHeader, tmp);
			}

			tmp.fontStyle = FontStyle.Normal;

			if(width > 0)
			{
				scroll = EditorGUILayout.BeginScrollView(scroll,
					GUILayout.Width(width),
					GUILayout.Height(height));
			}
			else
			{
				scroll = EditorGUILayout.BeginScrollView(scroll,
					GUILayout.Height(height));
			}

			GUILayout.Box(EditorContent.Instance.HelpText, tmp,
				EditorTool.W_EXPAND, GUILayout.ExpandHeight(true));

			EditorGUILayout.EndScrollView();

			EditorGUILayout.BeginHorizontal();
			if(EditorTool.Button(EditorContent.Instance.CopyToClipboardContent))
			{
				EditorGUIUtility.systemCopyBuffer = EditorContent.Instance.HelpHeader +
					": " + EditorContent.Instance.HelpText;
			}
			EditorGUI.BeginDisabledGroup(!EditorContent.Instance.HelpInfo.StartsWith("http"));
			if(EditorTool.Button(EditorContent.Instance.OpenLinkContent))
			{
				Application.OpenURL(EditorContent.Instance.HelpInfo);
			}
			EditorGUI.EndDisabledGroup();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			GUILayout.EndVertical();
		}

		/// <summary>
		/// Checks the editor help text should be set and sets it if check is valid.
		/// </summary>
		/// <param name='helpHeader'>
		/// The new helpt text header (field name).
		/// </param>
		/// <param name='helpText'>
		/// The new helpt text (field description).
		/// </param>
		public static void CheckHelpText(string helpHeader, string helpText, string helpInfo)
		{
			if(EditorHelpType.Hover == Maki.EditorSettings.editorHelpType)
			{
				if(Event.current.type == EventType.Repaint &&
					GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition))
				{
					EditorContent.Instance.SetEditorHelp(helpHeader, helpText, helpInfo);
				}
			}
			else if(EditorHelpType.Focus == Maki.EditorSettings.editorHelpType)
			{
				if(GUI.GetNameOfFocusedControl() == helpHeader)
				{
					EditorContent.Instance.SetEditorHelp(helpHeader, helpText, helpInfo);
				}
			}
			else if(EditorHelpType.Button == Maki.EditorSettings.editorHelpType)
			{
				if(EditorTool.Button("?", EditorTool.WIDTH_20))
				{
					EditorContent.Instance.SetEditorHelp(helpHeader, helpText, helpInfo);
				}
			}
		}


		/*
		============================================================================
		Drag bars
		============================================================================
		*/

		/// <summary>
		/// Displays a vertical drag bar.
		/// Performs vertical dragging.
		/// </summary>
		/// <param name='drag'>
		/// Reference to an <see cref="GamingIsLove.Makinom.Editor.EditorDragData"/> object.
		/// </param>
		public static void DragVertical(ref EditorDragData drag, bool inverse)
		{
			GUIStyle guiStyle = new GUIStyle();
			guiStyle.margin = new RectOffset(0, 0, 0, 0);
			guiStyle.padding = new RectOffset(0, 0, 0, 0);

			EditorGUILayout.BeginHorizontal(guiStyle, GUILayout.Height(5));
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();

			if(drag.isDragging && Event.current.type == EventType.MouseDrag)
			{
				drag.lastMove = inverse ?
					Event.current.delta.y :
					-Event.current.delta.y;
				drag.isDragging = true;
			}
			else
			{
				drag.lastMove = 0;
			}
			if(Event.current.type == EventType.Repaint)
			{
				drag.rect = GUILayoutUtility.GetLastRect();
			}
			if(!drag.isDragging && Event.current.type == EventType.MouseDown)
			{
				drag.isDragging = drag.rect.Contains(Event.current.mousePosition);
			}
			if(Event.current.type == EventType.MouseUp)
			{
				drag.isDragging = false;
			}
			EditorGUIUtility.AddCursorRect(drag.rect, MouseCursor.ResizeVertical);
		}

		/// <summary>
		/// Displays a horizontal drag bar.
		/// Performs horizontal dragging.
		/// </summary>
		/// <param name='drag'>
		/// Reference to an <see cref="GamingIsLove.Makinom.Editor.EditorDragData"/> object.
		/// </param>
		public static void DragHorizontal(ref EditorDragData drag, bool inverse)
		{
			GUIStyle guiStyle = new GUIStyle();
			guiStyle.margin = new RectOffset(0, 0, 0, 0);
			guiStyle.padding = new RectOffset(0, 0, 0, 0);

			EditorGUILayout.BeginVertical(guiStyle, GUILayout.Width(5));
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			if(drag.isDragging && Event.current.type == EventType.MouseDrag)
			{
				drag.lastMove = inverse ?
					-Event.current.delta.x :
					Event.current.delta.x;
				drag.isDragging = true;
			}
			else
			{
				drag.lastMove = 0;
			}

			if(Event.current.type == EventType.Repaint)
			{
				drag.rect = GUILayoutUtility.GetLastRect();
			}
			if(!drag.isDragging && Event.current.type == EventType.MouseDown)
			{
				drag.isDragging = drag.rect.Contains(Event.current.mousePosition);
			}
			if(Event.current.type == EventType.MouseUp)
			{
				drag.isDragging = false;
			}
			EditorGUIUtility.AddCursorRect(drag.rect, MouseCursor.ResizeHorizontal);
		}


		/*
		============================================================================
		Base stuff
		============================================================================
		*/

		/// <summary>
		/// Called befor every editor setting.
		/// </summary>
		public static void BeginSetting(string name, bool horizontal)
		{
			if(horizontal)
			{
				EditorGUILayout.BeginHorizontal();
			}
			GUI.SetNextControlName(name);
		}

		/// <summary>
		/// Called after every editor setting.
		/// </summary>
		public static void EndSetting(string helpHeader, string helpText, string helpInfo, bool horizontal)
		{
			EditorTool.CheckHelpText(helpHeader, helpText, helpInfo);
			if(horizontal)
			{
				EditorGUILayout.EndHorizontal();
			}
		}


		/*
		============================================================================
		Box and foldout
		============================================================================
		*/
		public static bool BeginFoldout(ref bool foldout, GUIContent content, string helpInfo)
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxStyle);
			GUI.SetNextControlName(content.text);
			foldout = EditorGUILayout.Foldout(foldout, content, true, EditorContent.Instance.FoldoutStyle);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			if(foldout && Maki.EditorSettings.showFoldoutHelp)
			{
				EditorGUILayout.HelpBox(content.tooltip, MessageType.Info);
			}
			GUILayout.Space(10);
			return foldout;
		}

		public static bool BeginFoldoutInspector(ref bool foldout, GUIContent content)
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxFoldoutInspectorStyle);
			foldout = EditorGUILayout.Foldout(foldout, content, true, EditorContent.Instance.FoldoutInspectorStyle);
			GUILayout.Space(10);
			return foldout;
		}

		public static bool BeginFoldoutInspector(ref bool foldout, GUIContent content, string helpInfo)
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxFoldoutInspectorStyle);
			GUI.SetNextControlName(content.text);
			foldout = EditorGUILayout.Foldout(foldout, content, true, EditorContent.Instance.FoldoutInspectorStyle);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			if(foldout && Maki.EditorSettings.showFoldoutHelp)
			{
				EditorGUILayout.HelpBox(content.tooltip, MessageType.Info);
			}
			GUILayout.Space(10);
			return foldout;
		}

		public static bool BeginFoldoutSearchFilter(ref bool foldout, GUIContent content, string helpInfo)
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxSearchFilterStyle);
			GUI.SetNextControlName(content.text);
			foldout = EditorGUILayout.Foldout(foldout, content, true, EditorContent.Instance.FoldoutStyle);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			if(foldout && Maki.EditorSettings.showFoldoutHelp)
			{
				EditorGUILayout.HelpBox(content.tooltip, MessageType.Info);
			}
			return foldout;
		}

		public static bool BeginFoldout(ref bool foldout, GUIContent content, string helpInfo, int depth)
		{
			GUIStyle foldoutStyle = new GUIStyle(EditorContent.Instance.FoldoutPrettyStyle);
			foldoutStyle.fontSize = Mathf.Max(16 - depth * 2, 11);
			//foldoutStyle.margin.bottom += foldoutStyle.fontSize / 2;

			GUIStyle boxStyle = new GUIStyle(EditorContent.Instance.BoxFoldoutPrettyStyle);
			if(depth > 0)
			{
				boxStyle.margin.left += 7;
				boxStyle.margin.right += 7;
			}
			boxStyle.margin.top = foldoutStyle.fontSize;
			boxStyle.margin.bottom = Mathf.Max(25 - depth * 5, 5);

			EditorGUILayout.BeginVertical(boxStyle);

			GUI.SetNextControlName(content.text);
			foldout = EditorGUILayout.Foldout(foldout, content, true, foldoutStyle);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			GUILayout.Space(5 + foldoutStyle.fontSize / 2);

			if(foldout && Maki.EditorSettings.showFoldoutHelp)
			{
				EditorGUILayout.HelpBox(content.tooltip, MessageType.Info);
			}
			return foldout;
		}

		public static void EndFoldout()
		{
			EditorGUILayout.EndVertical();
		}

		public static void BeginBox()
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxStyle);
		}

		public static void EndBox()
		{
			EditorGUILayout.Separator();
			EditorGUILayout.EndVertical();
		}


		/*
		============================================================================
		Labels
		============================================================================
		*/
		public static void Label(string text)
		{
			GUILayout.Label(text);
		}

		public static void BoldLabel(string text)
		{
			GUILayout.Label(text, EditorStyles.boldLabel);
		}

		public static void BoldLabel(GUIContent content)
		{
			GUILayout.Label(content, EditorStyles.boldLabel);
		}

		public static void Separator(int count)
		{
			for(int i = 0; i < count; i++)
			{
				EditorGUILayout.Separator();
			}
		}


		/*
		============================================================================
		Buttons
		============================================================================
		*/
		public static bool ShowButton(string name, string helpText, string helpInfo, GUILayoutOption option)
		{
			EditorTool.BeginSetting(name, true);
			bool press = EditorTool.Button(new GUIContent(name, helpText), option);
			EditorTool.EndSetting(name, helpText, helpInfo, true);
			return press;
		}

		public static bool ShowButton(GUIContent content, string helpText, string helpInfo, GUILayoutOption option)
		{
			EditorTool.BeginSetting(content.text, true);
			bool press = EditorTool.Button(content, option);
			EditorTool.EndSetting(content.text, helpText, helpInfo, true);
			return press;
		}

		public static bool ShowButton2(string name, string helpText, string helpInfo, GUILayoutOption option)
		{
			bool press = EditorTool.Button(new GUIContent(name, helpText), option);
			EditorTool.CheckHelpText(name, helpText, helpInfo);
			return press;
		}

		public static bool ShowButton2(string name, string helpText, string helpInfo, GUILayoutOption option, GUIStyle style)
		{
			bool press = GUILayout.Button(new GUIContent(name, helpText), style, option);
			EditorTool.CheckHelpText(name, helpText, helpInfo);
			return press;
		}

		public static bool ShowButton2(GUIContent content, string helpText, string helpInfo, params GUILayoutOption[] options)
		{
			bool press = EditorTool.Button(content, options);
			EditorTool.CheckHelpText(content.text, helpText, helpInfo);
			return press;
		}

		public static bool ShowButton2(GUIContent content, string helpText, string helpInfo, GUIStyle style, params GUILayoutOption[] options)
		{
			bool press = GUILayout.Button(content, style, options);
			EditorTool.CheckHelpText(content.text, helpText, helpInfo);
			return press;
		}

		public static bool ShowButtonNoNameNoWidth(GUIContent content, string helpText, string helpInfo)
		{
			bool press = EditorTool.Button(new GUIContent("", content.image, content.tooltip));
			EditorTool.CheckHelpText(content.text, helpText, helpInfo);
			return press;
		}

		public static bool MicroButton(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(name, helpText, helpInfo, EditorTool.W_MICRO_BUTTON);
		}

		public static bool MicroButton2(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton2(name, helpText, helpInfo, EditorTool.W_MICRO_BUTTON);
		}

		public static bool MicroButton2(GUIContent gc, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton2(gc, helpText, helpInfo, EditorTool.W_MICRO_BUTTON);
		}

		public static bool SmallButton(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(name, helpText, helpInfo, EditorTool.W_SMALL_BUTTON);
		}

		public static bool SmallButton(GUIContent gc, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(gc, helpText, helpInfo, EditorTool.W_SMALL_BUTTON);
		}

		public static bool SmallButton2(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton2(name, helpText, helpInfo, EditorTool.W_SMALL_BUTTON);
		}

		public static bool SmallButton2(GUIContent gc, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton2(gc, helpText, helpInfo, EditorTool.W_SMALL_BUTTON);
		}

		public static bool MediumButton(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(name, helpText, helpInfo, EditorTool.W_MEDIUM_BUTTON);
		}

		public static bool MediumButton(GUIContent gc, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(gc, helpText, helpInfo, EditorTool.W_MEDIUM_BUTTON);
		}

		public static bool MediumButton2(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton2(name, helpText, helpInfo, EditorTool.W_MEDIUM_BUTTON);
		}

		public static bool Button(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(name, helpText, helpInfo, EditorTool.WIDTH);
		}

		public static bool Button(GUIContent gc, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton(gc, helpText, helpInfo, EditorTool.WIDTH);
		}

		public static bool Button2(string name, string helpText, string helpInfo)
		{
			return EditorTool.ShowButton2(name, helpText, helpInfo, EditorTool.WIDTH);
		}

		public static bool Button(Texture image, params GUILayoutOption[] options)
		{
			return GUILayout.Button(image, EditorContent.Instance.ButtonStyle, options);
		}

		public static bool Button(GUIContent content, params GUILayoutOption[] options)
		{
			return GUILayout.Button(content, EditorContent.Instance.ButtonStyle, options);
		}

		public static bool Button(string text, params GUILayoutOption[] options)
		{
			return GUILayout.Button(text, EditorContent.Instance.ButtonStyle, options);
		}


		/*
		============================================================================
		Selection grid
		============================================================================
		*/
		public static void SelectionGrid(string controlName, ref int index, string[] names, int xCount)
		{
			GUI.SetNextControlName(controlName);
			int tmpIndex = index;
			index = GUILayout.SelectionGrid(index, names, xCount, EditorContent.Instance.SelectionGridStyle);
			if(tmpIndex != index)
			{
				GUI.FocusControl(controlName);
			}
		}

		public static void SelectionGrid(string controlName, ref int index, GUIContent[] names, int xCount)
		{
			GUI.SetNextControlName(controlName);
			int tmpIndex = index;
			index = GUILayout.SelectionGrid(index, names, xCount, EditorContent.Instance.SelectionGridStyle,
				GUILayout.ExpandWidth(true), GUILayout.MinWidth(100));
			if(tmpIndex != index)
			{
				GUI.FocusControl(controlName);
			}
		}

		public static void SelectionGridCenter(string controlName, ref int index, GUIContent[] names, int xCount)
		{
			GUI.SetNextControlName(controlName);
			int tmpIndex = index;
			index = GUILayout.SelectionGrid(index, names, xCount, EditorContent.Instance.SelectionGridCenterStyle,
				GUILayout.ExpandWidth(true), GUILayout.MinWidth(100));
			if(tmpIndex != index)
			{
				GUI.FocusControl(controlName);
			}
		}

		public static void SelectionGridCenter(string controlName, ref int index, GUIContent[] names, int xCount, int buttonWidth)
		{
			GUI.SetNextControlName(controlName);
			int tmpIndex = index;
			index = GUILayout.SelectionGrid(index, names, xCount, EditorContent.Instance.SelectionGridCenterStyle,
				GUILayout.Width(buttonWidth * xCount));
			if(tmpIndex != index)
			{
				GUI.FocusControl(controlName);
			}
		}

		public static void SelectionGridCenter(string controlName, ref int index, string[] names, int xCount, int buttonWidth)
		{
			GUI.SetNextControlName(controlName);
			int tmpIndex = index;
			index = GUILayout.SelectionGrid(index, names, xCount, EditorContent.Instance.SelectionGridCenterStyle,
				GUILayout.Width(buttonWidth * xCount));
			if(tmpIndex != index)
			{
				GUI.FocusControl(controlName);
			}
		}

		public static void SelectionGrid(ref int index, List<string> names)
		{
			GUIStyle selected = EditorContent.Instance.SelectionGridSelectedStyle;
			GUIStyle normal = EditorContent.Instance.SelectionGridStyle;
			for(int i = 0; i < names.Count; i++)
			{
				GUI.SetNextControlName("ListID: " + names[i]);
				if(GUILayout.Button(names[i],
					index == i ? selected : normal,
					EditorTool.W_EXPAND))
				{
					index = i;
				}
			}
		}

		public static void SelectionGrid(ref int index, List<BaseEditorTab> tabs)
		{
			GUIStyle selected = EditorContent.Instance.SelectionGridSelectedStyle;
			GUIStyle normal = EditorContent.Instance.SelectionGridStyle;
			for(int i = 0; i < tabs.Count; i++)
			{
				if(tabs[i].Header != "")
				{
					EditorGUILayout.Separator();
					EditorTool.BoldLabel(tabs[i].Header);
				}
				else if(tabs[i].AddSeparator &&
					Maki.EditorSettings.showSubSectionSeparators)
				{
					EditorGUILayout.Separator();
				}
				GUI.SetNextControlName(tabs[i].Name);
				bool pressed = GUILayout.Button(tabs[i].Name,
					index == i ? selected : normal,
					EditorTool.W_EXPAND);
				EditorTool.CheckHelpText(tabs[i].Name, tabs[i].HelpText, tabs[i].HelpInfo);
				if(pressed)
				{
					index = i;
				}
			}
		}

		public static bool SelectionGridButton(string name, string helpText, string helpInfo, bool isIndex)
		{
			GUI.SetNextControlName(name);
			bool press = GUILayout.Button(name, isIndex ?
					EditorContent.Instance.SelectionGridSelectedStyle :
					EditorContent.Instance.SelectionGridStyle,
				EditorTool.W_EXPAND);
			EditorTool.CheckHelpText(name, helpText, helpInfo);
			return press;
		}

		public static bool SelectionGridButton(GUIContent name, string helpText, string helpInfo, bool isIndex)
		{
			GUI.SetNextControlName(name.text);
			bool press = GUILayout.Button(name, isIndex ?
					EditorContent.Instance.SelectionGridSelectedStyle :
					EditorContent.Instance.SelectionGridStyle,
				EditorTool.W_EXPAND);
			EditorTool.CheckHelpText(name.text, helpText, helpInfo);
			return press;
		}


		/*
		============================================================================
		Base data types
		============================================================================
		*/
		public static void Title(string name, string helpText, string helpInfo)
		{
			EditorTool.BeginSetting(name, false);

			EditorGUILayout.LabelField(name, EditorTool.WIDTH_LABEL);

			EditorTool.EndSetting(name, helpText, helpInfo, false);
		}

		public static void Title(GUIContent content, string helpInfo)
		{
			EditorTool.BeginSetting(content.text, false);

			EditorGUILayout.PrefixLabel(content);

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, false);
		}

		public static void ExpandedTextField(string name, ref string value, string helpText, string helpInfo)
		{
			EditorTool.BeginSetting(name, true);
			value = EditorGUILayout.TextField(new GUIContent(name, helpText), value, EditorTool.W_EXPAND);
			EditorTool.EndSetting(name, helpText, helpInfo, true);
		}

		public static void Field<T>(string name, ref T value, string helpText, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			EditorTool.Field(new GUIContent(name, helpText), ref value, helpInfo, attributes, baseEditor);
		}

		public static void Field<T>(GUIContent content, ref T value, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}
			EditorTool.BeginSetting(content.text, horizontal);

			// base types
			if(typeof(int).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.IntField(title, (int)(object)value, layout);
			}
			else if(typeof(float).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.FloatField(title, (float)(object)value, layout);
			}
			else if(typeof(bool).Equals(typeof(T)))
			{
				if(attributes != null && attributes.info.isToggleLeft)
				{
					value = (T)(object)EditorGUILayout.ToggleLeft(title, (bool)(object)value, layout);
				}
				else
				{
					value = (T)(object)EditorGUILayout.Toggle(title, (bool)(object)value, layout);
				}
			}
			else if(typeof(string).Equals(typeof(T)))
			{
				if(attributes != null && attributes.info.isStandardTextArea)
				{
					EditorGUILayout.BeginVertical();
					EditorTool.BoldLabel(title);
					value = (T)(object)EditorGUILayout.TextArea((string)(object)value, EditorContent.Instance.TextAreaStyle, layout);
					EditorGUILayout.EndVertical();
				}
				else
				{
					value = (T)(object)EditorGUILayout.TextField(title, (string)(object)value, layout);
				}
			}
			// unity types
			else if(typeof(Vector2).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Vector2Field(title, (Vector2)(object)value, layout);
			}
			else if(typeof(Vector3).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Vector3Field(title, (Vector3)(object)value, layout);
			}
			else if(typeof(Vector4).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Vector4Field(title, (Vector4)(object)value, layout);
			}
			else if(typeof(Rect).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.RectField(title, (Rect)(object)value, layout);
			}
			else if(typeof(Color).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ColorField(new GUIContent(title), (Color)(object)value, true, true, true, layout);
			}
			else if(typeof(Texture).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (Texture)(object)value, typeof(T), false, layout);
			}
			else if(typeof(AudioClip).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (AudioClip)(object)value, typeof(T), false, layout);
			}
			else if(typeof(AudioMixer).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (AudioMixer)(object)value, typeof(T), false, layout);
			}
			else if(typeof(AudioMixerGroup).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (AudioMixerGroup)(object)value, typeof(T), false, layout);
			}
			else if(typeof(GameObject).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (GameObject)(object)value, typeof(T),
					attributes != null ? attributes.info.allowSceneObjects : false, layout);
			}
			else if(typeof(GUISkin).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (GUISkin)(object)value, typeof(T), false, layout);
			}
			else if(typeof(Material).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (Material)(object)value, typeof(T), false, layout);
			}
			else if(typeof(PhysicMaterial).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (PhysicMaterial)(object)value, typeof(T), false, layout);
			}
			else if(typeof(PhysicsMaterial2D).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (PhysicsMaterial2D)(object)value, typeof(T), false, layout);
			}
			else if(typeof(Sprite).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (Sprite)(object)value, typeof(T), false, layout);
			}
			else if(typeof(Font).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (Font)(object)value, typeof(T), false, layout);
			}
			// asset types
			else if(typeof(MakinomSchematicAsset).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (MakinomSchematicAsset)(object)value, typeof(T), false, layout);
			}
			else if(typeof(UnityEngine.Object).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField(title, (UnityEngine.Object)(object)value, typeof(T),
					attributes != null ? attributes.info.allowSceneObjects : false, layout);
			}

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, horizontal);
		}

		public static void NoTitleField<T>(string name, ref T value, string helpText, string helpInfo,
			AttributeHelper attributes, GUILayoutOption layout)
		{
			bool horizontal = attributes == null ||
				attributes.width == null ||
				!attributes.width.noHorizontal;
			EditorTool.BeginSetting(name, horizontal);

			// base types
			if(typeof(int).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.IntField((int)(object)value, layout);
			}
			else if(typeof(float).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.FloatField((float)(object)value, layout);
			}
			else if(typeof(bool).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Toggle((bool)(object)value, layout);
			}
			else if(typeof(string).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.TextField((string)(object)value, layout);
			}
			// unity types
			else if(typeof(Vector2).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Vector2Field("", (Vector2)(object)value, layout);
			}
			else if(typeof(Vector3).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Vector3Field("", (Vector3)(object)value, layout);
			}
			else if(typeof(Vector4).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.Vector4Field("", (Vector4)(object)value, layout);
			}
			else if(typeof(Rect).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.RectField((Rect)(object)value, layout);
			}
			else if(typeof(Color).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ColorField(new GUIContent(), (Color)(object)value, true, true, true, layout);
			}
			else if(typeof(Texture).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((Texture)(object)value, typeof(T), false, layout);
			}
			else if(typeof(AudioClip).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((AudioClip)(object)value, typeof(T), false, layout);
			}
			else if(typeof(AudioMixer).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((AudioMixer)(object)value, typeof(T), false, layout);
			}
			else if(typeof(AudioMixerGroup).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((AudioMixerGroup)(object)value, typeof(T), false, layout);
			}
			else if(typeof(GameObject).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((GameObject)(object)value, typeof(T),
					attributes != null ? attributes.info.allowSceneObjects : false, layout);
			}
			else if(typeof(GUISkin).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((GUISkin)(object)value, typeof(T), false, layout);
			}
			else if(typeof(Material).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((Material)(object)value, typeof(T), false, layout);
			}
			else if(typeof(PhysicMaterial).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((PhysicMaterial)(object)value, typeof(T), false, layout);
			}
			else if(typeof(PhysicsMaterial2D).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((PhysicsMaterial2D)(object)value, typeof(T), false, layout);
			}
			else if(typeof(Sprite).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((Sprite)(object)value, typeof(T), false, layout);
			}
			else if(typeof(Font).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((Font)(object)value, typeof(T), false, layout);
			}
			// asset types
			else if(typeof(MakinomSchematicAsset).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((MakinomSchematicAsset)(object)value, typeof(T), false, layout);
			}
			else if(typeof(UnityEngine.Object).Equals(typeof(T)))
			{
				value = (T)(object)EditorGUILayout.ObjectField((UnityEngine.Object)(object)value, typeof(T),
					attributes != null ? attributes.info.allowSceneObjects : false, layout);
			}

			EditorTool.EndSetting(name, helpText, helpInfo, horizontal);
		}

		public static void ToggleButton(string name, ref bool value, string helpText, string helpInfo)
		{
			EditorTool.ToggleButton(new GUIContent(name, helpText), ref value, helpInfo);
		}

		public static void ToggleButton(GUIContent content, ref bool value, string helpInfo)
		{
			EditorTool.BeginSetting(content.text, true);
			value = GUILayout.Toggle(value, content, "button");
			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, true);
		}

		public static void ToggleButtonNoName(GUIContent content, ref bool value, string helpText, string helpInfo)
		{
			EditorTool.BeginSetting(content.text, true);
			value = GUILayout.Toggle(value, new GUIContent("", content.image, content.tooltip), "button");
			EditorTool.EndSetting(content.text, helpText, helpInfo, true);
		}

		public static void AssetField(GUIContent content, ref UnityEngine.Object value, System.Type type, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}
			EditorTool.BeginSetting(content.text, horizontal);

			value = EditorGUILayout.ObjectField(title, value, type,
				attributes != null ? attributes.info.allowSceneObjects : false, layout);

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, horizontal);
		}

		public static void Slider(GUIContent content, ref float value, float minValue, float maxValue,
			string helpInfo, AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", content.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", content.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}
			EditorTool.BeginSetting(content.text, horizontal);

			value = EditorGUILayout.Slider(title, value, minValue, maxValue, layout);

			EditorTool.EndSetting(content.text, title.tooltip, helpInfo, horizontal);
		}

		public static void IntSlider(GUIContent content, ref int value, int minValue, int maxValue,
			string helpInfo, AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}
			EditorTool.BeginSetting(content.text, horizontal);

			value = EditorGUILayout.IntSlider(title, value, minValue, maxValue, layout);

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, horizontal);
		}


		/*
		============================================================================
		Object fields
		============================================================================
		*/
		public static void ObjectField<T>(string name, ref T obj, System.Type type,
			string helpText, string helpInfo, GUILayoutOption layout) where T : UnityEngine.Object
		{
			EditorTool.BeginSetting(name, true);
			obj = EditorGUILayout.ObjectField(name, obj, type, false, layout) as T;
			EditorTool.EndSetting(name, helpText, helpInfo, true);
		}

		public static void CurveField(GUIContent content, ref AnimationCurve curve, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}

			EditorTool.BeginSetting(content.text, horizontal);
			curve = EditorGUILayout.CurveField(title, curve, layout);

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, horizontal);
		}

		public static void CurveField(string name, ref AnimationCurve curve, string helpText, string helpInfo,
			Rect ranges, AttributeHelper attributes, BaseEditor baseEditor)
		{
			string title = name;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = "";
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = "";
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}

			EditorTool.BeginSetting(name, horizontal);
			curve = EditorGUILayout.CurveField(title, curve, Color.green, ranges, layout);

			EditorTool.EndSetting(name, helpText, helpInfo, horizontal);
		}



		/*
		============================================================================
		Search fields
		============================================================================
		*/
		public static void SearchField(string name, ref string search, string helpText, string helpInfo, SearchField searchField)
		{
			search = searchField.OnGUI(search, EditorTool.W_EXPAND);
			EditorTool.CheckHelpText(name, helpText, helpInfo);
		}


		/*
		============================================================================
		Popups
		============================================================================
		*/
		public static void LayerMaskField(GUIContent content, ref LayerMask mask, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}
			else if(Maki.EditorSettings.popupLonger)
			{
				layout = EditorTool.WIDTH_LONG;
			}

			string[] layer = new string[31]; // ignore last layer for now
			for(int i = 0; i < layer.Length; i++)
			{
				if(Maki.EditorSettings.showAllLayers)
				{
					layer[i] = i + ": " + LayerMask.LayerToName(i);
				}
				else
				{
					layer[i] = LayerMask.LayerToName(i);
				}
			}

			EditorTool.BeginSetting(content.text, horizontal);
			mask.value = EditorGUILayout.MaskField(title, mask.value, layer, layout);
			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, horizontal);
		}

		public static void LayerMaskField(string title, ref LayerMask mask, GUILayoutOption layout)
		{
			string[] layer = new string[31]; // ignore last layer for now
			for(int i = 0; i < layer.Length; i++)
			{
				if(Maki.EditorSettings.showAllLayers)
				{
					layer[i] = i + ": " + LayerMask.LayerToName(i);
				}
				else
				{
					layer[i] = LayerMask.LayerToName(i);
				}
			}

			mask.value = EditorGUILayout.MaskField(title, mask.value, layer, layout);
		}

		public static void LayerField(GUIContent content, ref int index, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent title = content;
			bool horizontal = true;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
				horizontal = !attributes.width.noHorizontal;
			}
			else if(Maki.EditorSettings.popupLonger)
			{
				layout = EditorTool.WIDTH_LONG;
			}

			EditorTool.BeginSetting(content.text, horizontal);
			index = EditorGUILayout.LayerField(title, index, layout);
			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, horizontal);
		}

		public static void Popup(GUIContent content, ref int index, string[] options, string favoriteInfo, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			baseEditor.PopupSelectionField(content, ref index, options, null, favoriteInfo, helpInfo, attributes);
		}

		public static void NoTitlePopup(string name, ref int index, string[] options, string helpText, string helpInfo, BaseEditor baseEditor)
		{
			baseEditor.PopupSelectionFieldSimple(name, ref index, options, null, helpText, helpInfo, true, false);
		}

		public static bool EnumPopup<T>(GUIContent content, ref T value, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			EditorSortedEnum sortedEnum = EditorAttributes.GetSortedEnum(value);
			int index = sortedEnum.GetIndex(value);
			int tmpIndex = index;
			baseEditor.PopupSelectionField(content, ref index, sortedEnum.names, null, value.GetType().FullName, helpInfo, attributes);
			value = (T)sortedEnum.GetValue(index);
			return index != tmpIndex;
		}

		// returns true if changed
		public static bool SettingPopup(GUIContent content, ref string value, System.Type baseType, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			GUIContent tmpContent = new GUIContent(content);
			EditorSortedSettingInfo infos = EditorAttributes.GetSettingInfos(baseType);
			tmpContent.tooltip += infos.infoHelpText;
			int index = infos.GetIndex(value);
			int tmpIndex = index;
			baseEditor.PopupSelectionField(tmpContent, ref index, infos.names, infos.descriptions, baseType.FullName, helpInfo, attributes);
			if(index != tmpIndex)
			{
				value = infos.GetValue(index);
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Special fields
		============================================================================
		*/
		public static void AxisBoolField(string name, ref AxisBool axis, string helpText, string helpInfo)
		{
			EditorTool.AxisBoolField(new GUIContent(name, helpText), ref axis, helpInfo);
		}

		public static void AxisBoolField(GUIContent content, ref AxisBool axis, string helpInfo)
		{
			EditorGUILayout.BeginHorizontal();
			EditorTool.Title(content, helpInfo);
			axis.x = EditorGUILayout.ToggleLeft("X", axis.x, EditorTool.WIDTH_30);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			axis.y = EditorGUILayout.ToggleLeft("Y", axis.y, EditorTool.WIDTH_30);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			axis.z = EditorGUILayout.ToggleLeft("Z", axis.z, EditorTool.WIDTH_30);
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			EditorGUILayout.EndHorizontal();
		}


		/*
		============================================================================
		Text area/editor
		============================================================================
		*/
		public static void TextArea(GUIContent content, ref TextContent text,
			ref EditorTextAreaControl control, int optionType,
			string helpInfo, BaseEditor baseEditor)
		{
			/*if(baseEditor.isInspector)
			{
				EditorGUILayout.BeginVertical();
				EditorTool.BoldLabel(content);
				GUI.SetNextControlName(content.text);
				text.text = EditorGUILayout.TextArea(text.text);
				EditorGUILayout.EndVertical();
				EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
			}
			else */
			if(Maki.EditorSettings.useCustomTextArea)
			{
				control.Edit(content, ref text, helpInfo, baseEditor, optionType);
			}
			else
			{
				EditorTool.UnityTextArea(content, ref text.text, ref control.scroll, helpInfo);
			}
		}

		public static void UnityTextArea(GUIContent content, ref string text, ref Vector2 scroll, string helpInfo)
		{
			EditorGUILayout.BeginVertical();
			EditorTool.BoldLabel(content);
			scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(Maki.EditorSettings.textAreaHeight));
			GUI.SetNextControlName(content.text);
			GUIStyle textStyle = new GUIStyle(EditorContent.Instance.TextAreaStyle);
			if(Maki.EditorSettings.setTextAreaColor)
			{
				textStyle.normal.textColor = Maki.EditorSettings.textAreaColor;
				textStyle.active.textColor = Maki.EditorSettings.textAreaColor;
				textStyle.focused.textColor = Maki.EditorSettings.textAreaColor;
				textStyle.hover.textColor = Maki.EditorSettings.textAreaColor;
			}
			text = EditorGUILayout.TextArea(text, textStyle);
			EditorGUILayout.EndScrollView();
			EditorGUILayout.EndVertical();
			EditorTool.CheckHelpText(content.text, content.tooltip, helpInfo);
		}


		/*
		============================================================================
		Extension functions
		============================================================================
		*/
		public static IEnumerable<SerializedProperty> GetVisibleChildren(this SerializedProperty property)
		{
			SerializedProperty currentProperty = property.Copy();
			SerializedProperty nextProperty = property.Copy();
			nextProperty.NextVisible(false);

			if(currentProperty.NextVisible(true))
			{
				do
				{
					if(SerializedProperty.EqualContents(currentProperty, nextProperty))
					{
						break;
					}
					yield return currentProperty;
				}
				while(currentProperty.NextVisible(false));
			}
		}
	}
}
