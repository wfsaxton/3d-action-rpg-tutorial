﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class DialogueImportSettings : BaseData
	{
		[EditorHelp("Default UI Box", "Define the UI box that will be used after processing the dialogue.\n" +
			"You can afterwards use different dialogues for the recognized speakers.")]
		[EditorFoldout("Import Settings", "Base settings for the dialogue import.")]
		public AssetSelection<UIBoxAsset> uiBox = new AssetSelection<UIBoxAsset>();


		// format
		[EditorHelp("Format", "Select the format of the dialogue that will be imported:")]
		[EditorSeparator]
		[EditorEndFoldout]
		[EditorInfo(settingBaseType = typeof(BaseDialogueImportFormat), settingAutoSetup = "settings")]
		public string type = typeof(SeparatorDialogueImportFormat).ToString();

		public BaseDialogueImportFormat settings = new SeparatorDialogueImportFormat();

		public DialogueImportSettings()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseDialogueImportFormat));
					if(tmpSettings is BaseDialogueImportFormat)
					{
						this.settings = (BaseDialogueImportFormat)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new SeparatorDialogueImportFormat();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}
	}
}
