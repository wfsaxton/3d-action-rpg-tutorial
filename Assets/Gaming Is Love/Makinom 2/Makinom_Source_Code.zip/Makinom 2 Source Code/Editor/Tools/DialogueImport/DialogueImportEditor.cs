﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.Makinom.Editor
{
	public class DialogueImportEditor : MakinomFullViewEditor
	{
		protected DialogueImportSettings settings = new DialogueImportSettings();

		protected MakinomSchematicAsset schematicAsset;

		protected NodeEditor nodeEditor;

		protected DialogueImportContent importContent;


		// editor
		protected int displayMode = 0;

		protected Vector2 scrollSettings = Vector2.zero;

		protected Vector2 scrollSpeakers = Vector2.zero;

		protected Vector2 scrollDialogues = Vector2.zero;

		protected GUIContent[] tabsSettings = new GUIContent[]
		{
			new GUIContent("Import Settings", "Define the settings for importing dialogues.")
		};

		protected GUIContent[] tabsFull = new GUIContent[]
		{
			new GUIContent("Import Settings", "Define the settings for importing dialogues."),
			new GUIContent("Speakers", "View and adjust the found speakers."),
			new GUIContent("Dialogues", "View and adjust the found dialogues.")
		};


		// special popup lists
		public string[] popupList0 = new string[0];

		public string[] popupList1 = new string[0];

		public string[] popupList2 = new string[0];

		public DialogueImportEditor(MakinomEditorWindow parent, MakinomSchematicAsset schematicAsset, NodeEditor nodeEditor) : base(parent)
		{
			this.schematicAsset = schematicAsset;
			this.nodeEditor = nodeEditor;

			// tab popup list 0
			if(this.schematicAsset != null)
			{
				this.popupList0 = new string[this.schematicAsset.Settings.actor.Length];
				for(int i = 0; i < this.popupList0.Length; i++)
				{
					this.popupList0[i] = this.GetActorName(i, this.schematicAsset.Settings.actor[i]);
				}
			}

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			if(editorAsset != null &&
				editorAsset.DialogueImportSettings != null)
			{
				this.settings.SetData(editorAsset.DialogueImportSettings.ToDataObject());
			}
			this.tabsSettings[0].image = EditorContent.Instance.EditIcon;
			this.tabsFull[0].image = EditorContent.Instance.EditIcon;
		}

		protected string GetActorName(int i, SchematicActor actor)
		{
			if(actor.setName)
			{
				return "Actor " + i + ": " + actor.actorName.Current;
			}
			return "Actor " + i + ": " + actor.settings.EditorName;
		}

		public virtual bool CanImport
		{
			get
			{
				return this.importContent != null &&
					this.importContent.dialogues.Length > 0;
			}
		}

		public override string[] GetPopupList(int id)
		{
			if(id == 0)
			{
				return this.popupList0;
			}
			else if(id == 1)
			{
				return this.popupList1;
			}
			else if(id == 2)
			{
				return this.popupList2;
			}
			return new string[0];
		}

		public override bool ShowGUI()
		{
			base.ShowGUI();

			bool close = false;

			// top buttons
			EditorGUILayout.BeginVertical(EditorContent.Instance.SearchBoxStyle, GUILayout.Height(24));
			// processing
			EditorGUILayout.BeginHorizontal();

			if(this.importContent == null)
			{
				EditorTool.SelectionGridCenter("DialogueImportTabs", ref this.displayMode, this.tabsSettings, 3, 200);
			}
			else
			{
				EditorTool.SelectionGridCenter("DialogueImportTabs", ref this.displayMode, this.tabsFull, 3, 200);
			}

			GUILayout.FlexibleSpace();

			// close/open foldouts
			if(EditorTool.ShowButton2(new GUIContent(EditorContent.Instance.CloseFoldoutsIcon, "Close all foldouts."),
				"Close all foldouts.", "", EditorStyles.miniButtonLeft, EditorTool.WIDTH_25, EditorTool.HEIGHT_18))
			{
				this.ExpandFoldouts(false);
			}
			if(EditorTool.ShowButton2(new GUIContent(EditorContent.Instance.OpenFoldoutsIcon, "Open all foldouts."),
				"Open all foldouts.", "", EditorStyles.miniButtonRight, EditorTool.WIDTH_25, EditorTool.HEIGHT_18))
			{
				this.ExpandFoldouts(true);
			}
			EditorGUILayout.EndHorizontal();

			EditorGUILayout.EndVertical();


			// content
			EditorGUILayout.BeginVertical(GUILayout.ExpandHeight(true));

			// settings
			if(this.importContent == null ||
				this.displayMode == 0)
			{
				this.scrollSettings = EditorGUILayout.BeginScrollView(this.scrollSettings);
				EditorGUILayout.BeginVertical();

				EditorAutomation.Automate(this.settings, this);

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			else if(this.displayMode == 1)
			{
				this.scrollSpeakers = EditorGUILayout.BeginScrollView(this.scrollSpeakers);
				EditorGUILayout.BeginVertical();

				EditorAutomation.Automate("speakers", this.importContent, this);

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			else if(this.displayMode == 2)
			{
				this.scrollDialogues = EditorGUILayout.BeginScrollView(this.scrollDialogues);
				EditorGUILayout.BeginVertical();

				EditorAutomation.Automate("dialogues", this.importContent, this);

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}


			// ok/cancel buttons
			EditorGUILayout.BeginHorizontal();
			// cancel
			if(EditorTool.ShowButton(EditorContent.Instance.CancelContent,
				"Cancel the dialogue import.", "", EditorTool.W_EXPAND))
			{
				close = true;
			}
			// import
			EditorGUI.BeginDisabledGroup(!this.CanImport);
			if(EditorTool.ShowButton(new GUIContent("Import Dialogue Nodes", EditorContent.Instance.SaveIcon,
				"Import the processed dialogue as 'Show Dialogue' nodes (one per dialogue) into the open schematic."),
				"Import the processed dialogue as 'Show Dialogue' nodes (one per dialogue) into the open schematic.", "", EditorTool.W_EXPAND))
			{
				close = true;
				if(this.nodeEditor != null)
				{
					this.nodeEditor.AddNodesFromExternal(this.importContent.CreateDialogues());
				}
				MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
				if(editorAsset != null)
				{
					editorAsset.DialogueImportSettings = this.settings.GetData().GetDataFile("dialogueImport", false, DataFile.SaveFormatType.ByteArray);
					MakinomAssetHelper.SaveEditorAsset(editorAsset);
				}
			}
			EditorGUI.EndDisabledGroup();
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.EndVertical();

			return close;
		}

		public override void AutomationCallback(string info)
		{
			if(info == "button:process")
			{
				EditorGUILayout.BeginHorizontal();

				// preprocess
				EditorGUI.BeginDisabledGroup(!this.settings.settings.CanPreprocessText);
				if(EditorTool.Button(new GUIContent("Preprocess Text", EditorContent.Instance.EditIcon,
					"Preprocess the text with the defined text options and update the processing text setting."),
					"Preprocess the text with the defined text options and update the processing text setting.", ""))
				{
					GUI.FocusControl("");
					this.settings.settings.PreprocessText();
					this.Repaint();
				}
				EditorGUI.EndDisabledGroup();

				// process
				EditorGUI.BeginDisabledGroup(!this.settings.settings.CanProcess);
				if(EditorTool.Button(new GUIContent("Process Dialogues", EditorContent.Instance.PlusIcon,
					"Process the defined dialogue.\n" +
					"This will create an overview of the found speakers and individual dialogues that you can further refine before importing the dialogues into the schematic."),
					"Process the defined dialogue.\n" +
					"This will create an overview of the found speakers and individual dialogues that you can further refine before importing the dialogues into the schematic.", ""))
				{
					GUI.FocusControl("");
					this.importContent = this.settings.settings.ProcessText();

					if(this.importContent != null)
					{
						this.popupList1 = new string[this.importContent.speakers.Length];
						for(int i = 0; i < this.importContent.speakers.Length; i++)
						{
							this.popupList1[i] = "Speaker " + i + ": " + this.importContent.speakers[i].GetName();
							this.importContent.speakers[i].uiBox.SetAsset(this.settings.uiBox.StoredAsset);
						}
						this.popupList2 = new string[this.importContent.dialogues.Length + 1];
						this.popupList2[0] = "None";
						for(int i = 0; i < this.importContent.dialogues.Length; i++)
						{
							this.popupList2[i + 1] = "Dialogue " + i + ": " + this.importContent.dialogues[i].GetName();
							this.importContent.dialogues[i].uiBox.SetAsset(this.settings.uiBox.StoredAsset);
						}
					}
					this.displayMode = 1;
				}
				EditorGUI.EndDisabledGroup();

				// clear
				EditorGUI.BeginDisabledGroup(this.importContent == null);
				if(EditorTool.Button(new GUIContent("Remove Processed Content", EditorContent.Instance.SmallRemoveIcon,
					"Removes the processed content (speakers and dialogues)."),
					"Removes the processed content (speakers and dialogues).", ""))
				{
					GUI.FocusControl("");
					this.importContent = null;
					this.popupList1 = new string[0];
					this.popupList2 = new string[0];
					this.displayMode = 0;
				}
				EditorGUI.EndDisabledGroup();

				GUILayout.FlexibleSpace();

				EditorGUILayout.EndHorizontal();
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
