
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(AreaComponent))]
public class AreaComponentInspector : BaseInspector
{
	protected AreaAsset lastArea;

	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as AreaComponent);
	}

	private void ComponentSetup(AreaComponent target)
	{
		Undo.RecordObject(target, "Change to 'Area' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Area Settings", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);
			EditorGUILayout.Separator();

			if(target.settings.autoName &&
				this.lastArea != target.settings.area.StoredAsset)
			{
				target.SetAutoName();
			}
			this.lastArea = target.settings.area.StoredAsset;
		}
		this.baseEditor.EndFoldout();

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}