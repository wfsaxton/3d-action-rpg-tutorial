﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(FirstPersonCamera))]
public class FirstPersonCameraInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as FirstPersonCamera);
	}

	protected virtual void ComponentSetup(FirstPersonCamera target)
	{
		Undo.RecordObject(target, "Change to 'First Person Camera' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}