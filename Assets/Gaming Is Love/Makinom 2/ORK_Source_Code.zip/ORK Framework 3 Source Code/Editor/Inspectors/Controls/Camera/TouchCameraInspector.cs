﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(MouseCamera))]
public class TouchCameraInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as MouseCamera);
	}

	protected virtual void ComponentSetup(MouseCamera target)
	{
		Undo.RecordObject(target, "Change to 'Touch Camera' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}