﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(CombatantTriggerComponent))]
public class CombatantTriggerComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as CombatantTriggerComponent);
	}

	protected virtual void ComponentSetup(CombatantTriggerComponent target)
	{
		Undo.RecordObject(target, "Change to 'Combatant Trigger' on " + target.name);
		this.BaseInit(false);


		// settings
		EditorAutomation.Automate(target.settings, this.baseEditor);
		EditorGUILayout.Separator();


		if(Application.isPlaying)
		{
			if(this.baseEditor.BeginFoldout("Combatants", "View the combatants that are currently within this combatant trigger.", "", true))
			{
				EditorGUILayout.LabelField("Owner",
					target.Owner != null ? target.Owner.GetName() : "-");
				EditorGUILayout.Separator();

				if(target.InTrigger.Count > 0)
				{
					EditorTool.BoldLabel("In Trigger");
					for(int i = 0; i < target.InTrigger.Count; i++)
					{
						if(target.InTrigger[i] != null)
						{
							EditorGUILayout.LabelField(target.InTrigger[i].GetName(),
								target.GetTime(target.InTrigger[i]).ToString("0.00"));
						}
					}
					EditorGUILayout.Separator();
				}
			}
			this.baseEditor.EndFoldout();
		}

		this.EndSetup();
	}
}