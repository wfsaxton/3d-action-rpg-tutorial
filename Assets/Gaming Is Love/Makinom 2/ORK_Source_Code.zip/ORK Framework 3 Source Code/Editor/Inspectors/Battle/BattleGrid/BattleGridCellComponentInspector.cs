﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

[CustomEditor(typeof(BattleGridCellComponent))]
public class BattleGridCellComponentInspector : BattleGridBaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ShowSettings(target as BattleGridCellComponent);
	}

	private void ShowSettings(BattleGridCellComponent target)
	{
		Undo.RecordObject(target, "Change to 'Battle Grid Cell' on " + target.name);
		this.BaseInit(true);

		EditorGUILayout.BeginHorizontal();
		if(EditorTool.Button(new GUIContent("", EditorContent.Instance.NavigateBackIcon)))
		{
			BattleGridCellComponent tmpCell = BattleGridHelper.GetPreviousCell(target);
			if(tmpCell != null)
			{
				Selection.objects = new Object[] { tmpCell.gameObject };
			}
		}
		if(EditorTool.Button(new GUIContent("Select Grid", EditorContent.Instance.EditIcon)))
		{
			Selection.objects = new Object[] { target.parentGrid.gameObject };
		}
		if(EditorTool.Button(new GUIContent("", EditorContent.Instance.NavigateForwardIcon)))
		{
			BattleGridCellComponent tmpCell = BattleGridHelper.GetNextCell(target);
			if(tmpCell != null)
			{
				Selection.objects = new Object[] { tmpCell.gameObject };
			}
		}
		EditorGUILayout.EndHorizontal();
		EditorGUILayout.LabelField("Row", target.row.ToString());
		EditorGUILayout.LabelField("Column", target.column.ToString());
		EditorGUILayout.LabelField("Occupant", target.Combatant != null ? target.Combatant.GetName() : "Empty");
		if(target.MarkedForCombatant != null)
		{
			EditorGUILayout.LabelField("Marked For", target.MarkedForCombatant.GetName());
		}
		if(target.MarkedForAI != null)
		{
			EditorGUILayout.LabelField("Marked For AI", target.MarkedForAI.GetName());
		}
		if(target.HasGuests)
		{
			List<Combatant> list = target.GetGuests();
			for(int i = 0; i < list.Count; i++)
			{
				EditorGUILayout.LabelField("Guest " + i, list[i].GetName());
			}
		}


		// grid settings
		this.ShowGridSettings(target);


		BattleGridCellTypeAsset cellType = target.settings.cellType.StoredAsset;
		EditorAutomation.Automate(target.settings, this.baseEditor);
		if(!target.settings.cellType.Is(cellType))
		{
			target.ClearSettings();
			if(target.PrefabInstance != null)
			{
				GameObject.DestroyImmediate(target.PrefabInstance);
			}
		}

		this.EndSetup();
	}
}
