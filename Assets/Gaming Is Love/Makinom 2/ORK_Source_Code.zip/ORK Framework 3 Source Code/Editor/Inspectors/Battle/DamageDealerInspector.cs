
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(DamageDealer))]
public class DamageDealerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as DamageDealer);
	}

	protected virtual void ComponentSetup(DamageDealer target)
	{
		Undo.RecordObject(target, "Change to 'Damage Dealer' on " + target.name);
		this.BaseInit(false);

		if(EditorApplication.isPlaying)
		{
			EditorGUILayout.LabelField("Action", target.Action != null ? target.Action.GetName() : "-");
			EditorGUILayout.LabelField("Is Active", target.IsDamageActive.ToString());
		}

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}
