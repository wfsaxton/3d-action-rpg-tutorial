﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(CombatantDespawner))]
public class CombatantDespawnerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as CombatantDespawner);
	}

	protected virtual void ComponentSetup(CombatantDespawner target)
	{
		Undo.RecordObject(target, "Change to 'Combatant Despawner' on " + target.name);
		this.BaseInit(true);

		if(target.settings.checkDistance &&
			target.settings.afterTime)
		{
			if(target.settings.resetTime)
			{
				if(target.settings.respawn)
				{
					if(target.settings.useDestroyRange)
					{
						EditorGUILayout.HelpBox("Combatants are despawned after being out of range of the player for the defined amount of time.\n" +
							"The combatants will be respawned when their last position is back within range of the player. " +
							"The combatant's game object will only be disabled instead of destroyed.\n" +
							"If the disabled combatant comes out of the destroy range, the combatant will be destroyed permanently (no respawn).\n" +
							"The time is reset each time a combatant gets out of range again.\n" +
							"The time is counted per individual combatant.",
							MessageType.Info);
					}
					else
					{
						EditorGUILayout.HelpBox("Combatants are despawned after being out of range of the player for the defined amount of time.\n" +
							"The combatants will be respawned when their last position is back within range of the player. " +
							"The combatant's game object will only be disabled instead of destroyed.\n" +
							"The time is reset each time a combatant gets out of range again.\n" +
							"The time is counted per individual combatant.",
							MessageType.Info);
					}
				}
				else
				{
					EditorGUILayout.HelpBox("Combatants are despawned after being out of range of the player for the defined amount of time.\n" +
						"The time is reset each time a combatant gets out of range again.\n" +
						"The time is counted per individual combatant.",
						MessageType.Info);
				}
			}
			else if(target.settings.respawn)
			{
				EditorGUILayout.HelpBox("Combatants are despawned after being out of range of the player for the defined amount of time.\n" +
					"The combatants will be respawned when their last position is back within range of the player.\n" +
					"The time is counted per individual combatant.",
					MessageType.Info);
			}
			else
			{
				EditorGUILayout.HelpBox("Combatants are despawned after being out of range of the player for the defined amount of time.\n" +
					"The time is counted per individual combatant.",
					MessageType.Info);
			}
		}
		else if(target.settings.checkDistance)
		{
			if(target.settings.respawn)
			{
				EditorGUILayout.HelpBox("Combatants are despawned when getting out of the defined range of the player.\n" +
					"The combatants will be respawned when their last position is back within range of the player.",
					MessageType.Info);
			}
			else
			{
				EditorGUILayout.HelpBox("Combatants are despawned when getting out of the defined range of the player.",
					MessageType.Info);
			}
		}
		else if(target.settings.afterTime)
		{
			EditorGUILayout.HelpBox("Combatants are despawned after the defined time in seconds.\n" +
				"The time is counted per individual combatant.",
				MessageType.Info);
		}
		else
		{
			EditorGUILayout.HelpBox("No despawning is used.",
				MessageType.Info);
		}

		// settings
		EditorAutomation.Automate(target.settings, this.baseEditor);
		EditorGUILayout.Separator();

		this.EndSetup();
	}
}
