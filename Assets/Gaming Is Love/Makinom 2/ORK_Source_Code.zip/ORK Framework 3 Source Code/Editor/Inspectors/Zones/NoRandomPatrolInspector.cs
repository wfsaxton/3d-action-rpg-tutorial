﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(NoRandomPatrol))]
public class NoRandomPatrolInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as NoRandomPatrol);
	}

	protected virtual void ComponentSetup(NoRandomPatrol target)
	{
		Undo.RecordObject(target, "Change to 'No Random Patrol' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}