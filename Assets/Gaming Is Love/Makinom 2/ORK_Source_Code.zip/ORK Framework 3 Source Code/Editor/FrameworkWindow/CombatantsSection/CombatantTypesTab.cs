﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CombatantTypesTab : ORKGenericAssetListTab<CombatantTypeAsset, CombatantType>
	{
		public CombatantTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.CombatantTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.CombatantTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Combatant Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Combatant types are used to separate combatants.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/combatants/"; }
		}
	}
}
