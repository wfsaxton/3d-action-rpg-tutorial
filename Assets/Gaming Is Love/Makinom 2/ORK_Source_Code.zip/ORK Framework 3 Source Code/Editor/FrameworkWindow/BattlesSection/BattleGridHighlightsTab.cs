﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleGridHighlightsTab : ORKBaseEditorTab
	{
		public BattleGridHighlightsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Grid Highlights"; }
		}

		public override string HelpText
		{
			get { return "Set up how grid cells are highlighted in battle grids."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-grid-highlights/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleGridHighlights; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.BattleGridHighlights; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void InstanceCallback(string info, object instance)
		{
			if(info == "check:linerenderer")
			{
				LineGridHighlight line = instance as LineGridHighlight;
				if(line != null &&
					line.prefab.Source.EditorAsset != null &&
					((GameObject)line.prefab.Source.EditorAsset).GetComponentInChildren<LineRenderer>() == null)
				{
					EditorGUILayout.HelpBox("No 'Line Renderer' component found on prefab.", MessageType.Error);
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}
	}
}
