
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusEffectsTab : ORKGenericAssetListTab<StatusEffectAsset, StatusEffectSetting>
	{
		public StatusEffectsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.StatusEffects.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.StatusEffects.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Effects"; }
		}

		public override string HelpText
		{
			get
			{
				return "Status effects are used to give temporary status alterations to combatants and can also be used to mark temporary states.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/status-effects/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<StatusEffectTypeAsset, StatusEffectType>(
							new string[] { "Status Effect Type", "Filter the status effect list by status effect type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.type.Source.EditorAsset);
		}
	}
}

