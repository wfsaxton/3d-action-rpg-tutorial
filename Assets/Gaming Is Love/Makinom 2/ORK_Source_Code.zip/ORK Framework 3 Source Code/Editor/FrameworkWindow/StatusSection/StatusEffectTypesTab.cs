
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusEffectTypesTab : ORKGenericAssetListTab<StatusEffectTypeAsset, StatusEffectType>
	{
		public StatusEffectTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Effect Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Status effect types are used to separate status effects.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/status-effects/"; }
		}
	}
}

