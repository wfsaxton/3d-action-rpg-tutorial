
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class ConsoleTypesTab : ORKGenericAssetListTab<ConsoleTypeAsset, ConsoleType>
	{
		public ConsoleTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ConsoleTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.ConsoleTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Console Settings & Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "An in-game console can be used to display information to the player (via 'Console' HUDs).\n" +
					"Set up default console messages and console types to separate the console messages.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/console-in-game/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding the in-game console and default console texts.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.ConsoleSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.ConsoleSettings;
				}
				return base.DisplayedSettings;
			}
		}
	}
}

