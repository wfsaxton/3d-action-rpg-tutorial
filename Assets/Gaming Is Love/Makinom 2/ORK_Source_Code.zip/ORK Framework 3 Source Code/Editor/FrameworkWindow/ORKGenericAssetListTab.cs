﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public abstract class ORKGenericAssetListTab<T, V> : GenericAssetListTab<T, V> where T : MakinomGenericAsset<V> where V : BaseIndexData, new()
	{
		public ORKGenericAssetListTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Automation callback functions
		============================================================================
		*/
		/*public override void AutomationCallback(string info)
		{
			base.AutomationCallback(info);
		}

		public override void AutomationCallback(int arrayIndex, string info)
		{
			base.AutomationCallback(arrayIndex, info);
		}

		public override bool AutomationCheck(string info)
		{
			return base.AutomationCheck(info);
		}

		public override bool AutomationCheck(int arrayIndex, string info)
		{
			return base.AutomationCheck(arrayIndex, info);
		}

		public override void InstanceCallback(string info, System.Object instance)
		{
			base.InstanceCallback(info, instance);
		}

		public override void AutomationAddCallback(string info)
		{
			base.AutomationAddCallback(info);
		}

		public override void AutomationRemoveCallback(int arrayIndex, string info)
		{
			base.AutomationRemoveCallback(arrayIndex, info);
		}*/
	}
}
