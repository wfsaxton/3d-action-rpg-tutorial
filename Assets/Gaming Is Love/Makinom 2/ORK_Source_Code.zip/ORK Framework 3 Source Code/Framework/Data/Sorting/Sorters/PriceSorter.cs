﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BuyPriceSorter : IComparer<IShortcut>
	{
		private Combatant user;

		private bool quantityPrice = false;

		private bool invert = false;

		public BuyPriceSorter(Combatant user, bool quantityPrice, bool invert)
		{
			this.user = user;
			this.quantityPrice = quantityPrice;
			this.invert = invert;
		}

		public int Compare(IShortcut x, IShortcut y)
		{
			if(this.invert)
			{
				int result = this.quantityPrice ?
					(y.Quantity * y.BuyPrice(user)).CompareTo(x.Quantity * x.BuyPrice(user)) :
					y.BuyPrice(user).CompareTo(x.BuyPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = this.quantityPrice ?
					(x.Quantity * x.BuyPrice(user)).CompareTo(y.Quantity * y.BuyPrice(user)) :
					x.BuyPrice(user).CompareTo(y.BuyPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}

	public class SellPriceSorter : IComparer<IShortcut>
	{
		private Combatant user;

		private bool quantityPrice = false;

		private bool invert = false;

		public SellPriceSorter(Combatant user, bool quantityPrice, bool invert)
		{
			this.user = user;
			this.quantityPrice = quantityPrice;
			this.invert = invert;
		}

		public int Compare(IShortcut x, IShortcut y)
		{
			if(this.invert)
			{
				int result = this.quantityPrice ?
					(y.Quantity * y.SellPrice(user)).CompareTo(x.Quantity * x.SellPrice(user)) :
					y.SellPrice(user).CompareTo(x.SellPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = this.quantityPrice ?
					(x.Quantity * x.SellPrice(user)).CompareTo(y.Quantity * y.SellPrice(user)) :
					x.SellPrice(user).CompareTo(y.SellPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
