﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class GridDistanceSorter : IComparer<BattleGridCellComponent>
	{
		private BattleGridCellComponent origin;

		private BattleGridCellComponent other;

		private bool inverse = false;

		private bool checkNonDiagonal1 = false;

		public GridDistanceSorter(BattleGridCellComponent origin, bool inverse)
		{
			this.origin = origin;
			this.inverse = inverse;

			if(ORK.BattleGridSettings.IsSquare &&
				ORK.BattleGridSettings.squareDiagonalDistanceOne)
			{
				this.checkNonDiagonal1 = true;
			}
		}

		public GridDistanceSorter(BattleGridCellComponent origin, BattleGridCellComponent other, bool inverse)
		{
			this.origin = origin;
			this.other = other;
			this.inverse = inverse;

			if(ORK.BattleGridSettings.IsSquare &&
				ORK.BattleGridSettings.squareDiagonalDistanceOne)
			{
				this.checkNonDiagonal1 = true;
			}
		}

		public int Compare(BattleGridCellComponent x, BattleGridCellComponent y)
		{
			if(this.inverse)
			{
				if(x == null &&
					y == null)
				{
					return 0;
				}
				else if(x != null &&
					y == null)
				{
					return 1;
				}
				else if(x == null &&
					y != null)
				{
					return -1;
				}
				else
				{
					int value = origin.CubeCoord.Distance(y.CubeCoord).CompareTo(
						origin.CubeCoord.Distance(x.CubeCoord));

					if(value == 0)
					{
						if(other != null)
						{
							value = other.CubeCoord.Distance(y.CubeCoord).CompareTo(
								other.CubeCoord.Distance(x.CubeCoord));
						}

						if(value == 0 &&
							this.checkNonDiagonal1)
						{
							value = origin.CubeCoord.Distance(y.CubeCoord, true).CompareTo(
								origin.CubeCoord.Distance(x.CubeCoord, true));

							if(other != null)
							{
								value = other.CubeCoord.Distance(y.CubeCoord, true).CompareTo(
									other.CubeCoord.Distance(x.CubeCoord, true));
							}
						}
					}
					return value;
				}
			}
			else
			{
				if(x == null &&
					y == null)
				{
					return 0;
				}
				else if(x != null &&
					y == null)
				{
					return -1;
				}
				else if(x == null &&
					y != null)
				{
					return 1;
				}
				else
				{
					int value = origin.CubeCoord.Distance(x.CubeCoord).CompareTo(
						origin.CubeCoord.Distance(y.CubeCoord));

					if(value == 0)
					{
						if(other != null)
						{
							value = other.CubeCoord.Distance(x.CubeCoord).CompareTo(
								other.CubeCoord.Distance(y.CubeCoord));
						}

						if(value == 0 &&
							this.checkNonDiagonal1)
						{
							value = origin.CubeCoord.Distance(x.CubeCoord, true).CompareTo(
								origin.CubeCoord.Distance(y.CubeCoord, true));

							if(other != null)
							{
								value = other.CubeCoord.Distance(x.CubeCoord, true).CompareTo(
									other.CubeCoord.Distance(y.CubeCoord, true));
							}
						}
					}
					return value;
				}
			}
		}
	}
}
