
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class TurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		private bool leadersFirst = false;

		private FloatValue<GameObjectSelection> secondaryValue;

		public TurnSorter(bool inverse, FloatValue<GameObjectSelection> secondaryValue)
		{
			this.inverse = inverse;
			this.secondaryValue = secondaryValue;
		}

		public TurnSorter(bool inverse, FloatValue<GameObjectSelection> secondaryValue, bool leadersFirst)
		{
			this.inverse = inverse;
			this.leadersFirst = leadersFirst;
			this.secondaryValue = secondaryValue;
		}

		public int Compare(Combatant x, Combatant y)
		{
			// leaders first
			if(this.leadersFirst)
			{
				if(x.IsLeader &&
					!y.IsLeader)
				{
					return this.inverse ? 1 : -1;
				}
				else if(!x.IsLeader &&
					y.IsLeader)
				{
					return this.inverse ? -1 : 1;
				}
			}

			// regular sort
			if(x.Battle.TurnValue < y.Battle.TurnValue)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValue > y.Battle.TurnValue)
			{
				return this.inverse ? 1 : -1;
			}
			else if(this.secondaryValue != null)
			{
				float xValue = this.secondaryValue.GetValue(x.Call);
				float yValue = this.secondaryValue.GetValue(y.Call);
				if(xValue < yValue)
				{
					return this.inverse ? -1 : 1;
				}
				else if(xValue > yValue)
				{
					return this.inverse ? 1 : -1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
	}

	public class DummyTurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		private bool leadersFirst = false;

		private bool usePreview = false;

		private FloatValue<GameObjectSelection> secondaryValue;

		public DummyTurnSorter(bool inverse, FloatValue<GameObjectSelection> secondaryValue, bool usePreview)
		{
			this.inverse = inverse;
			this.secondaryValue = secondaryValue;
			this.usePreview = usePreview;
		}

		public DummyTurnSorter(bool inverse, FloatValue<GameObjectSelection> secondaryValue, bool leadersFirst, bool usePreview)
		{
			this.inverse = inverse;
			this.leadersFirst = leadersFirst;
			this.secondaryValue = secondaryValue;
			this.usePreview = usePreview;
		}

		public int Compare(Combatant x, Combatant y)
		{
			// leaders first
			if(this.leadersFirst)
			{
				if(x.IsLeader &&
					!y.IsLeader)
				{
					return this.inverse ? 1 : -1;
				}
				else if(!x.IsLeader &&
					y.IsLeader)
				{
					return this.inverse ? -1 : 1;
				}
			}

			// regular sort
			if(x.Battle.TurnValueDummy < y.Battle.TurnValueDummy)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValueDummy > y.Battle.TurnValueDummy)
			{
				return this.inverse ? 1 : -1;
			}
			else if(this.secondaryValue != null)
			{
				float xValue = this.usePreview ? this.secondaryValue.GetValuePreview(x.Call) : this.secondaryValue.GetValue(x.Call);
				float yValue = this.usePreview ? this.secondaryValue.GetValuePreview(y.Call) : this.secondaryValue.GetValue(y.Call);
				if(xValue < yValue)
				{
					return this.inverse ? -1 : 1;
				}
				else if(xValue > yValue)
				{
					return this.inverse ? 1 : -1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
	}

	public class GroupLeaderSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		public GroupLeaderSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.IsLeader &&
				!y.IsLeader)
			{
				return this.inverse ? 1 : -1;
			}
			else if(!x.IsLeader &&
				y.IsLeader)
			{
				return this.inverse ? -1 : 1;
			}
			return 0;
		}
	}
}
