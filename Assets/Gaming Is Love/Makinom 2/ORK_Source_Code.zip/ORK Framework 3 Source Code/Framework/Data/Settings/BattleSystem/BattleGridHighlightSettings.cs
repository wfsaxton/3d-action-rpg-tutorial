﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleGridHighlightSettings : BaseSettings
	{
		// base highlights
		[EditorHelp("Hide Unused Prefabs", "Spawned prefabs that are currently not in use " +
			"(e.g. the replaced cell prefab or the highlight prefab when stopping the highlight) will be hidden instead of disabled.\n" +
			"Hiding will disable the renderer and projector components on the prefab.\n" +
			"If disabled, the prefabs will be disabled.\n" +
			"Using this setting can have performance improvements when using prefabs as highlights.", "")]
		[EditorFoldout("Base Highlight Settings", "Define the base highlights that can be used by other grid highlights.", "")]
		public bool hideUnusedPrefabs = true;

		[EditorFoldout("Area Highlight", "Used for 'Area' highligting, e.g. move range.", "")]
		[EditorEndFoldout]
		public GridHighlight areaHighlight = new GridHighlight();

		[EditorFoldout("Selection Highlight", "Used for 'Selection' highligting, e.g. target cell selection.", "")]
		[EditorEndFoldout]
		public GridHighlight selectionHighlight = new GridHighlight();

		[EditorFoldout("No Selection Highlight", "Used for 'No Selection' highligting, e.g. cells not available for movement.", "")]
		[EditorEndFoldout(2)]
		public GridHighlight noSelectionHighlight = new GridHighlight();


		// combatant cell
		[EditorHelp("Use Combatant Cells", "Highlight the cell a combatant is currently occupying.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will be displayed permanently and overridden by all other highlights (e.g. combatant selection).", "")]
		[EditorFoldout("Combatant Cell", "Optionally highlight the cells currently occupied by combatants.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will be displayed permanently and overridden by all other highlights (e.g. combatant selection).", "")]
		public bool useCombatantCells = false;

		[EditorHelp("UI Hides Cells", "Combatant cell highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorCondition("useCombatantCells", true)]
		public bool uiHidesCombatantCells = false;

		[EditorHelp("Use Turn Ended Cells", "Use different highlights for combatants that ended their turn.\n" +
			"Using turn ended highlights but not using a highlight for player/ally/enemy will fall back to the regular combatant cell highlights.", "")]
		public bool useTurnEndedCombatantCells = false;

		[EditorFoldout("Player Cell", "The player cell highlight is used to display the cells occupied by player group members.", "")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public GridHighlightSetting combatantCellPlayer;

		[EditorFoldout("Ally Cell", "The ally cell highlight is used to display the cells occupied by allies of the player.", "")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public GridHighlightSetting combatantCellAlly;

		[EditorFoldout("Enemy Cell", "The enemy cell highlight is used to display the cells occupied by enemies of the player.", "")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public GridHighlightSetting combatantCellEnemy;

		[EditorFoldout("Turn Ended Player Cell", "The turn ended player cell highlight is used to display the cells occupied by " +
			"player group members that finished their turn.", "")]
		[EditorEndFoldout]
		[EditorCondition("useTurnEndedCombatantCells", true)]
		[EditorAutoInit]
		public GridHighlightSetting combatantCellPlayerTurnEnded;

		[EditorFoldout("Turn Ended Ally Cell", "The turn ended ally cell highlight is used to display the cells occupied by " +
			"allies of the player that finished their turn.", "")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public GridHighlightSetting combatantCellAllyTurnEnded;

		[EditorFoldout("Turn Ended Enemy Cell", "The turn ended enemy cell highlight is used to display the cells occupied by " +
			"enemies of the player that finished their turn.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public GridHighlightSetting combatantCellEnemyTurnEnded;


		// combatant selection
		[EditorHelp("Use Combatant Selections", "Use different grid highlights when a cell with a combatant is selected.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will override other selection highlights (e.g. for move command or examine grid), " +
			"the highlights still have to be enabled to actually show the override highlight.", "")]
		[EditorFoldout("Combatant Selections", "Optionally use different selection highlights when a cell with a combatant is selected.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will override other selection highlights (e.g. for move command or examine grid), " +
			"the highlights still have to be enabled to actually show the override highlight.", "")]
		public bool useCombatantSelections = false;

		[EditorHelp("UI Hides Selections", "Combatant selection highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorCondition("useCombatantSelections", true)]
		public bool uiHidesCombatantSelections = false;

		[EditorFoldout("Player Selection", "The player selection highlight is used to display the currently selected cell " +
			"when a player group member is placed on the cell.", "")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public GridHighlightSetting combatantSelectionPlayer;

		[EditorFoldout("Ally Selection", "The ally selection highlight is used to display the currently selected cell " +
			"when an ally of the player is placed on the cell.", "")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public GridHighlightSetting combatantSelectionAlly;

		[EditorFoldout("Enemy Selection", "The enemy selection highlight is used to display the currently selected cell " +
			"when an enemy of the player is placed on the cell.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GridHighlightSetting combatantSelectionEnemy;


		// placement
		[EditorHelp("UI Hides Placement", "Combatant placement highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Combatant Placement", "Highlight settings for selecting a combatant's placement on the grid.", "")]
		public bool uiHidesPlacement = false;

		[EditorFoldout("Placement", "The placement highlight is used to display cells that are available for placing combatants.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting placementHighlight = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Placement Selection", "The placement selection highlight is used to display " +
			"the currently selected cell that is available for placement.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting placementSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("No Placement Selection", "The no placement selection highlight is used to display " +
			"the currently selected cell that is not available for placement.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting noPlacementSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.NoSelection);


		// move command
		[EditorHelp("UI Hides Move Command", "Move command highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Move Command", "Highlight settings for selecting a combatant's move target for the grid move command.", "")]
		public bool uiHidesMoveCommand = false;

		[EditorHelp("Blocked Highlight Occupied", "Cells occupied by a combatant are highlighted by the " +
			"'Move Range (Blocked)' and 'Move Range (Passable)' highlights.\n" +
			"If disabled, occupied cells aren't highlighted as blocked.", "")]
		public bool moveRangeBlockedHighlightOccupied = true;

		[EditorFoldout("Move Range", "The move range highlight is used to display cells that are available for moving.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting moveRangeHighlight = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Move Range (Blocked)", "The move range highlight is used to display blocked cells within move range.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting moveRangeBlockedHighlight = new GridHighlightSetting();

		[EditorFoldout("Move Range (Passable)", "The move range highlight is used to display blocked cells within move range that are passable.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting moveRangePassableHighlight = new GridHighlightSetting();

		[EditorFoldout("Move Selection", "The move selection highlight is used to display " +
			"the currently selected cell that is available for movement when selecting a move target.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting moveSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("No Move Selection", "The no move selection highlight is used to display " +
			"the currently selected cell that is not available for movement when selecting a move target.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting noMoveSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.NoSelection);

		[EditorFoldout("Move Path", "The move path highlight is used to display " +
			"the path to the currently selected cell when selecting a move target.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting movePathHighlight = new GridHighlightSetting();


		// available target
		[EditorHelp("UI Hides Available Target", "Available target highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Available Target", "Highlight settings for available targets during target selection for an action.", "")]
		public bool uiHidesAvailableTarget = false;

		[EditorHelp("In Action Selection", "The available targets of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the available target cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool availableTargetActionSelection = false;

		[EditorHelp("In Target Selection", "The available targets of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the available target cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool availableTargetTargetSelection = false;

		[EditorHelp("For Tooltips", "The available targets of an ability/item will be highlighted for tooltips (i.e. cursor over something with a tooltip).\n" +
			"I.e. the available target cells will be highlighted while having the cursor over something with a tooltip (e.g. from a 'Shortcut' slot in a HUD).", "")]
		public bool availableTargetTooltip = false;

		[EditorHelp("Above Affect Range", "The available target highlight will be displayed above the affect range highlight, " +
			"i.e. an available target will overrule the affect range.\n" +
			"If disabled, the affect range will overrule the available targets.", "")]
		public bool availableTargetAboveAffectRange = true;

		[EditorFoldout("Available Target (Player)", "The available player target highlight is used to display " +
			"the available targets that are members of the player group during target selection (not target cell selection).", "")]
		[EditorEndFoldout]
		public GridHighlightSetting availableTargetPlayerHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Available Target (Ally)", "The available ally target highlight is used to display " +
			"the available targets that are allies of the player during target selection (not target cell selection).", "")]
		[EditorEndFoldout]
		public GridHighlightSetting availableTargetAllyHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Available Target (Enemy)", "The available enemy target highlight is used to display " +
			"the available targets that are enemies of the player during target selection (not target cell selection).", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting availableTargetEnemyHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);


		// selected target
		[EditorHelp("UI Hides Available Target", "Selected target highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Selected Target", "Highlight settings for selected targets during target selection for an action.", "")]
		public bool uiHidesSelectedTarget = false;

		[EditorFoldout("Selected Target (Player)", "The selected player target highlight is used to display " +
			"the selected targets that are members of the player group during target selection (not target cell selection).", "")]
		[EditorEndFoldout]
		public GridHighlightSetting selectedTargetPlayerHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Selected Target (Ally)", "The selected ally target highlight is used to display " +
			"the selected targets that are allies of the player during target selection (not target cell selection).", "")]
		[EditorEndFoldout]
		public GridHighlightSetting selectedTargetAllyHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Selected Target (Enemy)", "The selected enemy target highlight is used to display " +
			"the selected targets that are enemies of the player during target selection (not target cell selection).", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting selectedTargetEnemyHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);


		// target cell selection
		[EditorHelp("UI Hides Target Cell", "Target cell highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Target Cell", "Highlight settings for target cell selection for an action.", "")]
		public bool uiHidesTargetCell = false;

		[EditorFoldout("Target Cell Selection", "The target cell selection highlight is used to display " +
			"the currently selected cell that is a valid target.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting targetCellSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("No Target Cell Selection", "The no target cell selection highlight is used to display " +
			"the currently selected cell that is not a valid target.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting noTargetCellSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.NoSelection);


		// orientation
		[EditorHelp("UI Hides Orientation", "Orientation highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Orientation Selection", "The orientation selection highlight is used to display " +
			"the currently selected orientation cell (i.e. the cell the combatant will turn to) when selecting the orientation.", "")]
		public bool uiHidesOrientation = false;

		[EditorEndFoldout]
		public GridHighlightSetting orientationSelectionHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);


		// marked cell
		[EditorHelp("UI Hides Marked Cell", "Marked cell highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Marked Cell", "The marked cell highlight is used to display grid cells that are marked for a combatant " +
			"(e.g. being the target of a grid move command).\n" +
			"The marked cell highlight is always displayed while a cell is marked for a combatant.", "")]
		public bool uiHidesMarkedCell = false;

		[EditorEndFoldout]
		public GridHighlightSetting markedCellHighlight = new GridHighlightSetting(GridBaseHighlight.Area);


		// use range
		[EditorHelp("UI Hides Use Range", "Use range highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Use Range", "The use range highlight is used to display use ranges of abilities and items.", "")]
		public bool uiHidesUseRange = false;

		[EditorHelp("In Action Selection", "The use range of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the use range cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool useRangeActionSelection = false;

		[EditorHelp("In Target Selection", "The use range of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the use range cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool useRangeTargetSelection = false;

		[EditorHelp("For Tooltips", "The use range of an ability/item will be highlighted for tooltips (i.e. cursor over something with a tooltip).\n" +
			"I.e. the use range cells will be highlighted while having the cursor over something with a tooltip (e.g. from a 'Shortcut' slot in a HUD).", "")]
		public bool useRangeTooltip = false;

		[EditorEndFoldout]
		public GridHighlightSetting useRangeHighlight = new GridHighlightSetting(GridBaseHighlight.Area);


		// affect range
		[EditorHelp("UI Hides Affect Range", "Affect range highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Affect Range", "The affect range highlight is used to display affect ranges of abilities and items.", "")]
		public bool uiHidesAffectRange = false;

		[EditorHelp("In Action Selection", "The affect range of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the affect range cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool affectRangeActionSelection = false;

		[EditorHelp("In Target Selection", "The affect range of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the affect range cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool affectRangeTargetSelection = false;

		[EditorHelp("For Tooltips", "The affect range of an ability/item will be highlighted for tooltips (i.e. cursor over something with a tooltip).\n" +
			"I.e. the affect range cells will be highlighted while having the cursor over something with a tooltip (e.g. from a 'Shortcut' slot in a HUD).", "")]
		public bool affectRangeTooltip = false;

		[EditorEndFoldout]
		public GridHighlightSetting affectRangeHighlight = new GridHighlightSetting(GridBaseHighlight.Area);


		// examine grid
		[EditorHelp("UI Hides Examine", "Examine highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Examine Selection", "Highlight settings for the examine cell selection.", "")]
		public bool uiHidesExamine = false;

		[EditorHelp("Combatant Is Blocked", "Combatants use the blocked selection cursor.", "")]
		public bool examineCombatantIsBlocked = false;

		[EditorFoldout("Examine (Not Blocked)", "The examine selection highlight is used to display " +
			"the currently selected cell (not blocked) during grid examination.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting examineHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Examine (Blocked)", "The examine blocked selection highlight is used to display " +
			"the currently selected cell (blocked) during grid examination.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting examineBlockedHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);


		// selecting combatant
		[EditorHelp("UI Hides Selecting Combatant", "Selecting combatant highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Selecting Combatant", "Highlight settings for the combatant currently selecting actions.", "")]
		public bool uiHidesSelectingCombatant = false;

		[EditorHelp("Prioritize Selecting", "The selecting combatant highlights will be prioritized, " +
			"i.e. they'll be displayed instead of all other highlights (e.g. selection cursors).", "")]
		public bool selectingPriority = false;

		[EditorHelp("In Action Selection", "The selecting combatant will also be highlighted in the action selection of the battle menu.\n" +
			"I.e. the selecting combatant's cell will also be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool selectingCombatantActionSelection = false;

		[EditorHelp("In Target Selection", "The selecting combatant will also be highlighted in the target selection.\n" +
			"I.e. the selecting combatant's cell will also be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool selectingCombatantTargetSelection = false;

		[EditorHelp("For Tooltips", "The selecting combatant will be highlighted for tooltips (i.e. cursor over something with a tooltip).\n" +
			"I.e. the selecting combatant's cell will be highlighted while having the cursor over something with a tooltip (e.g. from a 'Shortcut' slot in a HUD).", "")]
		public bool selectingCombatantTooltip = false;

		[EditorFoldout("Selecting Player", "The selecting player highlight is used to display " +
			"the currently selecting members of the player group.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting selectingPlayerHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Selecting Ally", "The selecting ally highlight is used to display " +
			"the currently selecting combatants that are allies of the player.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting selectingAllyHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);

		[EditorFoldout("Selecting Enemy", "The selecting enemy highlight is used to display " +
			"the currently selecting combatants that are enemies of the player.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting selectingEnemyHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);


		// grid formations
		[EditorHelp("UI Hides Grid Formation", "Grid formation highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Grid Formation", "Highlight settings for grid formations during a player combatant's turn.", "")]
		public bool uiHidesGridFormation = false;

		[EditorFoldout("Grid Formation", "The grid formation highlight is used to display cells that are part of the grid formation.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting gridFormationHighlight = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Formation Position", "The formation position highlight is used to display the combatant's formation position cell.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting gridFormationPositionHighlight = new GridHighlightSetting(GridBaseHighlight.Selection);


		// custom highlights
		[EditorHelp("UI Hides Custom", "Custom highlights are hidden while the cursor is over a UI (e.g. a HUD).", "")]
		[EditorFoldout("Custom Highlights", "Custom grid highlights can be used in 'Highlight Grid Cell' nodes in schematics.", "")]
		public bool uiHidesCustom = false;

		[EditorFoldout("Custom 1", "The highlight is used when using the 'Custom1' highlight in a 'Highlight Grid Cell' node in schematics.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting customHighlight = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Custom 2", "The highlight is used when using the 'Custom2' highlight in a 'Highlight Grid Cell' node in schematics.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting customHighlight2 = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Custom 3", "The highlight is used when using the 'Custom3' highlight in a 'Highlight Grid Cell' node in schematics.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting customHighlight3 = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Custom 4", "The highlight is used when using the 'Custom4' highlight in a 'Highlight Grid Cell' node in schematics.", "")]
		[EditorEndFoldout]
		public GridHighlightSetting customHighlight4 = new GridHighlightSetting(GridBaseHighlight.Area);

		[EditorFoldout("Custom 5", "The highlight is used when using the 'Custom5' highlight in a 'Highlight Grid Cell' node in schematics.", "")]
		[EditorEndFoldout(2)]
		public GridHighlightSetting customHighlight5 = new GridHighlightSetting(GridBaseHighlight.Area);


		// ingame
		protected bool hideGridHighlights = false;

		public BattleGridHighlightSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle Grid Highlights"; }
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public virtual bool HideGridHighlights
		{
			get { return this.hideGridHighlights; }
			set
			{
				if(this.hideGridHighlights != value)
				{
					this.hideGridHighlights = value;
					if(ORK.Battle.Grid != null)
					{
						ORK.Battle.Grid.UpdateHighlightHideState();
					}
				}
			}
		}

		public virtual void Tick()
		{
			float deltaTime = Maki.Game.DeltaTime;

			this.areaHighlight.Tick(deltaTime);
			this.selectionHighlight.Tick(deltaTime);
			this.noSelectionHighlight.Tick(deltaTime);
			this.placementHighlight.Tick(deltaTime);
			this.placementSelectionHighlight.Tick(deltaTime);
			this.noPlacementSelectionHighlight.Tick(deltaTime);
			this.moveRangeHighlight.Tick(deltaTime);
			this.moveRangeBlockedHighlight.Tick(deltaTime);
			this.moveRangePassableHighlight.Tick(deltaTime);
			this.moveSelectionHighlight.Tick(deltaTime);
			this.noMoveSelectionHighlight.Tick(deltaTime);
			this.movePathHighlight.Tick(deltaTime);
			this.targetCellSelectionHighlight.Tick(deltaTime);
			this.noTargetCellSelectionHighlight.Tick(deltaTime);
			this.orientationSelectionHighlight.Tick(deltaTime);
			this.markedCellHighlight.Tick(deltaTime);
			this.useRangeHighlight.Tick(deltaTime);
			this.affectRangeHighlight.Tick(deltaTime);
			this.examineHighlight.Tick(deltaTime);
			this.examineBlockedHighlight.Tick(deltaTime);
			this.availableTargetPlayerHighlight.Tick(deltaTime);
			this.availableTargetAllyHighlight.Tick(deltaTime);
			this.availableTargetEnemyHighlight.Tick(deltaTime);
			this.selectedTargetPlayerHighlight.Tick(deltaTime);
			this.selectedTargetAllyHighlight.Tick(deltaTime);
			this.selectedTargetEnemyHighlight.Tick(deltaTime);
			this.selectingPlayerHighlight.Tick(deltaTime);
			this.selectingAllyHighlight.Tick(deltaTime);
			this.selectingEnemyHighlight.Tick(deltaTime);
			this.gridFormationHighlight.Tick(deltaTime);
			this.gridFormationPositionHighlight.Tick(deltaTime);
			this.customHighlight.Tick(deltaTime);
			this.customHighlight2.Tick(deltaTime);
			this.customHighlight3.Tick(deltaTime);
			this.customHighlight4.Tick(deltaTime);
			this.customHighlight5.Tick(deltaTime);

			if(this.useCombatantCells)
			{
				this.combatantCellPlayer.Tick(deltaTime);
				this.combatantCellAlly.Tick(deltaTime);
				this.combatantCellEnemy.Tick(deltaTime);
				if(this.useTurnEndedCombatantCells)
				{
					this.combatantCellPlayerTurnEnded.Tick(deltaTime);
					this.combatantCellAllyTurnEnded.Tick(deltaTime);
					this.combatantCellEnemyTurnEnded.Tick(deltaTime);
				}
			}

			if(this.useCombatantSelections)
			{
				this.combatantSelectionPlayer.Tick(deltaTime);
				this.combatantSelectionAlly.Tick(deltaTime);
				this.combatantSelectionEnemy.Tick(deltaTime);
			}

			if(this.uiHidesCombatantCells ||
				this.uiHidesCombatantSelections ||
				this.uiHidesPlacement ||
				this.uiHidesMoveCommand ||
				this.uiHidesAvailableTarget ||
				this.uiHidesTargetCell ||
				this.uiHidesOrientation ||
				this.uiHidesUseRange ||
				this.uiHidesAffectRange ||
				this.uiHidesExamine ||
				this.uiHidesSelectingCombatant)
			{
				ORK.Battle.Grid.HighlightsHiddenByUI = Maki.UI.IsCursorOver;
			}
		}

		public virtual bool IsHidden(GridCellHighlight type)
		{
			if(Maki.UI.IsCursorOver)
			{
				// placement
				return (this.uiHidesCombatantCells &&
						(GridCellHighlight.CellPlayer == type ||
						GridCellHighlight.CellAlly == type ||
						GridCellHighlight.CellEnemy == type)) ||
					// placement
					(this.uiHidesPlacement &&
						(GridCellHighlight.Placement == type ||
						GridCellHighlight.PlacementSelection == type ||
						GridCellHighlight.NoPlacementSelection == type)) ||
					// move command
					(this.uiHidesMoveCommand &&
						(GridCellHighlight.MovePath == type ||
						GridCellHighlight.MoveRange == type ||
						GridCellHighlight.MoveRangeBlocked == type ||
						GridCellHighlight.MoveRangePassable == type ||
						GridCellHighlight.MoveSelection == type ||
						GridCellHighlight.NoMoveSelection == type)) ||
					// available targets
					(this.uiHidesAvailableTarget &&
						(GridCellHighlight.AvailableTargetAlly == type ||
						GridCellHighlight.AvailableTargetEnemy == type ||
						GridCellHighlight.AvailableTargetPlayer == type)) ||
					// selected targets
					(this.uiHidesSelectedTarget &&
						(GridCellHighlight.SelectedTargetAlly == type ||
						GridCellHighlight.SelectedTargetEnemy == type ||
						GridCellHighlight.SelectedTargetPlayer == type)) ||
					// target cell
					(this.uiHidesTargetCell &&
						(GridCellHighlight.TargetCellSelection == type ||
						GridCellHighlight.NoTargetCellSelection == type)) ||
					// orientation
					(this.uiHidesOrientation &&
						GridCellHighlight.OrientationSelection == type) ||
					// marked cell
					(this.uiHidesMarkedCell &&
						GridCellHighlight.MarkedCell == type) ||
					// use range
					(this.uiHidesUseRange &&
						GridCellHighlight.UseRange == type) ||
					// affect range
					(this.uiHidesAffectRange &&
						GridCellHighlight.AffectRange == type) ||
					// examine
					(this.uiHidesExamine &&
						(GridCellHighlight.ExamineSelection == type ||
						GridCellHighlight.ExamineSelectionBlocked == type ||
						GridCellHighlight.ExamineMoveRange == type ||
						GridCellHighlight.ExamineMoveRangeBlocked == type ||
						GridCellHighlight.ExamineMoveRangePassable == type ||
						GridCellHighlight.ExamineUseRange == type)) ||
					// selecting combatant
					(this.uiHidesSelectingCombatant &&
						(GridCellHighlight.SelectingAlly == type ||
						GridCellHighlight.SelectingEnemy == type ||
						GridCellHighlight.SelectingPlayer == type)) ||
					// combatant selection
					(this.uiHidesCombatantSelections &&
						(GridCellHighlight.PlacementSelectionPlayer == type ||
						GridCellHighlight.PlacementSelectionEnemy == type ||
						GridCellHighlight.PlacementSelectionAlly == type ||
						GridCellHighlight.MoveSelectionPlayer == type ||
						GridCellHighlight.MoveSelectionAlly == type ||
						GridCellHighlight.MoveSelectionEnemy == type ||
						GridCellHighlight.OrientationSelectionPlayer == type ||
						GridCellHighlight.OrientationSelectionAlly == type ||
						GridCellHighlight.OrientationSelectionEnemy == type ||
						GridCellHighlight.TargetCellSelectionPlayer == type ||
						GridCellHighlight.TargetCellSelectionAlly == type ||
						GridCellHighlight.TargetCellSelectionEnemy == type ||
						GridCellHighlight.ExamineSelectionPlayer == type ||
						GridCellHighlight.ExamineSelectionAlly == type ||
						GridCellHighlight.ExamineSelectionEnemy == type)) ||
					(this.uiHidesGridFormation &&
						(GridCellHighlight.GridFormation == type ||
						GridCellHighlight.GridFormationPosition == type)) ||
					(this.uiHidesCustom &&
						(GridCellHighlight.Custom1 == type ||
						GridCellHighlight.Custom2 == type ||
						GridCellHighlight.Custom3 == type ||
						GridCellHighlight.Custom4 == type ||
						GridCellHighlight.Custom5 == type));
			}
			return false;
		}

		public virtual GridCellHighlight GetSelectionHighlight(GridCellHighlight type, BattleGridCellComponent cell)
		{
			if(this.useCombatantSelections &&
				cell != null && cell.Combatant != null)
			{
				// player
				if(cell.Combatant.IsPlayerControlled())
				{
					if(this.combatantSelectionPlayer.enable)
					{
						// placement
						if(GridCellHighlight.PlacementSelection == type ||
							GridCellHighlight.NoPlacementSelection == type)
						{
							return GridCellHighlight.PlacementSelectionPlayer;
						}
						// move command
						else if(GridCellHighlight.MoveSelection == type ||
							GridCellHighlight.NoMoveSelection == type)
						{
							return GridCellHighlight.MoveSelectionPlayer;
						}
						// orientation
						else if(GridCellHighlight.OrientationSelection == type)
						{
							return GridCellHighlight.OrientationSelectionPlayer;
						}
						// target cell
						else if(GridCellHighlight.TargetCellSelection == type ||
							GridCellHighlight.NoTargetCellSelection == type)
						{
							return GridCellHighlight.TargetCellSelectionPlayer;
						}
						// examine
						else if(GridCellHighlight.ExamineSelection == type ||
							GridCellHighlight.ExamineSelectionBlocked == type)
						{
							return GridCellHighlight.ExamineSelectionPlayer;
						}
					}
				}
				// enemy
				else if(cell.Combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(this.combatantSelectionEnemy.enable)
					{
						// placement
						if(GridCellHighlight.PlacementSelection == type ||
							GridCellHighlight.NoPlacementSelection == type)
						{
							return GridCellHighlight.PlacementSelectionEnemy;
						}
						// move command
						else if(GridCellHighlight.MoveSelection == type ||
							GridCellHighlight.NoMoveSelection == type)
						{
							return GridCellHighlight.MoveSelectionEnemy;
						}
						// orientation
						else if(GridCellHighlight.OrientationSelection == type)
						{
							return GridCellHighlight.OrientationSelectionEnemy;
						}
						// target cell
						else if(GridCellHighlight.TargetCellSelection == type ||
							GridCellHighlight.NoTargetCellSelection == type)
						{
							return GridCellHighlight.TargetCellSelectionEnemy;
						}
						// examine
						else if(GridCellHighlight.ExamineSelection == type ||
							GridCellHighlight.ExamineSelectionBlocked == type)
						{
							return GridCellHighlight.ExamineSelectionEnemy;
						}
					}
				}
				// ally
				else if(this.combatantSelectionAlly.enable)
				{
					// placement
					if(GridCellHighlight.PlacementSelection == type ||
							GridCellHighlight.NoPlacementSelection == type)
					{
						return GridCellHighlight.PlacementSelectionAlly;
					}
					// move command
					else if(GridCellHighlight.MoveSelection == type ||
						GridCellHighlight.NoMoveSelection == type)
					{
						return GridCellHighlight.MoveSelectionAlly;
					}
					// orientation
					else if(GridCellHighlight.OrientationSelection == type)
					{
						return GridCellHighlight.OrientationSelectionAlly;
					}
					// target cell
					else if(GridCellHighlight.TargetCellSelection == type ||
						GridCellHighlight.NoTargetCellSelection == type)
					{
						return GridCellHighlight.TargetCellSelectionAlly;
					}
					// examine
					else if(GridCellHighlight.ExamineSelection == type ||
						GridCellHighlight.ExamineSelectionBlocked == type)
					{
						return GridCellHighlight.ExamineSelectionAlly;
					}
				}
			}
			return type;
		}

		public virtual GridCellHighlight GetCombatantCellHighlight(Combatant combatant)
		{
			if(this.useCombatantCells &&
				combatant != null)
			{
				// player
				if(combatant.IsPlayerControlled())
				{
					if(CombatantTurnState.AfterTurn == combatant.Battle.TurnState &&
						this.useTurnEndedCombatantCells &&
						this.combatantCellPlayerTurnEnded.enable)
					{
						return GridCellHighlight.CellPlayerTurnEnded;
					}
					else if(this.combatantCellPlayer.enable)
					{
						return GridCellHighlight.CellPlayer;
					}
				}
				// enemy
				else if(combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(CombatantTurnState.AfterTurn == combatant.Battle.TurnState &&
						this.useTurnEndedCombatantCells &&
						this.combatantCellEnemyTurnEnded.enable)
					{
						return GridCellHighlight.CellEnemyTurnEnded;
					}
					else if(this.combatantCellEnemy.enable)
					{
						return GridCellHighlight.CellEnemy;
					}
				}
				// ally
				else
				{
					if(CombatantTurnState.AfterTurn == combatant.Battle.TurnState &&
						this.useTurnEndedCombatantCells &&
						this.combatantCellAllyTurnEnded.enable)
					{
						return GridCellHighlight.CellAllyTurnEnded;
					}
					else if(this.combatantCellAlly.enable)
					{
						return GridCellHighlight.CellAlly;
					}
				}
			}
			return GridCellHighlight.None;
		}

		public virtual bool IsEnabled(GridCellHighlight type)
		{
			GridHighlightSetting highlight = this.GetHighlight(type);
			return highlight != null && highlight.enable;
		}

		public virtual GridHighlightSetting GetHighlight(GridCellHighlight type)
		{
			// combatant cell
			// player
			if(GridCellHighlight.CellPlayerTurnEnded == type)
			{
				return this.combatantCellPlayerTurnEnded;
			}
			else if(GridCellHighlight.CellPlayer == type)
			{
				return this.combatantCellPlayer;
			}
			// ally
			else if(GridCellHighlight.CellAllyTurnEnded == type)
			{
				return this.combatantCellAllyTurnEnded;
			}
			else if(GridCellHighlight.CellAlly == type)
			{
				return this.combatantCellAlly;
			}
			// enemey
			else if(GridCellHighlight.CellEnemyTurnEnded == type)
			{
				return this.combatantCellEnemyTurnEnded;
			}
			else if(GridCellHighlight.CellEnemy == type)
			{
				return this.combatantCellEnemy;
			}
			// combatant selection override
			else if(GridCellHighlight.PlacementSelectionPlayer == type ||
				GridCellHighlight.MoveSelectionPlayer == type ||
				GridCellHighlight.OrientationSelectionPlayer == type ||
				GridCellHighlight.TargetCellSelectionPlayer == type ||
				GridCellHighlight.ExamineSelectionPlayer == type)
			{
				return this.combatantSelectionPlayer;
			}
			else if(GridCellHighlight.PlacementSelectionAlly == type ||
				GridCellHighlight.MoveSelectionAlly == type ||
				GridCellHighlight.OrientationSelectionAlly == type ||
				GridCellHighlight.TargetCellSelectionAlly == type ||
				GridCellHighlight.ExamineSelectionAlly == type)
			{
				return this.combatantSelectionAlly;
			}
			else if(GridCellHighlight.PlacementSelectionEnemy == type ||
				GridCellHighlight.MoveSelectionEnemy == type ||
				GridCellHighlight.OrientationSelectionEnemy == type ||
				GridCellHighlight.TargetCellSelectionEnemy == type ||
				GridCellHighlight.ExamineSelectionEnemy == type)
			{
				return this.combatantSelectionEnemy;
			}
			// placement
			else if(GridCellHighlight.Placement == type)
			{
				return this.placementHighlight;
			}
			else if(GridCellHighlight.PlacementSelection == type)
			{
				return this.placementSelectionHighlight;
			}
			else if(GridCellHighlight.NoPlacementSelection == type)
			{
				return this.noPlacementSelectionHighlight;
			}
			// move
			else if(GridCellHighlight.MoveRange == type)
			{
				return this.moveRangeHighlight;
			}
			else if(GridCellHighlight.MoveRangeBlocked == type)
			{
				return this.moveRangeBlockedHighlight;
			}
			else if(GridCellHighlight.MoveRangePassable == type)
			{
				return this.moveRangePassableHighlight;
			}
			else if(GridCellHighlight.MoveSelection == type)
			{
				return this.moveSelectionHighlight;
			}
			else if(GridCellHighlight.NoMoveSelection == type)
			{
				return this.noMoveSelectionHighlight;
			}
			else if(GridCellHighlight.MovePath == type)
			{
				return this.movePathHighlight;
			}
			// orientation
			else if(GridCellHighlight.OrientationSelection == type)
			{
				return this.orientationSelectionHighlight;
			}
			// marked cell
			else if(GridCellHighlight.MarkedCell == type)
			{
				return this.markedCellHighlight;
			}
			// use/affect range
			else if(GridCellHighlight.UseRange == type)
			{
				return this.useRangeHighlight;
			}
			else if(GridCellHighlight.AffectRange == type)
			{
				return this.affectRangeHighlight;
			}
			// available target
			else if(GridCellHighlight.AvailableTargetPlayer == type)
			{
				return this.availableTargetPlayerHighlight;
			}
			else if(GridCellHighlight.AvailableTargetAlly == type)
			{
				return this.availableTargetAllyHighlight;
			}
			else if(GridCellHighlight.AvailableTargetEnemy == type)
			{
				return this.availableTargetEnemyHighlight;
			}
			// selected target
			else if(GridCellHighlight.SelectedTargetPlayer == type)
			{
				return this.selectedTargetPlayerHighlight;
			}
			else if(GridCellHighlight.SelectedTargetAlly == type)
			{
				return this.selectedTargetAllyHighlight;
			}
			else if(GridCellHighlight.SelectedTargetEnemy == type)
			{
				return this.selectedTargetEnemyHighlight;
			}
			// target cell
			else if(GridCellHighlight.TargetCellSelection == type)
			{
				return this.targetCellSelectionHighlight;
			}
			else if(GridCellHighlight.NoTargetCellSelection == type)
			{
				return this.noTargetCellSelectionHighlight;
			}
			// examine
			else if(GridCellHighlight.ExamineSelection == type)
			{
				return this.examineHighlight;
			}
			else if(GridCellHighlight.ExamineSelectionBlocked == type)
			{
				return this.examineBlockedHighlight;
			}
			else if(GridCellHighlight.ExamineMoveRange == type)
			{
				return this.moveRangeHighlight;
			}
			else if(GridCellHighlight.ExamineMoveRangeBlocked == type)
			{
				return this.moveRangeBlockedHighlight;
			}
			else if(GridCellHighlight.ExamineMoveRangePassable == type)
			{
				return this.moveRangePassableHighlight;
			}
			else if(GridCellHighlight.ExamineUseRange == type)
			{
				return this.useRangeHighlight;
			}
			// selecting combatant
			else if(GridCellHighlight.SelectingPlayer == type)
			{
				return this.selectingPlayerHighlight;
			}
			else if(GridCellHighlight.SelectingAlly == type)
			{
				return this.selectingAllyHighlight;
			}
			else if(GridCellHighlight.SelectingEnemy == type)
			{
				return this.selectingEnemyHighlight;
			}
			// grid formation
			else if(GridCellHighlight.GridFormation == type)
			{
				return this.gridFormationHighlight;
			}
			else if(GridCellHighlight.GridFormationPosition == type)
			{
				return this.gridFormationPositionHighlight;
			}
			// custom
			else if(GridCellHighlight.Custom1 == type)
			{
				return this.customHighlight;
			}
			else if(GridCellHighlight.Custom2 == type)
			{
				return this.customHighlight2;
			}
			else if(GridCellHighlight.Custom3 == type)
			{
				return this.customHighlight3;
			}
			else if(GridCellHighlight.Custom4 == type)
			{
				return this.customHighlight4;
			}
			else if(GridCellHighlight.Custom5 == type)
			{
				return this.customHighlight5;
			}
			return null;
		}

		public virtual Dictionary<GridCellHighlight, GridHighlightSetting> GetHighlights()
		{
			Dictionary<GridCellHighlight, GridHighlightSetting> list = new Dictionary<GridCellHighlight, GridHighlightSetting>();
			foreach(GridCellHighlight type in (GridCellHighlight[])System.Enum.GetValues(typeof(GridCellHighlight)))
			{
				GridHighlightSetting highlight = this.GetHighlight(type);
				if(highlight != null)
				{
					list.Add(type, highlight);
				}
			}
			return list;
		}

		public virtual bool IsCombatantHighlight(GridCellHighlight type)
		{
			return GridCellHighlight.AvailableTargetAlly == type ||
				GridCellHighlight.AvailableTargetEnemy == type ||
				GridCellHighlight.AvailableTargetPlayer == type ||
				GridCellHighlight.CellAlly == type ||
				GridCellHighlight.CellAllyTurnEnded == type ||
				GridCellHighlight.CellEnemy == type ||
				GridCellHighlight.CellEnemyTurnEnded == type ||
				GridCellHighlight.CellPlayer == type ||
				GridCellHighlight.CellPlayerTurnEnded == type ||
				GridCellHighlight.ExamineSelectionAlly == type ||
				GridCellHighlight.ExamineSelectionEnemy == type ||
				GridCellHighlight.ExamineSelectionPlayer == type ||
				GridCellHighlight.MoveSelectionAlly == type ||
				GridCellHighlight.MoveSelectionEnemy == type ||
				GridCellHighlight.MoveSelectionPlayer == type ||
				GridCellHighlight.OrientationSelectionAlly == type ||
				GridCellHighlight.OrientationSelectionEnemy == type ||
				GridCellHighlight.OrientationSelectionPlayer == type ||
				GridCellHighlight.PlacementSelectionAlly == type ||
				GridCellHighlight.PlacementSelectionEnemy == type ||
				GridCellHighlight.PlacementSelectionPlayer == type ||
				GridCellHighlight.SelectingAlly == type ||
				GridCellHighlight.SelectingEnemy == type ||
				GridCellHighlight.SelectingPlayer == type ||
				GridCellHighlight.TargetCellSelectionAlly == type ||
				GridCellHighlight.TargetCellSelectionEnemy == type ||
				GridCellHighlight.TargetCellSelectionPlayer == type ||
				GridCellHighlight.MarkedCell == type;
		}
	}
}
