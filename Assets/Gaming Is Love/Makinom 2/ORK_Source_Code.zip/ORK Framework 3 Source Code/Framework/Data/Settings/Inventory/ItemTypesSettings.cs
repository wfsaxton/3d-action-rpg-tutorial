
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ItemTypesSettings : GenericAssetListSettings<ItemTypeAsset, ItemType>
	{
		public ItemTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Item Types"; }
		}
	}
}

