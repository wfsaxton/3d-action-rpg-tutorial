
using UnityEngine;
using GamingIsLove.ORKFramework.Combatants;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleSettings : BaseSettings
	{
		// base settings
		[EditorHelp("Default Battle System", "Select which battle system will be used when a battle or combatant doesn't define a specific system.")]
		[EditorFoldout("Base Settings", "Base battle system settings.", "")]
		public AssetSelection<BattleSystemAsset> defaultBattleSystem = new AssetSelection<BattleSystemAsset>();

		[EditorHelp("Real Time Area System", "Select which 'Real Time' battle system will be used in real time battle areas.")]
		[EditorAssetSelectionCondition("settings.Type", BattleSystemType.RealTime, true)]
		public AssetSelection<BattleSystemAsset> realTimeBattleAreaSystem = new AssetSelection<BattleSystemAsset>();

		[EditorHelp("Default Battle Menu", "The default battle menu.\n" +
			"Battle systems, classes and combatants can override the default battle menu.", "")]
		[EditorSeparator]
		public AssetSelection<BattleMenuAsset> defaultBattleMenu = new AssetSelection<BattleMenuAsset>();

		// enemy counting
		[EditorHelp("Enemy Counter", "Enemies of the same type can have a counter " +
			"added to their name to differentiate them from another:\n" +
			"- None: No counter is added.\n" +
			"- Letters: Letters are used (A, B, C, ...).\n" +
			"- Numbers: Numbers are used (1, 2, 3, ...).\n" +
			"The enemy counter is only used in arena battles.", "")]
		[EditorSeparator]
		public EnemyCounting enemyCounter = EnemyCounting.None;

		[EditorHelp("Count Type", "Select how enemies are counted:\n" +
			"- ID: Based on the combatant's ID.\n" +
			"- Name: Based on the combatant's name (i.e. matching names are counted together).", "")]
		[EditorIndent]
		[EditorCondition("enemyCounter", EnemyCounting.None)]
		[EditorElseCondition]
		[EditorEndCondition]
		public EnemyCountingType enemyCounterType = EnemyCountingType.ID;

		// animations
		[EditorHelp("Play Damage Animation", "Combatants currently performing a battle action " +
			"(and by this a battle animation) will play their damage animation when receiving damage.\n" +
			"If disabled, damage animations will be ignored for combatants that are in action while receiving damage.", "")]
		[EditorSeparator]
		public bool playDamageAnim = false;

		[EditorHelp("Play Victory Animation", "The combatants that won the battle will play the victory animation type.\n" +
			"Disable this setting to not automatically play a victory animation, e.g. if you want to handle this in the battle end schematic.", "")]
		public bool playVictoryAnimation = true;

		// other
		[EditorHelp("Remove Dead Actions", "A combatant's death will remove all scheduled actions of the combatant.\n" +
			"If disabled, the actions are kept scheduled and will be removed when trying to perform them.", "")]
		[EditorSeparator]
		public bool removeDeadActions = false;

		// chances and factors
		// base defend rate
		[EditorHelp("Base Defend Rate", "Define the base defence rate when using the defend command.\n" +
			"It's used as percent value - i.e. if the value is 100, " +
			"the damage will do 100 % of it's original damage, if the result is 50, the damage " +
			"will only do 50 % of it's original damage.")]
		[EditorFoldout("Chances & Factors", "Define the default chances and factors, e.g. base counter chance or experience factor.\n" +
			"Combatants can override the default chances and factors.", "")]
		public FloatValue<GameObjectSelection> defendRate = new FloatValue<GameObjectSelection>(50);

		// base counter chance
		[EditorHelp("Base Counter Chance", "Define the base counter chance.\n" +
			"The counter chance decides if a combatant counters an attack (i.e. when received damage).\n" +
			"The counter is performed if a random float number between two values (default 0 and 100, you can change " +
			"this in the game settings) is less or equal to this value.\n" +
			"When using a formula, the attacked combatant (who will counter) will be used as the user in the calculation, " +
			"while the attacker is the target.\n" +
			"Combatants can override the counter chance.", "")]
		[EditorSeparator]
		public FloatValue<GameObjectSelection> counterChance = new FloatValue<GameObjectSelection>();

		// base block chance
		[EditorHelp("Base Block Chance", "Define the base block chance.\n" +
			"Attacks and abilities can be blocked (if enabled) if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) is less or equal to this value.\n" +
			"When using a formula, the attacked combatant will be used as the target in the calculation, " +
			"while the attacker is the user.\n" +
			"Combatants can override the block chance.", "")]
		[EditorSeparator]
		public FloatValue<GameObjectSelection> blockChance = new FloatValue<GameObjectSelection>();

		// escape chance
		[EditorHelp("Base Escape Chance", "Define the base escape chance when using the escape command.\n" +
			"The escape is performed if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to this value.\n" +
			"Combatants can override the escape chance.", "")]
		[EditorSeparator]
		public FloatValue<GameObjectSelection> escapeChance = new FloatValue<GameObjectSelection>(50);

		// experience factor
		[EditorHelp("Base Experience Factor", "Define the base experience factor.\n" +
			"The experience factor influences the experience a combatant gains from battle. E.g.:\n" +
			"- factor 1: The combatant gets 100 % of the experience.\n" +
			"- factor 0.5: The combatant gets 50 % of the experience.\n" +
			"- factor 2: The combatant gets 200 % of the experience.\n" +
			"A negative experience factor is not possible, the smallest factor is 0.\n" +
			"Combatants can override the experience factor.", "")]
		[EditorSeparator]
		public FloatValue<GameObjectSelection> experienceFactor = new FloatValue<GameObjectSelection>(1);

		// random battle factor
		[EditorHelp("Random Battle Factor", "Define the random battle factor.\n" +
			"The random battle factor is used to influence the chance of random battles occurring via 'Random Battle Area' components. " +
			"The factor is influenced by the player battle group's random battle factor bonuses.\n" +
			"When using a formula, the player combatant (i.e. leader of the player group) will be used as user and target.\n\n" +
			"E.g.:\n" +
			"The random battle chance is 10 %, the factor is 100 % - the final chance is 10 %.\n" +
			"The chance is 10 %, the factor is 50 % - the final chance is 5 %.", "")]
		[EditorEndFoldout]
		[EditorSeparator]
		public FloatValue<GameObjectSelection> randomBattleFactor = new FloatValue<GameObjectSelection>(100);

		// auto join
		[EditorFoldout("Auto Join Settings", "Combatants within range of a starting battle can " +
			"automatically join the battle.\n" +
			"This setting can be overridden by individual 'Battle' components in the scene.\n" +
			"Note that this is only used in arena battles (i.e. using the 'Battle' component), " +
			"and not in real time area battles.", "")]
		[EditorEndFoldout]
		public AutoJoinBattle autoJoin = new AutoJoinBattle();

		// field mode
		[EditorFoldout("Field Mode", "Define how the battle system handles things while in the field (i.e. not in battle).")]
		[EditorEndFoldout(2)]
		public FieldMode fieldMode = new FieldMode();


		// ranges
		// battle range
		[EditorHelp("Use Battle Range", "The battle range is used to determine participating combatants.\n" +
			"If disabled, all combatants will participate in battle.", "")]
		[EditorFoldout("Range Settings", "Define ranges of the battle system, e.g. the battle range or AI range.", "",
			"Battle Range", "The distance (in world units) a combatant can " +
			"have to the player to participate in a battle.", "")]
		public bool useBattleRange = true;

		[EditorEndFoldout]
		[EditorCondition("useBattleRange", true)]
		[EditorEndCondition]
		public RangeValue battleRange = new RangeValue(100.0f);

		// AI settings
		[EditorHelp("Use AI Range", "The AI range is used to determine if a combatant can perform AI actions.\n" +
			"If disabled, the distance to the player doesn't prevent performing AI actions.", "")]
		[EditorFoldout("AI Range", "The distance (in world units) a combatant can " +
			"have to the player to perform AI actions.", "")]
		public bool useAIRange = true;

		[EditorHelp("AI Recheck Time (s)", "The time in seconds between AI range checks.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("useAIRange", true)]
		public float aiRecheckTime = 4.0f;

		[EditorEndFoldout]
		[EditorEndCondition]
		public RangeValue aiRange = new RangeValue(100.0f);

		// move AI range
		[EditorHelp("Use Move AI Range", "The move AI range is used to determine if a combatant can use the move AI.\n" +
			"If disabled, the distance to the player doesn't prevent using the move AI.", "")]
		[EditorFoldout("Move AI Range", "The distance (in world units) a combatant can " +
			"have to the player to use the move AI.\n" +
			"This will be used while not in battle - " +
			"each battle system type can define it's own move AI settings.", "")]
		public bool useMoveAIRange = true;

		[EditorEndFoldout]
		[EditorCondition("useMoveAIRange", true)]
		[EditorEndCondition]
		public RangeValue moveAIRange = new RangeValue(100.0f);


		// default use range
		[EditorFoldout("Default Use Range", "The default use range settings for using abilities and items.\n" +
			"The use range determines the maximum distance between user and target to allow using an ability or item.\n" +
			"The range can be defined for different battle systems. If no range is defined (or found for the current battle system) " +
			"a 'None' range will be used (i.e. no range limit).\n" +
			"Can be overridden by each ability and item individually as well as the ability/item type of the ability or item.", "")]
		[EditorEndFoldout(2)]
		public UseRangeSettings useRange = new UseRangeSettings();


		// times
		// default cast times
		[EditorFoldout("Time Settings", "Optionally use cast and delay times for battle actions.", "",
			"Cast Time Settings", "You can optionally use cast times for basic commands like defending or escaping.", "",
			"Default Ability Cast Time", "An ability can be casted for a set amount of time before it is used.\n" +
			"This is the default setting for all abilities, each individual ability can override it.\n"+
			"The cast time can be displayed in a HUD (either as a number or a bar).", "")]
		[EditorEndFoldout]
		public CastTimeSettings abilityCastTime = new CastTimeSettings();

		[EditorFoldout("Default Item Cast Time", "An item can be casted for a set amount of time before it is used.\n" +
			"This is the default setting for all items, each individual item can override it.\n"+
			"The cast time can be displayed in a HUD (either as a number or a bar).", "")]
		[EditorEndFoldout]
		public CastTimeSettings itemCastTime = new CastTimeSettings();

		[EditorFoldout("Defend Cast Time", "The defend command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "")]
		[EditorEndFoldout]
		public CastTimeSettings defendCastTime = new CastTimeSettings();

		[EditorFoldout("Escape Cast Time", "The escape command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "")]
		[EditorEndFoldout]
		public CastTimeSettings escapeCastTime = new CastTimeSettings();

		[EditorFoldout("None Cast Time", "The none command (doing nothing) can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "")]
		[EditorEndFoldout]
		public CastTimeSettings noneCastTime = new CastTimeSettings();

		[EditorFoldout("Grid Move Cast Time", "The grid move command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "")]
		[EditorEndFoldout(2)]
		public CastTimeSettings gridMoveCastTime = new CastTimeSettings();

		// default reuse times
		// ability reuse time
		[EditorFoldout("Reuse Time Settings", "You can optionally use reuse times for abilities and items.\n" +
			"An ability/item can be optionally blocked from reuse for a defined amount of turns or time.", "",
			"Default Ability Reuse Time", "An ability can be optionally blocked from reuse for a defined amount of turns or time.\n" +
			"When using a formula to calculate the reuse turns/time, the user of the item is used as user and target of the formula.\n" +
			"The delay time can be overridden by each ability individually.", "")]
		[EditorEndFoldout]
		public ReuseTimeSettings abilityReuseTime = new ReuseTimeSettings();

		// item reuse time
		[EditorFoldout("Default Item Reuse Time", "An item can be optionally blocked from reuse for a defined amount of turns or time.\n" +
			"When using a formula to calculate the reuse turns/time, the user of the item is used as user and target of the formula.\n" +
			"The reuse time can be overridden by each item individually.", "")]
		[EditorEndFoldout(2)]
		public ReuseTimeSettings itemReuseTime = new ReuseTimeSettings();

		// default delay times
		// ability delay time
		[EditorFoldout("Delay Time Settings", "You can optionally use delay times for abilities and items.\n" +
			"The delay time starts running after using an ability or item and prevents the combatant from using any other action.", "",
			"Default Ability Delay Time", "Abilities can set a delay time after being used.\n" +
			"A combatant can't perform actions (e.g. attack, use an ability or item) during the delay time.\n" +
			"When using a formula, the user of the ability is used as both user and target.\n" +
			"The delay time can be overridden by each ability individually.", "")]
		[EditorEndFoldout]
		public DelayTimeSettings abilityDelayTime = new DelayTimeSettings();

		// item delay time
		[EditorFoldout("Default Item Delay Time", "Items can set a delay time after being used.\n" +
			"A combatant can't perform actions (e.g. attack, use an ability or item) during the delay time.\n" +
			"When using a formula, the user of the item is used as both user and target.\n" +
			"The delay time can be overridden by each item individually.", "")]
		[EditorEndFoldout(3)]
		public DelayTimeSettings itemDelayTime = new DelayTimeSettings();


		// battle advantages
		[EditorFoldout("Battle Advantage Settings", "The player or enemies can have the advantage when starting a battle.\n" +
			"Having the advantage can e.g. change status values or status effects, give the group the first turn(s) or a fully filled timebar.", "",
			"Player Advantage", "Battle advantage settings for the player group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "")]
		[EditorEndFoldout]
		public BattleAdvantage playerAdvantage = new BattleAdvantage();

		[EditorFoldout("Enemy Advantage", "Battle advantage settings for the enemy group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "")]
		[EditorEndFoldout(2)]
		public BattleAdvantage enemyAdvantage = new BattleAdvantage();


		// battle statistics
		[EditorFoldout("Combatant Battle Statistics", "Dealing and taking damage can be tracked to be e.g. used in the battle AI or formulas.\n" +
			"Beside tracking the total damage dealt/taken of a combatant, you can also track damage dealt and take from individual combatants.", "")]
		[EditorEndFoldout]
		public BattleStatisticSettings battleStatistics = new BattleStatisticSettings();

		public BattleSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle Settings"; }
		}
	}
}
