
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class DefenceModifiersSettings : GenericAssetListSettings<DefenceModifierAsset, DefenceModifierSetting>
	{
		public DefenceModifiersSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Defence Modifiers"; }
		}
	}
}

