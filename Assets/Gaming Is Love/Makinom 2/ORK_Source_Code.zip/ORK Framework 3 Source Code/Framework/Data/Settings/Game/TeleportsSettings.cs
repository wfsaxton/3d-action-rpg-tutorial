
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class TeleportsSettings : GenericAssetListSettings<TeleportAsset, Teleport>
	{
		public TeleportsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Teleports"; }
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public List<Teleport> GetTeleports(bool ignoreConditions)
		{
			List<Teleport> list = new List<Teleport>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(ignoreConditions || this.assets[i].Settings.Available())
				{
					list.Add(this.assets[i].Settings);
				}
			}
			return list;
		}

		public List<Teleport> GetTeleports(bool checkParent, AreaType type, bool ignoreConditions)
		{
			List<Teleport> list = new List<Teleport>();
			this.GetTeleports(checkParent, type, ignoreConditions, ref list);
			return list;
		}

		public void GetTeleports(bool checkParent, AreaType type, bool ignoreConditions, ref List<Teleport> list)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if((type == null ||
					this.assets[i].Settings.type.Is(type) ||
					(checkParent &&
						this.assets[i].Settings.type.StoredAsset != null &&
						this.assets[i].Settings.type.StoredAsset.Settings.IsSubTypeOf(type))) &&
					(ignoreConditions || this.assets[i].Settings.Available()))
				{
					list.Add(this.assets[i].Settings);
				}
			}
		}

		public List<AreaType> GetAreaTypes(bool ignoreConditions)
		{
			List<AreaType> list = new List<AreaType>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.type.StoredAsset != null &&
					!list.Contains(this.assets[i].Settings.type.StoredAsset.Settings) &&
					(ignoreConditions || this.assets[i].Settings.Available()))
				{
					list.Add(this.assets[i].Settings.type.StoredAsset.Settings);
				}
			}
			return list;
		}

		public List<AreaType> GetAreaTypes(AreaType parentType, bool ignoreConditions)
		{
			List<AreaType> list = new List<AreaType>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.type.StoredAsset != null &&
					(ignoreConditions || this.assets[i].Settings.Available()))
				{
					this.assets[i].Settings.type.StoredAsset.Settings.AddTypeToList(parentType, ref list);
				}
			}
			return list;
		}

		public bool HasAnyAreaType(bool ignoreConditions)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(ignoreConditions || this.assets[i].Settings.Available())
				{
					return true;
				}
			}
			return false;
		}

		public bool HasAreaType(bool checkParent, AreaType type, bool ignoreConditions)
		{
			HashSet<AreaType> types = new HashSet<AreaType>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(ignoreConditions || this.assets[i].Settings.Available())
				{
					if(this.assets[i].Settings.type.Is(type))
					{
						return true;
					}
					else if(checkParent &&
						this.assets[i].Settings.type.StoredAsset != null &&
						!types.Contains(this.assets[i].Settings.type.StoredAsset.Settings))
					{
						if(this.assets[i].Settings.type.StoredAsset.Settings.IsSubTypeOf(type))
						{
							return true;
						}
						else
						{
							types.Add(this.assets[i].Settings.type.StoredAsset.Settings);
						}
					}
				}
			}
			return false;
		}
	}
}

