
using UnityEngine;
using UnityEngine.SceneManagement;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ORKSaveGameSettings : BaseSettings
	{
		// save settings
		[EditorHelp("Statistics", "Game statistics will be saved.", "")]
		[EditorFoldout("ORK Save Settings", "Select the data of a running game that will be saved in a save game.", "")]
		[EditorTitleLabel("Game Data")]
		[EditorLabel("ORK Framework will handle saving/loading the player position.\n" +
			"Makinom's player position save settings will not be used.")]
		public bool saveStatistics = true;

		[EditorHelp("Groups", "The player groups (i.e. all combatants and their current levels, equipment, etc.) will be saved.", "")]
		public bool saveGroups = true;

		[EditorHelp("Factions", "The factions (i.e. the sympathy values.) will be saved.", "")]
		public bool saveFactions = true;

		[EditorHelp("Logs", "The learned logs will be saved.", "")]
		public bool saveLogs = true;

		[EditorHelp("Quests", "The learned/finished quests will be saved.", "")]
		public bool saveQuests = true;

		[EditorHelp("Bestiary", "The learned enemy combatant information will be saved.", "")]
		public bool saveBestiary = true;

		[EditorHelp("Battle Gains", "The uncollected battle gains will be saved.", "")]
		public bool saveBattleGains = true;

		[EditorHelp("Max Battle Group/Reserve", "The maximum battle group/reserve size of player groups will be saved.", "")]
		public bool savePlayerMaxBattleGroupSize = true;

		[EditorHelp("Group Positions", "The position of all group members will be saved.", "")]
		[EditorCondition("saveGroups", true)]
		public bool saveGroupPosition = true;

		[EditorHelp("Camera Position", "The position of the camera will be saved.", "")]
		[EditorCondition("saveGroupPosition", true)]
		public bool saveCameraPosition = true;

		[EditorHelp("Music", "Save the currently playing music and playing time.", "")]
		public bool saveMusic = true;

		[EditorHelp("Load Scene", "The scene that will be loaded when loading a game without group positions.", "")]
		[EditorWidth(true)]
		[EditorElseCondition]
		public string saveSceneName = "";

		[EditorHelp("Spawn ID", "The spawn point ID where the group (if saved) will spawn.", "")]
		[EditorEndCondition(2)]
		public int saveSpawnID = 0;

		[EditorHelp("Block States", "The state of blocked control maps will be saved.", "")]
		public bool saveBlockStates = false;

		// scene data
		[EditorHelp("Save Item Boxes", "Select how the content of item boxes will be saved (using the box ID of item collectors):\n" +
			"- None: The content won't be saved, i.e. boxes will fill again when reentering a scene.\n" +
			"- Game: The content will be remebered in a running game.\n" +
			"- Save: The content will be saved in a save game.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Scene Data")]
		public SaveOption boxSaveOption = SaveOption.Save;

		[EditorHelp("Save Items", "Select how collected items will be saved (using the scene ID of item collectors):\n" +
			"- None: Collected items won't be saved, i.e. they will reappear when reentering a scene.\n" +
			"- Game: Collected items will be remebered in a running game.\n" +
			"- Save: Collected items will be saved in a save game.", "")]
		public SaveOption itemSaveOption = SaveOption.Save;

		[EditorHelp("Auto Remove", "Auto remove collected item data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[EditorIndent]
		[EditorCondition("itemSaveOption", SaveOption.None)]
		[EditorElseCondition]
		[EditorDefaultValue(false)]
		public bool itemAutoRemove = false;

		[EditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("itemAutoRemove", true)]
		[EditorEndCondition(2)]
		public int itemAutoRemoveAfter = 3;

		[EditorHelp("Save Drops", "Select how the item drops will be saved:\n" +
			"- None: Drops won't be saved, i.e. they will be gone when reentering a scene.\n" +
			"- Game: Drops will be remebered in a running game.\n" +
			"- Save: Drops will be saved in a save game.", "")]
		public SaveOption dropSaveOption = SaveOption.None;

		[EditorHelp("Auto Remove", "Auto remove item drop data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[EditorIndent]
		[EditorCondition("dropSaveOption", SaveOption.None)]
		[EditorElseCondition]
		[EditorDefaultValue(false)]
		public bool dropAutoRemove = false;

		[EditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("dropAutoRemove", true)]
		[EditorEndCondition(2)]
		public int dropAutoRemoveAfter = 3;

		[EditorHelp("Save Battles", "Select how the battles using a scene ID will be saved:\n" +
			"- None: Finished battles won't be saved, i.e. they will reappear when reentering a scene.\n" +
			"- Game: Finished battles will be remebered in a running game.\n" +
			"- Save: Finished battles will be saved in a save game.", "")]
		public SaveOption battlesSaveOption = SaveOption.Save;

		[EditorHelp("Auto Remove", "Auto remove finished battle data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[EditorIndent]
		[EditorCondition("battlesSaveOption", SaveOption.None)]
		[EditorElseCondition]
		[EditorDefaultValue(false)]
		public bool battleAutoRemove = false;

		[EditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("battleAutoRemove", true)]
		[EditorEndCondition(2)]
		public int battleAutoRemoveAfter = 3;

		[EditorHelp("Save Shops", "Select how the content of shops will be saved (using the shop ID):\n" +
			"- None: The content won't be saved, i.e. shops will reset again when opening them.\n" +
			"- Game: The content will be remebered in a running game.\n" +
			"- Save: The content will be saved in a save game.", "")]
		public SaveOption shopsSaveOption = SaveOption.Save;

		[EditorHelp("Object Variables", "Select how variables bound to objects will be saved:\n" +
			"- None: The variables won't be saved, i.e. they won't be used at all.\n" +
			"- Game: The variables will be remebered in a running game.\n" +
			"- Save: The variables will be saved in a save game.", "")]
		public SaveOption objectVariableOption = SaveOption.Save;

		// spawned combatants
		[EditorHelp("Spawned Combatants", "Select if data of spawned combatants when using " +
			"'Remember Combatants' in 'Combatant Spawner' and 'Add Combatant' components will be saved:\n" +
			"- None: Spawned combatants aren't saved.\n" +
			"- Current: Only combatants spawned in the current scene are saved.\n" +
			"- All: All stored combatants will be saved (this can massively increase the save file).", "")]
		public SceneSaveOption saveSpawnedCombatants = SceneSaveOption.None;

		[EditorHelp("Auto Remove", "Auto remove spawned combatant data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[EditorIndent]
		public bool combatantAutoRemove = false;

		[EditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("combatantAutoRemove", true)]
		[EditorEndCondition]
		public int combatantAutoRemoveAfter = 3;

		// inventory
		[EditorHelp("Items", "All items in the inventory will be saved.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Inventory Data")]
		public bool saveItems = true;

		[EditorHelp("Equipment", "All equipment in the inventory will be saved.\n" +
			"Equipped equipment will only be saved if the party is saved.", "")]
		public bool saveEquipment = true;

		[EditorHelp("Recipes", "All learned crafting recipes will be saved", "")]
		public bool saveRecipes = true;

		[EditorHelp("Currency", "The current amount of currency will be saved.", "")]
		public bool saveCurrency = true;

		[EditorHelp("AI Behaviours", "The currently collected and equipped AI behaviours and AI behaviour slots will be saved.", "")]
		public bool aiBehaviours = true;

		[EditorHelp("AI Rulesets", "The currently collected and equipped AI rulesets and AI ruleset slots will be saved.", "")]
		[EditorEndFoldout]
		public bool aiRulesets = true;


		// player prefs game options
		[EditorHide]
		public ORKPlayerPrefsGameOptions playerPrefsGameOptions = new ORKPlayerPrefsGameOptions();

		public ORKSaveGameSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.ContainsArray<string>("noAutoRemoveScene"))
			{
				data.Get("noAutoRemoveScene", out Maki.SaveGameSettings.noAutoRemoveScene);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "ORK Save Settings"; }
		}
	}
}
