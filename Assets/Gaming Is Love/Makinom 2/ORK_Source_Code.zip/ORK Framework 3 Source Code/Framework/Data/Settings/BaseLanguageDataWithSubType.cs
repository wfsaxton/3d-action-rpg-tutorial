﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public abstract class BaseLanguageDataWithSubType<T, V> : BaseLanguageDataWithType<T, V>
		where T : MakinomGenericAsset<V>
		where V : BaseSubTypeData<T, V>, new()
	{
		public BaseLanguageDataWithSubType()
		{

		}

		public BaseLanguageDataWithSubType(string name) : base(name)
		{

		}

		public virtual bool IsType(V type, bool checkParent)
		{
			V tmpType = this.TypeData;
			return tmpType != null &&
				tmpType.IsType(type, checkParent);
		}

		public virtual void GetType(List<V> addToList)
		{
			V tmpType = this.TypeData;
			if(tmpType != null &&
				!addToList.Contains(tmpType))
			{
				addToList.Add(tmpType);
			}
		}
	}
}
