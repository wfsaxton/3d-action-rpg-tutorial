
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class QuestTasksSettings : GenericAssetListSettings<QuestTaskAsset, QuestTaskSetting>
	{
		public QuestTasksSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Quest Tasks"; }
		}


		/*
		============================================================================
		Task functions
		============================================================================
		*/
		public List<QuestTaskSetting> GetQuestTasks(QuestSetting quest)
		{
			List<QuestTaskSetting> list = new List<QuestTaskSetting>();

			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.TypeData == quest)
				{
					list.Add(this.assets[i].Settings);
				}
			}

			return list;
		}
	}
}
