﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public static class GUIDHelper
	{
		/// <summary>
		/// Creates a new GUID string.
		/// The string is formatted in 32 digits, e.g. '00000000000000000000000000000000'.
		/// </summary>
		/// <returns>The new, unused GUID string.</returns>
		public static string CreateGUID()
		{
			return System.Guid.NewGuid().ToString("N");
		}
	}
}
