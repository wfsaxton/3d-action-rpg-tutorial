
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.Animations;
using UnityEngine.AI;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Player Control/Button Controller")]
	public class ButtonPlayerController : BasePlayerControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public ButtonPlayerControlSettings settings = new ButtonPlayerControlSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected Vector3 moveDirection = Vector3.zero;

		protected float verticalSpeed = 0.0f;

		protected float moveSpeed = 0.0f;

		protected float lastMoveSpeed = 0.0f;

		protected Combatant combatant = null;

		protected CharacterController controller = null;

		protected NavMeshAgent navMeshAgent = null;

		protected Vector3 targetDirection = Vector3.zero;

		protected bool isJumping = false;

		protected bool isFalling = false;

		protected float fallTime = 0;

		protected float currentSprintEnergy = 0;

		protected float currentMaxSprintEnergy = 0;

		protected StatusValue sprintEnergyStatusValue;

		// root motion
		protected Animator animatorComponent;

		protected MecanimFloatParameterSetter parameterForwardSpeed;

		protected MecanimFloatParameterSetter parameterVerticalSpeed;

		protected int hashGrounded = 0;

		protected virtual void Start()
		{
			this.moveDirection = this.transform.TransformDirection(Vector3.forward);

			this.combatant = ORKComponentHelper.GetCombatant(this.transform.root.gameObject);
			if(this.combatant != null &&
				this.settings.useSprint &&
				this.settings.useEnergy)
			{
				if(this.settings.energyUseStatusValue)
				{
					if(this.settings.energyStatusValue.StoredAsset != null)
					{
						this.sprintEnergyStatusValue = this.combatant.Status.Get(this.settings.energyStatusValue.StoredAsset.Settings);
					}
					this.currentSprintEnergy = 0;
				}
				else
				{
					this.currentMaxSprintEnergy = this.settings.maxEnergy.GetValue(this.combatant.Call);
					this.currentSprintEnergy = this.currentMaxSprintEnergy;
				}
			}
		}

		protected int InputID
		{
			get { return this.combatant != null ? this.combatant.InputID : Maki.Control.InputID; }
		}

		protected virtual void OnEnable()
		{
			if(ButtonControlMoveType.CharacterController == this.settings.moveType ||
				ButtonControlMoveType.AnimatorRootMotion == this.settings.moveType)
			{
				if(this.navMeshAgent != null)
				{
					this.navMeshAgent.updatePosition = false;
					this.navMeshAgent.updateRotation = false;
				}
			}
		}

		protected virtual void OnDisable()
		{
			if(ButtonControlMoveType.CharacterController == this.settings.moveType)
			{
				if(this.navMeshAgent != null)
				{
					if(this.navMeshAgent.enabled)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
					this.navMeshAgent.updatePosition = true;
					this.navMeshAgent.updateRotation = true;
				}
			}
			else if(ButtonControlMoveType.CombatantMovementComponent == this.settings.moveType)
			{
				if(this.combatant != null &&
					this.combatant.Object.MovementComponent != null)
				{
					this.combatant.Object.MovementComponent.Stop();
				}
			}
			else if(ButtonControlMoveType.AnimatorRootMotion == this.settings.moveType)
			{
				if(this.animatorComponent != null)
				{
					if(this.settings.forwardSpeedParameter != "")
					{
						this.animatorComponent.SetFloat(this.parameterForwardSpeed.hash, 0);
					}
					if(this.settings.verticalSpeedParameter != "")
					{
						this.animatorComponent.SetFloat(this.parameterVerticalSpeed.hash, 0);
					}
					if(this.settings.groundedParameter != "")
					{
						this.animatorComponent.SetBool(this.hashGrounded, true);
					}
				}
				if(this.navMeshAgent != null)
				{
					if(this.navMeshAgent.enabled)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
					this.navMeshAgent.updatePosition = true;
					this.navMeshAgent.updateRotation = true;
				}
			}
			this.verticalSpeed = 0.0f;
			this.moveSpeed = 0.0f;
			this.lastMoveSpeed = 0.0f;
		}

		protected virtual void Update()
		{
			float t = ORK.Game.DeltaMovementTime;

			if(ButtonControlMoveType.CharacterController == this.settings.moveType)
			{
				if(this.controller == null)
				{
					this.controller = this.GetComponent<CharacterController>();
					if(this.controller == null)
					{
						this.controller = this.gameObject.AddComponent<CharacterController>();
					}

					this.navMeshAgent = this.GetComponent<NavMeshAgent>();
					if(this.navMeshAgent != null)
					{
						this.navMeshAgent.updatePosition = false;
						this.navMeshAgent.updateRotation = false;
					}
				}
			}
			else if(ButtonControlMoveType.NavMeshAgent == this.settings.moveType)
			{
				if(this.navMeshAgent == null)
				{
					this.navMeshAgent = this.GetComponent<NavMeshAgent>();
					if(this.navMeshAgent == null)
					{
						this.navMeshAgent = this.gameObject.AddComponent<NavMeshAgent>();
					}
					if(this.navMeshAgent != null &&
						!this.navMeshAgent.isOnNavMesh)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
				}
			}
			else if(ButtonControlMoveType.AnimatorRootMotion == this.settings.moveType)
			{
				if(this.animatorComponent == null)
				{
					this.animatorComponent = this.GetComponent<Animator>();
					if(this.settings.forwardSpeedParameter != "")
					{
						this.parameterForwardSpeed = new MecanimFloatParameterSetter(this.settings.forwardSpeedParameter, this.settings.dampForwardSpeedParameter);
					}
					if(this.settings.verticalSpeedParameter != "")
					{
						this.parameterVerticalSpeed = new MecanimFloatParameterSetter(this.settings.verticalSpeedParameter, this.settings.dampVerticalSpeedParameter);
					}
					if(this.settings.groundedParameter != "")
					{
						this.hashGrounded = Animator.StringToHash(this.settings.groundedParameter);
					}

					if(this.settings.rootMotionSetControllerGravity)
					{
						this.controller = this.GetComponent<CharacterController>();
					}

					this.navMeshAgent = this.GetComponent<NavMeshAgent>();
					if(this.navMeshAgent != null)
					{
						this.navMeshAgent.updatePosition = false;
						this.navMeshAgent.updateRotation = false;
					}
				}
			}

			bool isGrounded = this.combatant != null && this.combatant.Object.Component != null ?
				!this.combatant.Object.Component.InAir :
				(this.controller != null ? this.controller.isGrounded : true);
			this.UpdateSmoothedMovementDirection(isGrounded);
			this.ApplyGravity(isGrounded);

			if(ButtonControlMoveType.AnimatorRootMotion == this.settings.moveType)
			{
				if(this.animatorComponent != null)
				{
					if(this.settings.forwardSpeedParameter != "")
					{
						this.parameterForwardSpeed.Set(this.animatorComponent, this.moveSpeed);
					}
					if(this.settings.verticalSpeedParameter != "")
					{
						this.parameterVerticalSpeed.Set(this.animatorComponent, this.verticalSpeed);
					}
					if(this.settings.groundedParameter != "")
					{
						this.animatorComponent.SetBool(this.hashGrounded, isGrounded && !this.isJumping);
					}
				}
				if(this.settings.rootMotionSetControllerGravity &&
					this.controller != null)
				{
					this.controller.Move(new Vector3(0, this.verticalSpeed, 0) * t);
				}
				if(this.navMeshAgent != null &&
					this.navMeshAgent.enabled)
				{
					if(Vector3.Distance(this.navMeshAgent.nextPosition, this.transform.position) > 0.1f)
					{
						this.navMeshAgent.Warp(this.transform.position);
					}
					else
					{
						this.navMeshAgent.nextPosition = this.transform.position;
					}
				}
			}
			else
			{
				Vector3 movement = Vector3.zero;
				if(!(this.lastMoveSpeed == 0 && this.moveSpeed == 0))
				{
					// Calculate actual motion
					if(this.settings.firstPerson)
					{
						movement = this.targetDirection * this.moveSpeed + new Vector3(0, this.verticalSpeed, 0);
					}
					else
					{
						movement = this.moveDirection * this.moveSpeed + new Vector3(0, this.verticalSpeed, 0);
					}
					movement *= t;
				}
				else
				{
					movement = new Vector3(0, this.verticalSpeed, 0) * t;
				}

				if(ButtonControlMoveType.CharacterController == this.settings.moveType)
				{
					this.controller.Move(movement);
				}
				else if(ButtonControlMoveType.NavMeshAgent == this.settings.moveType)
				{
					this.navMeshAgent.Move(movement);
				}
				else if(ButtonControlMoveType.CombatantMovementComponent == this.settings.moveType)
				{
					if(this.combatant != null &&
						this.combatant.Object.MovementComponent != null)
					{
						this.combatant.Object.MovementComponent.Move(movement);
					}
				}
			}

			this.lastMoveSpeed = this.moveSpeed;

			if(!this.settings.firstPerson && this.settings.useCamDirection)
			{
				this.transform.rotation = Quaternion.LookRotation(this.moveDirection);
			}
		}

		protected virtual void UpdateSmoothedMovementDirection(bool isGrounded)
		{
			float t = ORK.Game.DeltaMovementTime;

			Transform view = Maki.Game.Camera != null ? Maki.Game.Camera.transform : this.transform;
			if(!this.settings.useCamDirection)
			{
				view = this.transform;
			}

			Vector2 input = Vector2.zero;
			float speedMod = 1;
			float inputMagnitude = 0;

			float runSpeed = ORK.GameControls.playerControl.runSpeed;
			if(this.combatant == null ||
				((ORK.GameControls.playerControl.moveDead || !this.combatant.Status.IsDead) &&
				!this.combatant.Status.Effects.StopMovement))
			{
				int inputID = this.InputID;
				input.y = InputKey.GetAxis(this.settings.verticalAxis, inputID);
				input.x = InputKey.GetAxis(this.settings.horizontalAxis, inputID);
				inputMagnitude = input.magnitude;

				if(this.combatant != null)
				{
					if(this.settings.use2WaySpeed)
					{
						if(inputMagnitude < this.settings.inputValue2WaySpeed)
						{
							runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Walk);
						}
						else
						{
							runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Run);
						}
					}
					else if(ORK.GameControls.playerControl.useSpeed)
					{
						runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Run);
					}
				}

				if(this.combatant != null)
				{
					// fall/land animations
					if(this.isFalling)
					{
						this.fallTime += Time.deltaTime;
						if(isGrounded)
						{
							if(this.settings.playLandAnimation &&
								this.fallTime >= this.settings.minFallTime)
							{
								this.combatant.Animations.Play(ORK.AnimationTypes.land);
							}
							else if(this.settings.playFallAnimation)
							{
								this.combatant.Animations.Stop(ORK.AnimationTypes.fall);
							}
							this.isFalling = false;
						}
					}
					else if(!isGrounded &&
						this.combatant.Object.Component.VerticalSpeed < 0)
					{
						if(this.settings.playFallAnimation)
						{
							this.combatant.Animations.Play(ORK.AnimationTypes.fall);
						}
						this.fallTime = 0;
						this.isFalling = true;
					}

					// sprint
					if(this.settings.useSprint && isGrounded &&
						InputKey.GetButton(this.settings.sprintKey.StoredAsset, inputID) &&
						input != Vector2.zero)
					{
						if(this.EnergyHandling(true))
						{
							speedMod = this.settings.sprintFactor;
						}
					}
					else
					{
						this.EnergyHandling(false);
					}
				}
			}

			// Target direction relative to the camera
			if(this.settings.useCamDirection || this.settings.firstPerson)
			{
				this.targetDirection = InputHelper.GetDirectionJoystick(input.x, input.y, view,
					HorizontalPlaneType.XZ, this.settings.camDirectionOffset);
			}
			else if(!this.settings.useCamDirection)
			{
				this.transform.Rotate(Vector3.up * input.x * this.settings.rotateSpeed * t);
				this.targetDirection = input.y * this.transform.TransformDirection(Vector3.forward);
			}

			if(!isGrounded)
			{
				this.targetDirection *= this.settings.inAirModifier;
			}

			// We store speed and direction seperately,
			// so that when the character stands still we still have a valid forward direction
			// moveDirection is always normalized, and we only update it if there is user input.
			if(this.targetDirection != Vector3.zero)
			{
				if(this.settings.firstPerson && this.settings.useCamDirection)
				{
					this.transform.eulerAngles = new Vector3(0, Quaternion.LookRotation(view.forward).eulerAngles.y, 0);
				}
				// If we are really slow, just snap to the target direction
				else if(this.moveSpeed < (runSpeed / 2) * 0.9f)
				{
					this.moveDirection = this.targetDirection.normalized;
				}
				else if(!this.settings.firstPerson)
				{
					this.moveDirection = Vector3.RotateTowards(this.moveDirection, this.targetDirection,
						this.settings.rotateSpeed * Mathf.Deg2Rad * t, 1000).normalized;
				}
			}
			else
			{
				this.moveDirection = this.transform.TransformDirection(Vector3.forward);
			}

			// Choose target speed
			//* We want to support analog input but make sure you cant walk faster diagonally than just forward or sideways
			float targetSpeed = Mathf.Min(this.targetDirection.magnitude, 1.0f);
			if(targetSpeed < 0.2)
				targetSpeed = 0;
			targetSpeed = this.settings.use2WaySpeed ?
				targetSpeed * runSpeed * speedMod :
				targetSpeed * runSpeed * speedMod * Mathf.Min(inputMagnitude, 1.0f);
			this.moveSpeed = ORK.GameControls.playerControl.speedSmoothing > 0 ?
				Mathf.Lerp(this.moveSpeed, targetSpeed, ORK.GameControls.playerControl.speedSmoothing * t) :
				targetSpeed;
		}

		protected virtual void ApplyGravity(bool isGrounded)
		{
			bool jumpInput = this.settings.useJump &&
				InputKey.GetButton(this.settings.jumpKey.StoredAsset, this.InputID);

			if(!jumpInput && isGrounded)
			{
				this.isJumping = false;
			}

			if(isGrounded)
			{
				if(!this.isJumping)
				{
					this.verticalSpeed = ORK.GameControls.playerControl.gravity;

					if(jumpInput)
					{
						RaycastOutput hit;
						if(RaycastHelper.Raycast(this.transform.position, -Vector3.up, out hit))
						{
							if(Vector3.Angle(Vector3.up, hit.normal) < this.settings.jumpMaxGroundAngle)
							{
								this.verticalSpeed = this.settings.jumpSpeed;
								this.isJumping = true;
							}
						}
					}
				}
			}
			else
			{
				// decelerate when not holding jump
				if(!jumpInput && this.verticalSpeed > 0.0f)
				{
					this.verticalSpeed -= this.settings.jumpDeceleration * Time.deltaTime;
				}
				// nearing peak
				if(Mathf.Approximately(this.verticalSpeed, 0f))
				{
					this.verticalSpeed = 0f;
				}

				this.verticalSpeed -= this.settings.jumpGravity * Time.deltaTime;
			}
		}

		protected virtual bool EnergyHandling(bool use)
		{
			bool ok = true;
			if(this.settings.useSprint &&
				this.settings.useEnergy &&
				this.moveSpeed > 0)
			{
				DataCall call = this.combatant.Call;
				float delta = ORK.Game.DeltaMovementTime;

				if(this.settings.energyUseStatusValue)
				{
					if(use &&
						this.sprintEnergyStatusValue != null)
					{
						float tmp = this.settings.energyConsume.GetValue(call) * delta;
						if(this.currentSprintEnergy + tmp > this.sprintEnergyStatusValue.GetValue())
						{
							ok = false;
						}
						else
						{
							this.currentSprintEnergy += tmp;
							if(this.currentSprintEnergy >= 1)
							{
								int change = (int)this.currentSprintEnergy;
								this.sprintEnergyStatusValue.AddValueAccess(-change, false, false, false, false, false, false, false, null);
								this.currentSprintEnergy -= change;
							}
						}
					}
				}
				else
				{
					// set max
					this.currentMaxSprintEnergy = this.settings.maxEnergy.GetValue(call);
					// regenerate
					this.currentSprintEnergy += this.settings.energyRegeneration.GetValue(call) * delta;
					// use
					if(use)
					{
						float tmp = this.settings.energyConsume.GetValue(call) * delta;
						if(tmp > this.currentSprintEnergy)
						{
							ok = false;
						}
						else
						{
							this.currentSprintEnergy -= tmp;
						}
					}
					// max bounds
					if(this.currentSprintEnergy < 0)
					{
						this.currentSprintEnergy = 0;
					}
					else if(this.currentSprintEnergy > this.currentMaxSprintEnergy)
					{
						this.currentSprintEnergy = this.currentMaxSprintEnergy;
					}
				}
			}
			return ok;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
