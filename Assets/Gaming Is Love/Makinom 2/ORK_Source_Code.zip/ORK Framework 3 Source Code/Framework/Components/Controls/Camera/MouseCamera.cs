
using GamingIsLove.ORKFramework;
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/Mouse Camera")]
	public class MouseCamera : BaseCameraControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public MouseCameraSettings settings = new MouseCameraSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// in-game
		protected bool initialized = false;

		protected float startHeight = 5.0f;

		protected float startRotation = 0;

		protected float lastTargetRotation = 0;

		protected float lastTargetHeight = 0;

		// non-input
		private Vector3 lastPosition = Vector3.zero;

		private Vector3 lastChange = Vector3.zero;

		public override bool UseUnscaledTime
		{
			get { return this.settings.useUnscaledTime; }
		}

		protected virtual void Start()
		{
			this.lastTargetRotation = this.transform.eulerAngles.y;
			this.lastTargetHeight = this.transform.position.y;
			this.startRotation = this.settings.rotation;
			this.startHeight = this.settings.height;

			if(this.settings.rememberRotation &&
				this.AllowRotation &&
				(this.settings.rememberRotationBattle || !ORK.Control.InBattle))
			{
				ORK.GameControls.cameraControl.mouseControl.GetStoredRotation(
					ref this.settings.rotation, ref this.lastTargetRotation);
			}
			if(this.settings.rememberZoom &&
				this.AllowZoom &&
				(this.settings.rememberZoomBattle || !ORK.Control.InBattle))
			{
				ORK.GameControls.cameraControl.mouseControl.GetStoredZoom(
					ref this.settings.height, ref this.lastTargetRotation);
			}
			this.initialized = true;
		}

		protected virtual void OnEnable()
		{
			this.lastPosition = Input.mousePosition;
			this.lastChange = Vector3.zero;
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				if(this.settings.rememberRotation &&
					this.AllowRotation &&
					(this.settings.rememberRotationBattle || !ORK.Control.InBattle))
				{
					ORK.GameControls.cameraControl.mouseControl.StoreRotation(
						this.settings.rotation, this.lastTargetRotation);
				}
				if(this.settings.rememberZoom &&
					this.AllowZoom &&
					(this.settings.rememberZoomBattle || !ORK.Control.InBattle))
				{
					ORK.GameControls.cameraControl.mouseControl.StoreZoom(
						this.settings.height, this.lastTargetRotation);
				}
			}
		}

		public override void CameraTargetChanged(GameObject oldTarget, GameObject newTarget)
		{
			if(this.settings.cameraTargetChangeResetRotation)
			{
				this.ResetRotation();
			}
			if(this.settings.cameraTargetChangeResetZoom)
			{
				this.ResetZoom();
			}
		}

		public virtual void ResetRotation()
		{
			this.settings.rotation = this.startRotation;
		}

		public virtual void ResetZoom()
		{
			this.settings.height = this.startHeight;
		}

		protected virtual bool AllowZoom
		{
			get
			{
				return this.settings.allowZoom &&
					(!this.settings.cameraTargetChangeBlockZoom ||
						!this.IsCameraTargetTransition);
			}
		}

		protected virtual bool AllowRotation
		{
			get
			{
				return this.settings.allowRotation &&
					(!this.settings.cameraTargetChangeBlockRotation ||
						!this.IsCameraTargetTransition);
			}
		}

		protected virtual void LateUpdate()
		{
			GameObject targetObject = this.settings.childObject.GetChild(this.CameraTarget);
			if(targetObject != null)
			{
				Vector3 add = Vector3.zero;
				if((this.AllowRotation || this.AllowZoom) &&
					(!this.settings.useInput ||
						this.settings.mouseTouch.Interacted(ref add)))
				{
					add = this.settings.useInput ?
						this.settings.mouseTouch.GetLastChange() :
						this.lastChange;

					if(this.AllowRotation &&
						this.AllowZoom &&
						this.settings.limitChange)
					{
						if(Mathf.Abs(add.x) >= Mathf.Abs(add.y))
						{
							add.y = 0;
						}
						else
						{
							add.x = 0;
						}
					}

					if(this.AllowRotation)
					{
						this.settings.rotation += add.x * this.settings.rotationFactor;
					}
					if(this.AllowZoom)
					{
						this.settings.height += add.y * this.settings.zoomFactor;
					}

					if(this.settings.rotation < -36000)
					{
						int change = (this.settings.rotation > -36000 ?
							1 : (int)(-this.settings.rotation / 36000)) * 36000;
						this.settings.rotation += change;
						this.lastTargetRotation += change;
					}
					else if(this.settings.rotation >= 36000)
					{
						int change = ((int)(this.settings.rotation / 36000)) * 36000;
						this.settings.rotation -= change;
						this.lastTargetRotation -= change;
					}
				}

				if(!this.settings.useInput)
				{
					this.lastChange = Input.mousePosition - this.lastPosition;
					this.lastPosition = Input.mousePosition;
				}

				if(this.AllowZoom)
				{
					this.settings.height += this.settings.zoomAxis.GetAxis(true) * this.settings.zoomKeyChange;
				}

				if(this.settings.height < this.settings.minHeight)
				{
					this.settings.height = this.settings.minHeight;
				}
				else if(this.settings.height > this.settings.maxHeight)
				{
					this.settings.height = this.settings.maxHeight;
				}

				float wantedHeight = targetObject.transform.position.y + this.settings.height;
				if(this.settings.heightDamping > 0)
				{
					this.lastTargetHeight = Mathf.Lerp(this.lastTargetHeight, wantedHeight,
						this.settings.heightDamping * this.DeltaTime);
				}
				else
				{
					this.lastTargetHeight = wantedHeight;
				}

				Vector3 position = targetObject.transform.position - Vector3.forward * this.settings.distance;
				position.y = this.lastTargetHeight;

				float targetRotation = this.settings.rotation;
				if(this.settings.rotationDamping > 0)
				{
					targetRotation = Mathf.Lerp(this.lastTargetRotation, this.settings.rotation,
						this.settings.rotationDamping * this.DeltaTime);
				}
				this.lastTargetRotation = targetRotation;

				position = VectorHelper.RotateAround(
					position, targetObject.transform.position,
					Quaternion.Euler(0, targetRotation, 0));

				this.UpdatePosition(position,
					VectorHelper.LookAt(position, targetObject.transform.position));
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
