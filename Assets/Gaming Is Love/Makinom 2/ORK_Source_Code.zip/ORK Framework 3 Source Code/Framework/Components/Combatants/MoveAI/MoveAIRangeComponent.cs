﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Move AI/Move AI Range")]
	public class MoveAIRangeComponent : BaseColliderZone
	{
		[Tooltip("Limit the random patrol of the combatant to within this game object's trigger (collider with 'Is Trigger' enabled).\n" +
			"The 'Move AI Range' component has to be selected by the combatant's setup in a 'Combatant Spawner' or 'Add Combatant' component.")]
		public bool limitRandomPatrol = true;

		[Tooltip("Limit the move range of the combatant to within this game object's trigger (collider with 'Is Trigger' enabled).\n" +
			"The 'Move AI Range' component has to be selected by the combatant's setup in a 'Combatant Spawner' or 'Add Combatant' component.")]
		public bool limitMoveRange = true;


		// in-game
		protected HashSet<Combatant> combatants = new HashSet<Combatant>();

		public virtual bool Contains(Combatant combatant)
		{
			return this.combatants.Contains(combatant);
		}


		/*
		============================================================================
		3D trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			if(this.limitMoveRange &&
				other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Add(combatant);
				}
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(this.limitMoveRange &&
				other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Remove(combatant);
				}
			}
		}


		/*
		============================================================================
		2D trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(this.limitMoveRange &&
				other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Add(combatant);
				}
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(this.limitMoveRange &&
				other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Remove(combatant);
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/MoveAIRangeComponent Icon.png");
		}
	}
}
