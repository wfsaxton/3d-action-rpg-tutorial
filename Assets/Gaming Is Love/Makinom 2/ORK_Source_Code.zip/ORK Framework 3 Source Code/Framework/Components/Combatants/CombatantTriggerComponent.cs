﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Combatant Trigger")]
	public class CombatantTriggerComponent : SerializedBehaviour<CombatantTriggerComponent.Settings>
	{
		// in-game
		protected Combatant owner;

		protected List<Combatant> registered = new List<Combatant>();

		protected Dictionary<Combatant, float> combatants = new Dictionary<Combatant, float>();

		protected virtual void Update()
		{
			float delta = ORK.Game.DeltaBattleTime;

			for(int i = 0; i < this.registered.Count; i++)
			{
				this.combatants[this.registered[i]] += delta;
			}
		}

		protected virtual void OnDisable()
		{
			this.registered.Clear();
			this.combatants.Clear();
		}

		public virtual Combatant Owner
		{
			get { return this.owner; }
			set
			{
				if(this.owner != value)
				{
					this.owner = value;
					this.RemoveCombatant(this.owner);
				}
			}
		}

		public virtual List<Combatant> InTrigger
		{
			get { return this.registered; }
		}

		public virtual bool IsActive
		{
			get { return this.enabled && this.gameObject.activeInHierarchy; }
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		protected virtual void AddCombatant(Combatant combatant)
		{
			if(combatant != null &&
				this.owner != combatant &&
				!this.combatants.ContainsKey(combatant))
			{
				this.registered.Add(combatant);
				this.combatants.Add(combatant, 0);
			}
		}

		protected virtual void RemoveCombatant(Combatant combatant)
		{
			if(combatant != null &&
				this.combatants.ContainsKey(combatant))
			{
				this.registered.Remove(combatant);
				this.combatants.Remove(combatant);
			}
		}

		public virtual bool Contains(Combatant combatant)
		{
			return combatant != null &&
				this.combatants.ContainsKey(combatant);
		}

		public virtual float GetTime(Combatant combatant)
		{
			if(combatant != null &&
				this.combatants.ContainsKey(combatant))
			{
				return this.combatants[combatant];
			}
			return -1;
		}

		public virtual void GetInTrigger(ref List<Combatant> list)
		{
			foreach(KeyValuePair<Combatant, float> pair in this.combatants)
			{
				if(!list.Contains(pair.Key))
				{
					list.Add(pair.Key);
				}
			}
		}

		public virtual void GetInTrigger(ref List<Combatant> list,
			float checkFor, float checkFor2, ValueCheckType check)
		{
			foreach(KeyValuePair<Combatant, float> pair in this.combatants)
			{
				if(ValueHelper.CheckValue(pair.Value, checkFor, checkFor2, check) &&
					!list.Contains(pair.Key))
				{
					list.Add(pair.Key);
				}
			}
		}


		/*
		============================================================================
		Tag functions
		============================================================================
		*/
		public virtual bool CheckTag(string tag)
		{
			for(int i = 0; i < this.settings.tags.Length; i++)
			{
				if(this.settings.tags[i] == tag)
				{
					return true;
				}
			}
			return false;
		}

		public virtual bool CheckTags(string[] checkTags, Needed needed)
		{
			if(checkTags.Length > 0)
			{
				for(int i = 0; i < checkTags.Length; i++)
				{
					if(this.CheckTag(checkTags[i]))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			this.AddCombatant(ORKComponentHelper.GetCombatant(other.gameObject));
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			this.RemoveCombatant(ORKComponentHelper.GetCombatant(other.gameObject));
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			this.AddCombatant(ORKComponentHelper.GetCombatant(other.gameObject));
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			this.RemoveCombatant(ORKComponentHelper.GetCombatant(other.gameObject));
		}


		/*
		============================================================================
		Settings
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Tag", "The tag used by the trigger.\n" +
				"You can find combatants within this trigger using this tag.")]
			[EditorWidth(true, hideName=true)]
			[EditorArray("Add Tag", "Adds a tag to this combatant trigger.", "",
				"Remove", "Removes this tag", "", isHorizontal=true)]
			public string[] tags = new string[0];

			public Settings()
			{

			}
		}
	}
}
