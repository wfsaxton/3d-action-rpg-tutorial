
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Real Time Battle Area")]
	public class RealTimeBattleArea : BaseConditionComponent
	{
		// ingame
		protected bool counted = false;

		protected bool doStart = false;

		protected bool doEnd = false;


		// collider
		protected Collider colliderComponent;

		protected Collider2D collider2DComponent;


		/*
		============================================================================
		Auto destroy functions
		============================================================================
		*/
		protected override void Start()
		{
			this.colliderComponent = this.GetComponent<Collider>();
			this.collider2DComponent = this.GetComponent<Collider2D>();

			this.SceneAreaStart();
		}

		public virtual bool EditorHasCollider()
		{
			return this.GetComponent<Collider>() != null ||
				this.GetComponent<Collider2D>() != null;
		}

		protected virtual IEnumerator DelaySceneAreaStart()
		{
			yield return null;
			this.SceneAreaStart();
		}

		protected virtual void SceneAreaStart()
		{
			if(ORK.Game.ActiveGroup.Size == 0)
			{
				Maki.StartCoroutine(this.DelaySceneAreaStart());
			}
			else if(!this.CheckAutoDestroy())
			{
				if(this.IsSceneArea())
				{
					ORK.Battle.RealTimeAreaCount++;
					this.counted = true;
				}
			}
		}


		/*
		============================================================================
		Scene area functions
		============================================================================
		*/
		public virtual bool IsSceneArea()
		{
			return this.colliderComponent == null && this.collider2DComponent == null;
		}

		protected virtual void OnDisable()
		{
			if(this.IsSceneArea() || this.counted)
			{
				this.doStart = false;
				this.doEnd = false;
				this.counted = false;
				ORK.Battle.RealTimeAreaCount--;
			}
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if((other.gameObject == player ||
				(player != null &&
					other.transform.root == player.transform.root)) &&
				this.CheckConditions(player, false))
			{
				this.doStart = true;
				this.doEnd = false;
				this.StartCoroutine(this.EnterBattle());
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if(other.gameObject == player ||
				(player != null &&
					other.transform.root == player.transform.root))
			{
				this.doStart = false;
				this.doEnd = true;
				this.StartCoroutine(this.ExitBattle());
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if((other.gameObject == player ||
				(player != null &&
					other.transform.root == player.transform.root)) &&
				this.CheckConditions(player, false))
			{
				this.doStart = true;
				this.doEnd = false;
				this.StartCoroutine(this.EnterBattle());
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if(other.gameObject == player ||
				(player != null &&
					other.transform.root == player.transform.root))
			{
				this.doStart = false;
				this.doEnd = true;
				this.StartCoroutine(this.ExitBattle());
			}
		}


		/*
		============================================================================
		Battle functions (fix for exit/enter bug)
		============================================================================
		*/
		protected virtual IEnumerator EnterBattle()
		{
			yield return null;
			yield return null;
			if(this.doStart)
			{
				this.doStart = false;
				this.doEnd = false;

				if(!this.counted)
				{
					this.counted = true;
					ORK.Battle.RealTimeAreaCount++;
				}
			}
		}

		protected virtual IEnumerator ExitBattle()
		{
			yield return null;
			yield return null;
			if(this.doEnd)
			{
				this.doStart = false;
				this.doEnd = false;

				if(this.counted)
				{
					this.counted = false;
					ORK.Battle.RealTimeAreaCount--;
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/RealTimeBattleArea Icon.png");
		}
	}
}
