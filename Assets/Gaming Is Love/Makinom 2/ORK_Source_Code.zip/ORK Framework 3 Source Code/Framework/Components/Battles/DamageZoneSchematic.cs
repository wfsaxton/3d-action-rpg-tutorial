﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using System.Collections.Generic;
using System;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Damage Zone (Schematic)")]
	public class DamageZoneSchematic : SerializedBehaviour<DamageZoneSchematic.Settings>, ISchematicStarter, IDamageZone
	{
		protected bool isStarted = false;

		public virtual Combatant Combatant
		{
			get { return null; }
			set { }
		}

		public virtual bool CanDamage(DamageDealer dealer, BaseAction action)
		{
			return this.settings.CheckTargetType(action) &&
				this.settings.CheckAction(action) &&
				(!dealer.settings.alwaysOn ||
					!dealer.settings.alwaysOnConsumeCosts ||
					action.Shortcut.CanUse(action.User, false, true)) &&
				(!dealer.settings.oneTimeDamage ||
					!dealer.IsBlocked(this)) &&
				(!dealer.settings.oneTarget ||
					dealer.BlockedCount == 0 ||
				(dealer.BlockedCount == 1 &&
					dealer.IsBlocked(this))) &&
				(dealer.settings.damageEvery == 0 ||
					!dealer.IsDamageBlocked(this));
		}

		public virtual void Damage(BaseAction action)
		{
			if(this.settings.schematicAsset.StoredAsset != null &&
				(!this.settings.wait || !this.isStarted))
			{
				this.isStarted = true;
				Schematic.Play(this.settings.schematicAsset.StoredAsset, this, this,
					action.User, this.gameObject);
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			this.isStarted = false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "/GamingIsLove/ORKFramework/Components/DamageZone Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Schematic Asset", "Select the schematic asset that will be started when this damage zone is hit.\n" +
				"Uses the damage dealer's user as the 'Machine Object', this game object as the 'Starting Object' of the schematic.")]
			[EditorFoldout("Schematic Damage Zone Settings", "Define if and how the damage zone's schematic can be started.")]
			[EditorLabel("This damage zone doesn't require to be placed on a combatant.\n" +
				"The defined schematic will be started when being hit by a damage dealer (based on the damage dealer's 'Start Type').")]
			public AssetSource<MakinomSchematicAsset> schematicAsset = new AssetSource<MakinomSchematicAsset>();

			[EditorHelp("Wait", "Wait for the schematic to finish before allowing another schematic to start.")]
			public bool wait = true;


			// check target type
			[EditorHelp("Check Target Type", "Check the 'Target Type' of the ability/item of the damage dealer hitting this damage zone.\n" +
				"This allows checking if the action is targeting allies or enemies (e.g. to only start the schematic when hit by an attack damaging enemies).")]
			public bool checkTargetType = false;

			[EditorHelp("Target Type", "Select which target type the ability/item must use:\n" +
				"- Self: The combatant itself.\n" +
				"- Ally: Allies of the combatant.\n" +
				"- Enemy: Enemies of the combatant.\n" +
				"- All: Any combatant.")]
			[EditorCondition("checkTargetType", true)]
			[EditorEndCondition]
			public TargetType targetType = TargetType.Enemy;

			// action check
			[EditorSeparator]
			[EditorEndFoldout]
			[EditorLabel("Add no action check to allow all actions to start the schematic.")]
			[EditorArray("Add Action Check", "Add an action to check for.", "",
				"Remove", "Remove this action check.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Action Check", "Define the action that will be checked for.", ""
			})]
			public ActionCheck[] actionCheck = new ActionCheck[0];

			public Settings()
			{

			}

			public virtual bool CheckTargetType(BaseAction action)
			{
				if(this.checkTargetType)
				{
					TargetSelectionSettings targetSettings = TargetSelectionSettings.Get(action.Shortcut);
					return targetSettings != null &&
						targetSettings.targetType == this.targetType;
				}
				return true;
			}

			public virtual bool CheckAction(BaseAction action)
			{
				if(action != null)
				{
					return ActionCheck.Check(this.actionCheck, action);
				}
				return false;
			}
		}
	}
}
