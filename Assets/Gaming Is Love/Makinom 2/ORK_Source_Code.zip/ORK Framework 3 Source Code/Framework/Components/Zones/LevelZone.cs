﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Zone/Level Zone")]
	public class LevelZone : BaseColliderZone, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_settings;

		protected virtual void OnEnable()
		{
			if(this.Collider ||
				this.Collider2D)
			{
				// just to get colliders
			}
			ORK.Game.Scene.AddLevelZone(this);
		}

		protected virtual void OnDestroy()
		{
			ORK.Game.Scene.RemoveLevelZone(this);
		}

		public virtual bool HasCollider
		{
			get { return this.colliderComponent != null || this.collider2DComponent != null; }
		}

		public override bool IsWithin(Vector3 point)
		{
			if(this.Collider != null)
			{
				point.y = this.Collider.bounds.center.y;
				if(this.Collider.bounds.Contains(point))
				{
					point.y = this.Collider.bounds.max.y + 1;
					RaycastHit hit;
					if(this.Collider.Raycast(new Ray(point, -Vector3.up), out hit, this.Collider.bounds.size.y))
					{
						return true;
					}
				}
			}
			else if(this.Collider2D != null)
			{
				return this.Collider2D.OverlapPoint(point);
			}
			return false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/LevelZone Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_settings = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_settings != null)
			{
				this.settings.SetData(this.serialize_settings.ToDataObject());
				this.serialize_settings = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// level settings
			// min level
			[EditorHelp("Use Minimum Level", "Use a minimum level all combatants can have within this level zone.", "")]
			[EditorFoldout("Level Settings", "The base level of combatants within this level zone.", "")]
			public bool useMinLevel = false;

			[EditorHelp("Minimum Level", "The minimum level all combatants can have within this level zone.", "")]
			[EditorLimit(1, false)]
			[EditorIndent]
			[EditorCondition("useMinLevel", true)]
			[EditorEndCondition]
			public int minLevel = 1;

			// max level
			[EditorHelp("Use Maximum Level", "Use a maximum level all combatants can have within this level zone.", "")]
			[EditorSeparator]
			public bool useMaxLevel = false;

			[EditorHelp("Minimum Level", "The maximum level all combatants can have within this level zone.", "")]
			[EditorLimit(1, false)]
			[EditorIndent]
			[EditorCondition("useMaxLevel", true)]
			[EditorEndCondition]
			public int maxLevel = 100;

			// level
			[EditorHelp("Set Levels", "Set the base levels of combatants with in this level zone.\n" +
				"If disabled, combatants will use the level settings they're usually spawned with " +
				"(e.g. from 'Battle' or 'Combatant Spawner' components).", "")]
			[EditorSeparator]
			public bool useLevelSettings = true;

			[EditorEndFoldout]
			[EditorCondition("useLevelSettings", true)]
			[EditorEndCondition]
			public LevelInitSettings levelSettings = new LevelInitSettings();


			// class level settings
			// min level
			[EditorHelp("Use Minimum Level", "Use a minimum class level all combatants can have within this level zone.", "")]
			[EditorFoldout("Class Level Settings", "The class level of combatants within this level zone.", "")]
			public bool classUseMinLevel = false;

			[EditorHelp("Minimum Level", "The minimum class level all combatants can have within this level zone.", "")]
			[EditorLimit(1, false)]
			[EditorIndent]
			[EditorCondition("classUseMinLevel", true)]
			[EditorEndCondition]
			public int classMinLevel = 1;

			// max level
			[EditorHelp("Use Maximum Level", "Use a maximum class level all combatants can have within this level zone.", "")]
			[EditorSeparator]
			public bool classUseMaxLevel = false;

			[EditorHelp("Minimum Level", "The maximum class level all combatants can have within this level zone.", "")]
			[EditorLimit(1, false)]
			[EditorIndent]
			[EditorCondition("classUseMaxLevel", true)]
			[EditorEndCondition]
			public int classMaxLevel = 100;

			// level
			[EditorHelp("Set Levels", "Set the class levels of combatants with in this level zone.\n" +
				"If disabled, combatants will use the level settings they're usually spawned with " +
				"(e.g. from 'Battle' or 'Combatant Spawner' components).", "")]
			[EditorSeparator]
			public bool classUseLevelSettings = true;

			[EditorEndFoldout]
			[EditorCondition("classUseLevelSettings", true)]
			[EditorEndCondition]
			public LevelInitSettings classLevelSettings = new LevelInitSettings();

			public Settings()
			{

			}
		}
	}
}
