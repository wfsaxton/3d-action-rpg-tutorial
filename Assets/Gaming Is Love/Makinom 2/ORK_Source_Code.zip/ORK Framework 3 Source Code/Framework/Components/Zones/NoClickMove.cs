
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Player Control/No Click Move")]
	public class NoClickMove : RaycastColliderZone
	{
		protected virtual void OnEnable()
		{
			ORK.Game.Scene.AddNoClickMove(this);
		}

		protected virtual void OnDisable()
		{
			ORK.Game.Scene.RemoveNoClickMove(this);
		}
	}
}
