
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Layer Gate", "Connects two layers.", "")]
	[NodeInfo("Base")]
	public class BattleAIGateNode : BaseAINode
	{
		[EditorHide]
		public int toLayer = 0;

		[EditorHide]
		public Vector2 nodePosition2 = new Vector2(38, 38);

		[EditorHide]
		public int nodeGroup2 = -1;

		public BattleAIGateNode()
		{

		}

		public BattleAIGateNode(int toLayer)
		{
			this.toLayer = toLayer;
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;
			return null;
		}

		public override bool IsConnectable(int layer)
		{
			return this.nodeLayer == layer;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.toLayer.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.layerGateNodeColor; }
		}


		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public override void SetPosition(int layer, Vector2 position)
		{
			if(this.nodeLayer == layer)
			{
				this.nodePosition = position;
			}
			if(this.toLayer == layer)
			{
				this.nodePosition2 = position;
			}
		}

		public override Vector2 GetPosition(int layer)
		{
			if(this.toLayer == layer)
			{
				return this.nodePosition2;
			}
			else
			{
				return this.nodePosition;
			}
		}


		/*
		============================================================================
		Node group functions
		============================================================================
		*/
		public override void SetNodeGroup(int layer, int index)
		{
			if(this.nodeLayer == layer)
			{
				this.nodeGroup = index;
			}
			if(this.toLayer == layer)
			{
				this.nodeGroup2 = index;
			}
		}

		public override int GetNodeGroup(int layer)
		{
			if(this.toLayer == layer)
			{
				return this.nodeGroup2;
			}
			else
			{
				return this.nodeGroup;
			}
		}

		public override void GroupRemoved(int index)
		{
			if(index <= this.nodeGroup)
			{
				this.nodeGroup--;
			}
			if(index <= this.nodeGroup2)
			{
				this.nodeGroup2--;
			}
		}


		/*
		============================================================================
		Layer functions
		============================================================================
		*/
		public override bool IsOnLayer(int layer)
		{
			return this.nodeLayer == layer ||
				this.toLayer == layer;
		}

		public override bool RemoveLayer(int layer)
		{
			if(this.nodeLayer == layer ||
				this.toLayer == layer)
			{
				return true;
			}
			if(this.nodeLayer > layer)
			{
				this.nodeLayer--;
			}
			if(this.toLayer > layer)
			{
				this.toLayer--;
			}
			return false;
		}
	}

	[EditorHelp("Random", "Randomly executes a next node out of a list of defined nodes.", "")]
	[NodeInfo("Base")]
	public class RandomNode : BaseAINode
	{
		[EditorHide]
		[EditorCallback("buttons:randomnode", EditorCallbackType.InstanceBefore)]
		public int[] random = new int[] { -1 };

		public RandomNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.random[UnityWrapper.Range(0, this.random.Length)];
			return null;
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}

		public override int GetNextCount()
		{
			return this.random.Length;
		}

		public override int GetNext(int index)
		{
			return this.random[index];
		}

		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Battle AI", "Executes another battle AI to find a battle action.\n" +
		"If no action is found, 'Next' will be executed.\n" +
		"Keep in mind that using the same battle AI can result in a loop and will ultimately crash the game.", "")]
	[NodeInfo("Base")]
	public class BattleAINode : BaseAINode
	{
		[EditorHelp("Battle AI", "Select the battle AI that will be executed.", "")]
		public AssetSelection<BattleAIAsset> battleAI = new AssetSelection<BattleAIAsset>();

		public BattleAINode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;
			if(this.battleAI.StoredAsset != null)
			{
				return this.battleAI.StoredAsset.Settings.GetAction(call);
			}
			else
			{
				return null;
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.battleAI.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Comment", "Leave a comment in your battle AI.\n" +
		"This node does nothing and is only for commentary purposes.", "")]
	[NodeInfo("Base")]
	public class CommentNode : BaseAINode
	{

		[EditorHelp("Comment", "The comment.", "")]
		public TextContent comment = new TextContent();

		public CommentNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}

	[EditorHelp("Unity Console", "Prints a text to the Unity console using 'Debug.Log()'.", "")]
	[NodeInfo("Base")]
	public class UnityConsoleNode : BaseAINode
	{
		[EditorHelp("Debug Type", "Select the debug type will be used:\n" +
			"- Log: Printed to 'Debug.Log'.\n" +
			"- Warning: Printed to 'Debug.LogWarning'.\n" +
			"- Error: Printed to 'Debug.LogError'.", "")]
		public DebugType type = DebugType.Log;

		[EditorSeparator]
		public VariableOrigin<BattleAIObjectSelection> variable = new VariableOrigin<BattleAIObjectSelection>();

		[EditorHelp("Text", "The text that will be printed to the Unity console.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Console Output")]
		public TextContent text = new TextContent();

		public UnityConsoleNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;
			UIText content = new UIText(this.text, null, null, this.variable.GetFirstHandler(call));
			if(DebugType.Log == this.type)
			{
				Debug.Log(content.Text);
			}
			else if(DebugType.Warning == this.type)
			{
				Debug.LogWarning(content.Text);
			}
			else if(DebugType.Error == this.type)
			{
				Debug.LogError(content.Text);
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.text.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Chance", "Which node will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"The next node of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[NodeInfo("Base", "Check")]
	public class ChanceNode : BaseAINode
	{
		[EditorArray("Add Range", "Adds a range for the chance check.", "",
			"Remove", "Removes this range.", "", isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next node will be executed.", ""
		})]
		public ChanceNextNode<BattleAIObjectSelection>[] range = new ChanceNextNode<BattleAIObjectSelection>[] {
			new ChanceNextNode<BattleAIObjectSelection>()
		};

		public ChanceNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			currentNode = this.next;

			float chance = Maki.GameSettings.GetRandom();

			for(int i = 0; i < this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, call))
				{
					currentNode = this.range[i].next;
					break;
				}
			}

			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " +
					this.range[index - 1].ToString();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Check Difficulty", "Checks the game's currently selected difficulty.\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Base", "Check")]
	public class CheckDifficultyNode : BaseAICheckNode
	{
		public DifficultyCheck difficultyCheck = new DifficultyCheck();

		public CheckDifficultyNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.difficultyCheck.Check())
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.difficultyCheck.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Check Value", "A value (e.g. result of a formula) will be checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Base", "Variable", "Check")]
	public class CheckValueNode : BaseAICheckNode
	{
		[EditorHelp("Value", "The value that will be checked.", "")]
		public FloatValue<BattleAIObjectSelection> value = new FloatValue<BattleAIObjectSelection>();

		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckValueNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.check.Check(this.value.GetValue(call), call))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.value.ToString() + " " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Battle Turn", "Checks the current battle turn (independent of combatants).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Please note that battle turns are only used in 'Turn Based', 'Active Time' and 'Phase' battles.\n" +
		"In 'Active Time' battles, a battle turn lasts until each combatant (that's able to) has performed 1 action.", "")]
	[NodeInfo("Base", "Combatant", "Check")]
	public class CheckBattleTurnNode : BaseAICheckNode
	{
		[EditorLabel("The current battle turn will be changed by the defined math function.\n" +
			"E.g. use 'Modulo (%)' to check for every defined turns (is equal 0), e.g. every 2nd turn via a divisor of 2.")]
		public MathFunction mathFunction = new MathFunction();

		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckBattleTurnNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.check.Check(this.mathFunction.Use(ORK.Battle.Turn), call))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.mathFunction.ToString() + " " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
