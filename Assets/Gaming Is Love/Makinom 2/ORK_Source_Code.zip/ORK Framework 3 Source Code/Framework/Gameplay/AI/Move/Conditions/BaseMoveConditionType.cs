﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public abstract class BaseMoveConditionType : BaseTypeData
	{
		public abstract bool IsValid(Combatant combatant, Combatant target);
	}
}
