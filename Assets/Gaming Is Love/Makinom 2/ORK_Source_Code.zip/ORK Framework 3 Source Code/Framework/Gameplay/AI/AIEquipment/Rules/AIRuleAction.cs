﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRuleAction : BaseData
	{
		public ActionSelection actionSettings = new ActionSelection();

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public AIRuleAction()
		{

		}

		public BaseAction GetAction(Combatant combatant)
		{
			return this.actionSettings.GetAction(combatant, false, true, true, this.blockBattleCamera);
		}
	}
}
