﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Change Move AI", "Changes the move AI of the user.", "")]
	[NodeInfo("Move AI")]
	public class ChangeMoveAINode : BaseAINode
	{
		[EditorHelp("Restore Move AI", "Restore the move AI to the one originally used by the combatant.", "")]
		public bool restore = false;

		[EditorHelp("Move AI", "Select the move AI that will be used.", "")]
		[EditorCondition("restore", false)]
		[EditorEndCondition]
		public AssetSelection<MoveAIAsset> move = new AssetSelection<MoveAIAsset>();

		public ChangeMoveAINode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				if(this.restore)
				{
					call.user.Object.MoveAI.ChangeMoveAI(call.user.Object.MoveAI.originalSettings);
				}
				else if(this.move.StoredAsset != null)
				{
					call.user.Object.MoveAI.ChangeMoveAI(this.move.StoredAsset.Settings);
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.move.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Change Move AI Mode", "Changes the use mode of the user's move AI.", "")]
	[NodeInfo("Move AI")]
	public class ChangeMoveAIModeNode : BaseAINode
	{
		[EditorHelp("Restore Default", "Restore the default use mode of the move AI (defined in the move AI's settings).", "")]
		public bool restore = false;

		[EditorHelp("Use Mode", "Select the use mode of the move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.\n" +
			"- Protect: Forces protecting group members.", "")]
		[EditorCondition("restore", false)]
		[EditorEndCondition]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public ChangeMoveAIModeNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				call.user.Object.MoveAI.UseMode = this.restore ?
					call.user.Object.MoveAI.settings.useMode : this.useMode;
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.useMode.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Change Move AI Stop Angle", "Changes the stop angle of the user's move AI.\n" +
		"The stop angle is used by hunting and caution modes to optionally move to a specific position around the target.\n" +
		"The used angle value defined here is calcualted only when setting the stop angle, not for each time it's used by the move AI.", "")]
	[NodeInfo("Move AI")]
	public class ChangeMoveAIStopAngleNode : BaseAINode
	{
		[EditorHelp("Restore Default", "Restore the default stop angle (defined in the move AI's settings).", "")]
		public bool restore = false;

		[EditorCondition("restore", false)]
		[EditorEndCondition]
		public MoveAIStopAngle<BattleAIObjectSelection> stopAngle = new MoveAIStopAngle<BattleAIObjectSelection>();

		public ChangeMoveAIStopAngleNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				call.user.Object.MoveAI.StopAngle = this.restore ? null : this.stopAngle.ToStopAngle(call);
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.stopAngle.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Detection", "Checks if the targets are detected by the combatant's move AI detection.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAIDetectionNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		public CheckMoveAIDetectionNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Object.MoveAI != null &&
				call.user.Object.MoveAI.settings.useDetection)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(call.user.Object.MoveAI.settings.Detect(call.user, list[i]))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Hunting", "Checks if the targets are valid for hunting due to the " +
		"combatant's move AI hunting conditions. " +
		"The combatant needs to be aggressive in order to hunt targets.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAIHuntingNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		public CheckMoveAIHuntingNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Object.MoveAI != null &&
				call.user.Object.MoveAI.settings.hunting.enabled)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(call.user.Object.MoveAI.settings.hunting.IsHunting(call.user, list[i]))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Flee", "Checks if the targets are valid for fleeing due to the " +
		"combatant's move AI flee conditions.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAIFleeNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		public CheckMoveAIFleeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Object.MoveAI != null &&
				call.user.Object.MoveAI.settings.flee.enabled)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(call.user.Object.MoveAI.settings.flee.IsFlee(call.user, list[i]))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Caution", "Checks if the targets are valid for being cautious due to the " +
		"combatant's move AI caution conditions.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAICautionNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		public CheckMoveAICautionNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Object.MoveAI != null &&
				call.user.Object.MoveAI.settings.caution.enabled)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(call.user.Object.MoveAI.settings.caution.IsCautious(call.user, list[i]))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Target", "Checks if the targets are the current target of the combatant's move AI.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAITargetNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();

		public CheckMoveAITargetNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(call.user.Object.MoveAI != null)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(call.user.Object.MoveAI.IsTarget(list[i]))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}
}
