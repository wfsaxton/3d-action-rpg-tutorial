﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework
{
	public class AIRulesetSlotSetting : BaseData, IFoldoutInfo
	{
		// unequip
		[EditorHelp("Unequip", "This AI ruleset slot will be unequipped.", "")]
		public bool unequip = false;

		[EditorHelp("Collect", "Collect the currently equipped AI ruleset.\n" +
			"Only used for combatants of the player group.", "")]
		public bool collect = false;


		// equip
		[EditorHelp("AI Ruleset", "Select the AI ruleset that will be equipped.", "")]
		[EditorCondition("unequip", false)]
		public AssetSelection<AIRulesetAsset> aiRuleset = new AssetSelection<AIRulesetAsset>();

		[EditorHelp("From Collection", "The AI ruleset will be taken from the collection, " +
			"i.e. it must be collected and available to be equipped.\n" +
			"This is only used for combatants of the player group.", "")]
		[EditorEndCondition]
		public bool fromCollection = false;

		public AIRulesetSlotSetting()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.unequip ? "Unequip" : this.aiRuleset.ToString();
		}

		public void Use(Combatant user, int slotIndex, bool notify)
		{
			if(this.unequip)
			{
				user.AI.UnequipAIRulesetSlotAccess(slotIndex, this.collect, notify);
			}
			else if(this.aiRuleset.StoredAsset != null)
			{
				user.AI.EquipAIRulesetAccess(this.aiRuleset.StoredAsset.Settings,
					slotIndex, this.collect, this.fromCollection, notify);
			}
		}

		public override string ToString()
		{
			return this.unequip ? "Unequip" : this.aiRuleset.ToString();
		}
	}
}
