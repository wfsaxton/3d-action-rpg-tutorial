﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public enum BattleAIUseMode { FirstUseable, Queue }

	public class BattleAICall : IDataCall
	{
		public bool hadQueuedActions = false;

		public Combatant user;

		public Combatant checkTarget;

		public List<Combatant> allies;

		public List<Combatant> enemies;

		public List<Combatant> foundTargets = new List<Combatant>();

		public bool checkTime = true;

		public bool checkUseCosts = true;

		public BattleAIUseMode useMode = BattleAIUseMode.FirstUseable;

		protected VariableHandler localVariables;

		protected SelectedDataHandler selectedData;

		public BattleAICall(bool hadQueuedActions, Combatant user,
			List<Combatant> allies, List<Combatant> enemies,
			bool checkTime, bool checkUseCosts)
		{
			this.hadQueuedActions = hadQueuedActions;
			this.user = user;
			this.allies = allies;
			this.enemies = enemies;
			this.checkTime = checkTime;
			this.checkUseCosts = checkUseCosts;
		}

		public BattleAICall(BattleAICall call, Combatant user, Combatant target)
		{
			this.hadQueuedActions = call.hadQueuedActions;
			this.user = user;
			this.checkTarget = target;
			this.allies = call.allies;
			this.enemies = call.enemies;
			this.foundTargets = call.foundTargets;
			this.checkTime = call.checkTime;
			this.checkUseCosts = call.checkUseCosts;
			this.useMode = call.useMode;
			this.localVariables = call.localVariables;
			this.selectedData = call.selectedData;
		}

		public VariableHandler Variables
		{
			get
			{
				if(this.localVariables == null)
				{
					this.localVariables = new VariableHandler();
				}
				return this.localVariables;
			}
		}

		public SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = new SelectedDataHandler();
				}
				return this.selectedData;
			}
		}

		public virtual int InputID
		{
			get { return this.user != null ? this.user.InputID : Maki.Control.InputID; }
		}

		public virtual float Value
		{
			get { return 0; }
		}

		public virtual float TimeScale
		{
			get { return Maki.Game.TimeScale; }
		}

		public virtual float DeltaTime
		{
			get { return Maki.Game.DeltaTime; }
		}

		public virtual bool HasDebug
		{
			get { return false; }
		}

		public virtual IDebug DebugInfo
		{
			get { return null; }
		}
	}
}
