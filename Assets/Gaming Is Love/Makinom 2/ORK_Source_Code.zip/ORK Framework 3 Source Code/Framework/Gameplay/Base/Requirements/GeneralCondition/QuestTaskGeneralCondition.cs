﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Quest Task", "Check quest task status conditions.")]
	public class QuestTaskGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Needed", "Either all or just one of the task conditions needs to be valid.", "")]
		public Needed needed = Needed.All;

		[EditorArray( "Add Task Condition", "Adds a new task status condition.", "",
			"Remove", "Removes the task status condition.", "",
			isMove=true, isCopy=true, removeCheckField="task",
			foldout=true, foldoutText=new string[] {
				"Task Status Condition", "Define the task status condition that must be valid.", ""
		})]
		public CheckQuestTaskStatus[] taskStatus = new CheckQuestTaskStatus[0];

		public QuestTaskGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Quest Task";
		}

		public override bool Check(IDataCall call)
		{
			if(this.taskStatus.Length > 0)
			{
				for(int i = 0; i < this.taskStatus.Length; i++)
				{
					if(this.taskStatus[i].Check())
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				if(Needed.All == this.needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			ORK.Game.Quests.Changed += notify;
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			ORK.Game.Quests.Changed -= notify;
		}
	}
}
