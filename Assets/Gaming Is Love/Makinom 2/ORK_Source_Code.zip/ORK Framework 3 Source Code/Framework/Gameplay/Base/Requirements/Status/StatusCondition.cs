
using UnityEngine;
using GamingIsLove.ORKFramework.Conditions;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum StatusConditionType { Status, Conditions, Template };

	public class StatusCondition : BaseData, IFoldoutInfo
	{
		[EditorHelp("Condition Type", "Select what will be checked:\n" +
			"- Status: A single status will be checked.\n" +
			"- Conditions: Defined status conditions will be checked, allows more complex conditions.\n" +
			"- Template: A status condition template will be used.", "")]
		public StatusConditionType conditionType = StatusConditionType.Status;


		// status
		[EditorCondition("conditionType", StatusConditionType.Status)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StatusConditionSelection status;


		// conditions
		[EditorHelp("Needed", "Either all or only one status conditions must be met.", "")]
		[EditorCondition("conditionType", StatusConditionType.Conditions)]
		public Needed needed = Needed.All;

		[EditorArray("Add Status Condition", "Add a status condition.", "",
			"Remove", "Remove the status condition.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Status Condition", "Define the status condition that must be valid.", ""
		})]
		[EditorEndCondition]
		[EditorAutoInit]
		public StatusCondition[] condition;


		// template
		[EditorHelp("Template", "Select the status condition template that will be used.", "")]
		[EditorCondition("conditionType", StatusConditionType.Template)]
		[EditorEndCondition]
		public AssetSelection<StatusConditionTemplateAsset> template = new AssetSelection<StatusConditionTemplateAsset>();

		public StatusCondition()
		{

		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override string ToString()
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				return this.status != null ? this.status.ToString() : "";
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				return "Conditions";
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				return this.template.ToString();
			}
			return "";
		}

		public virtual string GetFoldoutInfo()
		{
			return this.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				return this.status.settings.Check(combatant);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				return StatusCondition.Check(combatant, this.condition, this.needed);
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				return this.template.StoredAsset != null &&
					this.template.StoredAsset.Settings.conditions.Check(combatant);
			}
			return false;
		}

		public bool CheckPreview(Combatant combatant)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				return this.status.settings.CheckPreview(combatant);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				return StatusCondition.CheckPreview(combatant, this.condition, this.needed);
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				return this.template.StoredAsset != null &&
					this.template.StoredAsset.Settings.conditions.CheckPreview(combatant);
			}
			return false;
		}

		public bool CheckBestiary(Combatant combatant)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				return this.status.settings.CheckBestiary(combatant);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				return StatusCondition.CheckBestiary(combatant, this.condition, this.needed);
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				return this.template.StoredAsset != null &&
					this.template.StoredAsset.Settings.conditions.CheckBestiary(combatant);
			}
			return false;
		}

		public static bool Check(Combatant combatant, StatusCondition[] condition, Needed needed)
		{
			if(condition.Length > 0)
			{
				for(int i = 0; i < condition.Length; i++)
				{
					if(condition[i].Check(combatant))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public static bool CheckPreview(Combatant combatant, StatusCondition[] condition, Needed needed)
		{
			if(condition.Length > 0)
			{
				for(int i = 0; i < condition.Length; i++)
				{
					if(condition[i].CheckPreview(combatant))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public static bool CheckBestiary(Combatant combatant, StatusCondition[] condition, Needed needed)
		{
			if(condition.Length > 0)
			{
				for(int i = 0; i < condition.Length; i++)
				{
					if(condition[i].CheckBestiary(combatant))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				this.status.settings.Register(combatant, notify);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					this.condition[i].RegisterStatusChanges(combatant, notify);
				}
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				if(this.template.StoredAsset != null)
				{
					this.template.StoredAsset.Settings.conditions.RegisterStatusChanges(combatant, notify);
				}
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				this.status.settings.Unregister(combatant, notify);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					this.condition[i].UnregisterStatusChanges(combatant, notify);
				}
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				if(this.template.StoredAsset != null)
				{
					this.template.StoredAsset.Settings.conditions.UnregisterStatusChanges(combatant, notify);
				}
			}
		}

		public void RegisterStatusChanges(Combatant combatant, Notify notify)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				this.status.settings.Register(combatant, notify);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					this.condition[i].RegisterStatusChanges(combatant, notify);
				}
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				if(this.template.StoredAsset != null)
				{
					this.template.StoredAsset.Settings.conditions.RegisterStatusChanges(combatant, notify);
				}
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, Notify notify)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				this.status.settings.Unregister(combatant, notify);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					this.condition[i].UnregisterStatusChanges(combatant, notify);
				}
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				if(this.template.StoredAsset != null)
				{
					this.template.StoredAsset.Settings.conditions.UnregisterStatusChanges(combatant, notify);
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool ContainsCondition(ResearchTreeSetting researchTree, int researchItemIndex)
		{
			if(StatusConditionType.Status == this.conditionType)
			{
				return this.status.settings is ResearchItemStatusConditionType &&
					((ResearchItemStatusConditionType)this.status.settings).IsCheck(researchTree, researchItemIndex);
			}
			else if(StatusConditionType.Conditions == this.conditionType)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					if(this.condition[i].ContainsCondition(researchTree, researchItemIndex))
					{
						return true;
					}
				}
			}
			else if(StatusConditionType.Template == this.conditionType)
			{
				if(this.template.StoredAsset != null)
				{
					this.template.StoredAsset.Settings.conditions.ContainsCondition(researchTree, researchItemIndex);
				}
			}
			return false;
		}
	}
}
