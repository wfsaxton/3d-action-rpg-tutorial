﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Menu Close", "When a menu is closed.")]
	public class MenuCloseGameStateChangeType : BaseGameStateChangeType
	{
		public MenuCloseGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Menu.MenuClosed += notify;
		}
	}
}
