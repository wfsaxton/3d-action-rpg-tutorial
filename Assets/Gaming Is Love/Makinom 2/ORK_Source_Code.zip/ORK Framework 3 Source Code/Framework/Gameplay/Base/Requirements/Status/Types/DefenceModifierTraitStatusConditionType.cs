﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Defence Modifier Trait", "The defined defence modifier attribute must or mustn't be recongized as a defined trait (strength, weakness, etc.).")]
	public class DefenceModifierTraitStatusConditionType : BaseStatusConditionType
	{
		public DefenceModifierAttributeSelection selection = new DefenceModifierAttributeSelection();

		[EditorHelp("Trait", "Select which trait will be checked for:\n" +
			"- None: The attribute isn't recognized as any trait.\n" +
			"- Strength: The attribute is recognized as strengths.\n" +
			"- Weakness: The attribute is recognized as weaknesses.\n" +
			"- Immunity: The attribute is recognized as immunities.\n" +
			"- Recovery: The attribute is recognized as recoveries.", "")]
		public ModifierTraitType trait = ModifierTraitType.Strength;

		[EditorHelp("Is Trait", "The attack modifier attribute must be the defined trait.\n" +
			"If disabled, it mustn't be the trait.", "")]
		public bool isTrait = true;

		public DefenceModifierTraitStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.selection.ToString() + (this.isTrait ? " is " : " is not ") + this.trait;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.selection.IsTrait(combatant, this.trait);
		}

		public override bool CheckPreview(Combatant combatant)
		{
			return this.selection.IsTrait(combatant, this.trait);
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null)
			{
				return this.selection.IsTrait(combatant, this.trait);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			DefenceModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.Changed += notify.NotifyStatusChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			DefenceModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.Changed -= notify.NotifyStatusChanged;
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			DefenceModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.SimpleChanged += notify;
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			DefenceModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.SimpleChanged -= notify;
			}
		}
	}
}
