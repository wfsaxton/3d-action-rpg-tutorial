﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface ITargetSelectionCursorPrefab
	{
		void StartSelection(Combatant user, Combatant target, IShortcut shortcut);

		void StopSelection();
	}
}
