
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using System.Text;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Grid Distance", "The grid distance between user and target is used.", "")]
	[NodeInfo("Position")]
	public class GridDistanceNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();


		// distance
		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[EditorSeparator]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		public GridDistanceNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = call.GetUserCombatant();
			Combatant target = call.GetTargetCombatant();
			if(user != null && target != null)
			{
				this.formulaOperator.Use(ref call.result,
					this.ignoreSizeCells ?
						user.Grid.Cell.CubeCoord.Distance(
							target.Grid.Cell.CubeCoord, this.blockDiagonalDistance1) :
						user.Grid.GetLowestDistance(
							target, this.blockDiagonalDistance1));
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Grid Distance", "The distance on a battle grid between user and target is checked with a defined value.\n" +
		"Neighbouring cells have a distance of 1, a cell between is distance of 2, etc.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckGridDistanceNode : BaseFormulaCheckNode
	{
		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;


		// check
		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckGridDistanceNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = call.GetUserCombatant();
			Combatant target = call.GetTargetCombatant();
			if(user != null &&
				target != null &&
				ORK.Battle.Grid != null &&
				user.Grid.Cell != null &&
				target.Grid.Cell != null &&
				this.ignoreSizeCells ?
					this.check.Check(
						user.Grid.Cell.CubeCoord.Distance(target.Grid.Cell.CubeCoord, this.blockDiagonalDistance1),
						call) :
					user.Grid.CheckDistance(target, this.blockDiagonalDistance1,
						(int)this.check.value.GetValue(call),
						(int)(this.check.value2 != null ? this.check.value2.GetValue(call) : 0),
						this.check.type, null))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Is Grid Cell Diagonal", "Checks if user and target are diagonal to each other ('Square' grids only).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position", "Check")]
	public class IsGridCellDiagonalNode : BaseFormulaCheckNode
	{
		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		public IsGridCellDiagonalNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant user = call.GetUserCombatant();
			Combatant target = call.GetTargetCombatant();
			if(user != null &&
				target != null &&
				ORK.Battle.Grid != null &&
				ORK.BattleGridSettings.IsSquare &&
				user.Grid.Cell != null &&
				target.Grid.Cell != null &&
				this.ignoreSizeCells ?
					CubeCoord.IsSquareDiagonal(user.Grid.Cell.CubeCoord, target.Grid.Cell.CubeCoord) :
					user.Grid.CheckDiagonal(target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Check Grid Cell Type", "Checks if a combatant is currently on a cell of a defined grid cell type.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckGridCellTypeNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// grid cell type
		[EditorHelp("Grid Cell Type", "Select the grid cell type that will be used.", "")]
		[EditorArray("Add Grid Cell Type", "Adds a grid cell type that will be used.", "",
			"Remove", "Removes the grid cell type.", "",
			isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Grid Cell Type", "Select the grid cell type that will be used.", ""
			})]
		public AssetSelection<BattleGridCellTypeAsset>[] gridCellType = new AssetSelection<BattleGridCellTypeAsset>[] {
			new AssetSelection<BattleGridCellTypeAsset>()
		};

		public CheckGridCellTypeNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);
			if(ORK.Battle.Grid != null &&
				combatant != null &&
				BattleGridHelper.IsCellType(combatant.Grid.Cell, this.gridCellType))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			StringBuilder builder = new StringBuilder();
			builder.Append(this.origin.ToString()).Append(": ");

			for(int i = 0; i < this.gridCellType.Length; i++)
			{
				if(i > 0)
				{
					builder.Append(", ");
				}
				builder.Append(this.gridCellType[i].ToString());
			}
			return builder.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}
