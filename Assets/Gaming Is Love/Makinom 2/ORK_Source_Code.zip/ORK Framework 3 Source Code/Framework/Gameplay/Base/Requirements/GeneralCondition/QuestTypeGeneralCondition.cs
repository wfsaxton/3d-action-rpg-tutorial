﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Quest Type", "Check quest type status conditions.")]
	public class QuestTypeGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Needed", "Either all or just one of the quest type conditions needs to be valid.", "")]
		public Needed needed = Needed.All;

		[EditorArray("Add Quest Type Condition", "Adds a new quest type status condition.", "",
			"Remove", "Removes the quest type status condition.", "", 
			isMove=true, isCopy=true, removeCheckField="questType",
			foldout=true, foldoutText=new string[] {
				"Quest Type Status Condition", "Define the quest type status condition that must be valid.", ""
		})]
		public CheckQuestTypeStatus[] questTypeStatus = new CheckQuestTypeStatus[0];

		public QuestTypeGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Quest Type";
		}

		public override bool Check(IDataCall call)
		{
			if(this.questTypeStatus.Length > 0)
			{
				for(int i = 0; i < this.questTypeStatus.Length; i++)
				{
					if(this.questTypeStatus[i].Check())
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				if(Needed.All == this.needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			ORK.Game.Quests.Changed += notify;
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			ORK.Game.Quests.Changed -= notify;
		}
	}
}
