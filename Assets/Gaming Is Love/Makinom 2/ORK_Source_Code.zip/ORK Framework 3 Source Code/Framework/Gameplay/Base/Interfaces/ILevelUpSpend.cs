﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface ILevelUpSpend
	{
		void UsesExperience(Combatant combatant, int points);

		void CheckLevelUp(Combatant combatant, int points);

		bool CanLevelUp();

		bool CanLevelUpSpend(Combatant combatant);

		void SpendExperience(Combatant combatant);
	}
}
