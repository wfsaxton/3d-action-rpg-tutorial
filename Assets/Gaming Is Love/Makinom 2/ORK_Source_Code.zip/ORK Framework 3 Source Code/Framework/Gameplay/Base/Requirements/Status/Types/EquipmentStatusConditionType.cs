﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Equipment", "A defined equipment must or mustn't be equipped.")]
	public class EquipmentStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Equipment", "Select the equipment that will be used.", "")]
		public AssetSelection<EquipmentAsset> equipment = new AssetSelection<EquipmentAsset>();

		[EditorHelp("Level", "The level of the equipment that will be checked for.\n" +
			"The combatant must have at least the defined equipment level equipped.", "")]
		[EditorLimit(1, false)]
		public int level = 1;

		[EditorHelp("Is Equipped", "The equipment must be equipped on the combatant.\n" +
			"If disabled, the equipment mustn't be equipped.", "")]
		public bool isEquipped = true;

		[EditorHelp("Check Equipment Slot", "Check if the equipment is equipped on a defined equipment slot.\n" +
			"If disabled, checks if the equipment is equipped on any slot.", "")]
		public bool checkEquipmentSlot = false;

		[EditorHelp("Equipment Slot", "Select the equipment slot that will be check.", "")]
		[EditorCondition("checkEquipmentSlot", true)]
		[EditorEndCondition]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		public EquipmentStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.equipment.ToString() + (this.isEquipped ? " is equipped" : " not equipped") +
				(this.checkEquipmentSlot ? " on " + this.equipmentSlot.ToString() : "");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.equipment.StoredAsset != null &&
				combatant.Equipment.IsEquipped(this.equipment.StoredAsset.Settings, this.level,
					this.checkEquipmentSlot && this.equipmentSlot.StoredAsset != null ?
						this.equipmentSlot.StoredAsset.Settings : null) == this.isEquipped;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.equipment))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.EquipmentChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.EquipmentChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.EquipmentChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.EquipmentChangedSimple -= notify;
		}
	}
}
