﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Action Bar", "The combatant's action bar will be compared with a defined value.\n" +
		"The action bar refers to the 'Actions Per Turn' in turn based and phase battles, and the timebar in active time battles.")]
	public class ActionBarStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Used Action Bar", "Check the combatant's used action bar.\n" +
			"If disabled, the action bar will be checked.", "")]
		public bool usedActionBar = false;

		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public ActionBarStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.usedActionBar ? "Used Action Bar " : "Action Bar ") + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(this.usedActionBar ?
					combatant.Battle.UsedActionBar :
					combatant.Battle.ActionBar,
				combatant.Call);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ActionBarChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ActionBarChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ActionBarChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ActionBarChangedSimple -= notify;
		}
	}
}
