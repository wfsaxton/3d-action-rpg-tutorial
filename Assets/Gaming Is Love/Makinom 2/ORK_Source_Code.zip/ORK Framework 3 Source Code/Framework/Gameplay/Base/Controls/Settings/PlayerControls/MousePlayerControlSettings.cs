﻿
using UnityEngine;
using UnityEngine.AI;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum MouseControlMoveType { CharacterController, NavMeshAgent, CombatantMovementComponent }

	public class MousePlayerControlSettings : BaseData
	{
		[EditorFoldout("Mouse/Touch Control", "Input settings for mouse and touch control.", "")]
		[EditorEndFoldout]
		public MouseTouchControl mouseTouch = new MouseTouchControl(MouseTouchType.Both);


		// raycast
		[EditorHelp("Raycast Distance", "The distance the raycast will check to set the move target.", "")]
		[EditorSeparator]
		[EditorLimit(0.0f, false)]
		public float raycastDistance = 100.0f;

		[EditorHelp("Layer Mask", "Select the layers the raycast will check.", "")]
		public LayerMask layerMask = -1;


		// cursor
		[EditorHelp("Cursor Prefab", "The prefab used to display a cursor on the position of the move target.\n" +
			"Select none if no cursor should be displayed.", "")]
		[EditorSeparator]
		public AssetSource<GameObject> cursorObject = new AssetSource<GameObject>();

		[EditorHelp("Cursor Respawn", "Respawn the cursor each time it is placed.\n" +
			"Depending on your prefab (e.g. using particle effects) it might be " +
			"neccessary to spawn a new instance of your cursor prefab.\n" +
			"If disabled, ORK will reuse the spawned prefab instance while it's available (e.g. during movement).", "")]
		public bool cursorRespawn = false;

		[EditorHelp("Cursor Offset", "The offset added to the move target position for displaying the cursor.", "")]
		public Vector3 cursorOffset = Vector3.zero;

		[EditorHelp("Min. Move Distance", "The minimum distance to the move target the player must reach to stop moving.", "")]
		[EditorSeparator]
		[EditorLimit(0.1f, false)]
		public float minimumMoveDistance = 0.2f;

		[EditorHelp("Ignore Distance", "Enable the axes that will be ignored for the distance check.")]
		public AxisBool ignoreDistance = new AxisBool();

		[EditorHelp("Move Type", "Select how the player will be moved:\n" +
			"- Character Controller: Moves using a 'CharacterController' component.\n" +
			"- NavMesh Agent: Moves using a 'NavMeshAgent' component.\n" +
			"- Combatant Movement Component: Moves using the 'Movement Component' setup of the combatant.", "")]
		public MouseControlMoveType mouseMoveType = MouseControlMoveType.CharacterController;


		// nav mesh
		[EditorHelp("Sample Distance", "Maximum distance used to find the nearest point on the NavMesh to the clicked position.", "")]
		[EditorCondition("mouseMoveType", MouseControlMoveType.NavMeshAgent)]
		public float navMeshSampleDistance = 1.0f;

		[EditorHelp("Area Mask", "A mask specifying which NavMesh areas are allowed when finding the nearest point.\n" +
			"Defaults to all areas (-1).", "")]
		[EditorEndCondition]
		public int navMeshSampleAreaMask = NavMesh.AllAreas;


		// secure move
		[EditorHelp("Secure Move", "The movement will end if the player couldn't move for a defined amount of time.\n" +
			"If disabled, the player will move until it reached it's target.", "")]
		[EditorSeparator]
		public bool secureMove = false;

		[EditorHelp("Secure Time (s)", "The time in seconds the player mustn't move to stop the movement.", "")]
		[EditorCondition("secureMove", true)]
		[EditorEndCondition]
		[EditorLimit(0.1f, false)]
		public float secureTime = 0.5f;

		[EditorHelp("Remove Cursor No Control", "The cursor will automatically be removed when " +
			"control is not possible (e.g. when an interaction starts).", "")]
		public bool autoRemoveCursor = true;

		[EditorHelp("Remove Cursor Target", "The cursor will automatically be removed when " +
			"the target destination is reached (or movement stopped).", "")]
		public bool autoRemoveCursorTarget = true;

		[EditorHelp("Auto Stop Move", "The move will be stopped when e.g. an interaction starts.", "")]
		public bool autoStopMove = true;

		public MousePlayerControlSettings()
		{

		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			MousePlayerController comp = player.GetComponent<MousePlayerController>();
			if(comp == null)
			{
				comp = player.AddComponent<MousePlayerController>();
			}
			comp.settings.SetData(this.GetData());

			Maki.Control.AddPlayerControl(comp);
		}

		public void RemovePlayerControl(GameObject player)
		{
			MousePlayerController comp = player.GetComponent<MousePlayerController>();
			if(comp != null)
			{
				Maki.Control.RemovePlayerControl(comp);
				comp.ClearCursor();
				GameObject.Destroy(comp);
			}
		}
	}
}
