﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class MecanimAutoParameters : BaseData
	{
		// auto move speed
		// horizontal speed
		[EditorHelp("Set Horizontal Speed", "Set the horizontal speed of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		[EditorTitleLabel("Auto Move Speed Parameters")]
		public bool mSetAutoHorizontal = false;

		[EditorHelp("Horizontal Parameter", "The name of the float parameter used to set the horizontal movement speed of the combatant.", "")]
		[EditorIndent]
		[EditorWidth(true)]
		[EditorCondition("mSetAutoHorizontal", true)]
		public string mAutoHoriziontal = "";

		[EditorIndent]
		[EditorEndCondition]
		public MecanimFloatParameterDamping mDampHorizontal = new MecanimFloatParameterDamping();

		// vertical speed
		[EditorHelp("Set Vertical Speed", "Set the vertical speed of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		[EditorSeparator]
		public bool mSetAutoVertical = false;

		[EditorHelp("Vertical Parameter", "The name of the float parameter used to set the vertical movement speed of the combatant.", "")]
		[EditorIndent]
		[EditorWidth(true)]
		[EditorCondition("mSetAutoVertical", true)]
		public string mAutoVertical = "";

		[EditorIndent]
		[EditorEndCondition]
		public MecanimFloatParameterDamping mDampVertical = new MecanimFloatParameterDamping();


		// auto direction
		// x
		[EditorHelp("Set X Move Direction", "Set the X-axis movement direction of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Auto Move Direction Parameters")]
		public bool mSetXMoveDirection = false;

		[EditorHelp("X Move Direction", "The name of the float parameter used to set the X-axis movement direction of the combatant.", "")]
		[EditorIndent]
		[EditorWidth(true)]
		[EditorCondition("mSetXMoveDirection", true)]
		public string mXMoveDirection = "";

		[EditorIndent]
		[EditorEndCondition]
		public MecanimFloatParameterDamping mDampXMoveDirection = new MecanimFloatParameterDamping();

		// y
		[EditorHelp("Set Y Move Direction", "Set the Y-axis movement direction of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		[EditorSeparator]
		public bool mSetYMoveDirection = false;

		[EditorHelp("Y Move Direction", "The name of the float parameter used to set the Y-axis movement direction of the combatant.", "")]
		[EditorIndent]
		[EditorWidth(true)]
		[EditorCondition("mSetYMoveDirection", true)]
		public string mYMoveDirection = "";

		[EditorIndent]
		[EditorEndCondition]
		public MecanimFloatParameterDamping mDampYMoveDirection = new MecanimFloatParameterDamping();

		// z
		[EditorHelp("Set Z Move Direction", "Set the Z-axis movement direction of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		[EditorSeparator]
		public bool mSetZMoveDirection = false;

		[EditorHelp("Z Move Direction", "The name of the float parameter used to set the Z-axis movement direction of the combatant.", "")]
		[EditorIndent]
		[EditorWidth(true)]
		[EditorCondition("mSetZMoveDirection", true)]
		public string mZMoveDirection = "";

		[EditorIndent]
		[EditorEndCondition]
		public MecanimFloatParameterDamping mDampZMoveDirection = new MecanimFloatParameterDamping();


		// auto rotation
		// x
		[EditorHelp("Set X Rotation", "Set the X-axis rotation of the combatant to a parameter of the animator.\n" +
			"Requiers an int or float parameter and is set every Update call.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Auto Rotation Parameters")]
		public bool mSetXRotation = false;

		[EditorIndent]
		[EditorCondition("mSetXRotation", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MecanimAutoRotationParameter mXRotation;

		// y
		[EditorHelp("Set Y Rotation", "Set the Y-axis rotation of the combatant to a parameter of the animator.\n" +
			"Requiers an int or float parameter and is set every Update call.", "")]
		[EditorSeparator]
		public bool mSetYRotation = false;

		[EditorIndent]
		[EditorCondition("mSetYRotation", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MecanimAutoRotationParameter mYRotation;

		// z
		[EditorHelp("Set Z Rotation", "Set the Z-axis rotation of the combatant to a parameter of the animator.\n" +
			"Requiers an int or float parameter and is set every Update call.", "")]
		[EditorSeparator]
		public bool mSetZRotation = false;

		[EditorIndent]
		[EditorCondition("mSetZRotation", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MecanimAutoRotationParameter mZRotation;

		public MecanimAutoParameters()
		{

		}

		public void Init(ref MecanimFloatParameterSetter horizontalParameter, ref MecanimFloatParameterSetter verticalParameter,
			ref MecanimFloatParameterSetter xMoveDirectionParameter, ref MecanimFloatParameterSetter yMoveDirectionParameter, ref MecanimFloatParameterSetter zMoveDirectionParameter,
			ref MecanimAutoRotationParameter xParameter, ref MecanimAutoRotationParameter yParameter, ref MecanimAutoRotationParameter zParameter)
		{
			// auto move speed
			if(this.mSetAutoHorizontal && horizontalParameter == null)
			{
				horizontalParameter = new MecanimFloatParameterSetter(this.mAutoHoriziontal, this.mDampHorizontal);
			}
			if(this.mSetAutoVertical && verticalParameter == null)
			{
				verticalParameter = new MecanimFloatParameterSetter(this.mAutoVertical, this.mDampVertical);
			}
			// auto move direction
			if(this.mSetXMoveDirection && xMoveDirectionParameter == null)
			{
				xMoveDirectionParameter = new MecanimFloatParameterSetter(this.mXMoveDirection, this.mDampXMoveDirection);
			}
			if(this.mSetYMoveDirection && yMoveDirectionParameter == null)
			{
				yMoveDirectionParameter = new MecanimFloatParameterSetter(this.mYMoveDirection, this.mDampYMoveDirection);
			}
			if(this.mSetZMoveDirection && zMoveDirectionParameter == null)
			{
				zMoveDirectionParameter = new MecanimFloatParameterSetter(this.mZMoveDirection, this.mDampZMoveDirection);
			}
			// auto rotation
			if(this.mSetXRotation && xParameter == null)
			{
				xParameter = this.mXRotation;
			}
			if(this.mSetYRotation && yParameter == null)
			{
				yParameter = this.mYRotation;
			}
			if(this.mSetZRotation && zParameter == null)
			{
				zParameter = this.mZRotation;
			}
		}
	}
}
