﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Death", "The combatant must be dead/alive.")]
	public class DeathStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Dead", "The combatant must be dead.\n" +
			"If disabled, the combatant must be alive.", "")]
		public bool isDead = true;

		[EditorHelp("Combatant Scope", "Select the scope that will be checked:\n" +
			"- Current: The combatant that is checked.\n" +
			"- Battle: The members of the checked combatant's battle group.\n" +
			"- Group: All members of the checked combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the checked combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the checked combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the checked combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.\n\n" +
			"When checking the group or battle group, 'Is Dead' is valid if all members are dead, " +
			"not 'Is Dead' is valid if at least one member is still alive.", "")]
		public MenuCombatantScope deadScope = MenuCombatantScope.Current;

		public DeathStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.deadScope + (this.isDead ? " is dead" : " is alive");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(MenuCombatantScope.Current == this.deadScope)
			{
				return combatant.Status.IsDead == this.isDead;
			}
			else if(MenuCombatantScope.Battle == this.deadScope)
			{
				return combatant.Group.AllDeadBattle() == this.isDead;
			}
			else if(MenuCombatantScope.Group == this.deadScope ||
				MenuCombatantScope.GroupBattleSorted == this.deadScope)
			{
				return combatant.Group.AllDead() == this.isDead;
			}
			else if(MenuCombatantScope.NonBattle == this.deadScope)
			{
				return combatant.Group.AllDeadNonBattle() == this.isDead;
			}
			else if(MenuCombatantScope.BattleReserve == this.deadScope)
			{
				return combatant.Group.AllDeadBattleReserve() == this.isDead;
			}
			else if(MenuCombatantScope.NonBattleReserve == this.deadScope)
			{
				return combatant.Group.AllDeadNonBattleReserve() == this.isDead;
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.DeathStateChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.DeathStateChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.DeathStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.DeathStateChangedSimple -= notify;
		}
	}
}
