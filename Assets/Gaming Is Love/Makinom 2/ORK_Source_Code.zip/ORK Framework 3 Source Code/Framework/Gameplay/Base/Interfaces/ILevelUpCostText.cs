﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface ILevelUpCostText
	{
		string GetLevelUpCostString(Combatant combatant);
	}
}
