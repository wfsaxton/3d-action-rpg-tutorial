﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class ORKButtonContentLayout : ButtonContentLayout<ORKContentLayout>
	{
		public ORKButtonContentLayout()
		{

		}

		public ORKButtonContentLayout(string contentID, ORKContentLayoutType type)
		{
			this.additionalContent = new ContentID<ORKContentLayout>[]
			{
				new ContentID<ORKContentLayout>(contentID, new ORKContentLayout(type))
			};
		}

		public ORKButtonContentLayout(string[] contentID, ORKContentLayoutType[] type)
		{
			this.additionalContent = new ContentID<ORKContentLayout>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<ORKContentLayout>(contentID[i],
					new ORKContentLayout(i < type.Length ? type[i] : ORKContentLayoutType.TextAndIcon));
			}
		}

		public ORKButtonContentLayout(string contentID, string contentText)
		{
			this.additionalContent = new ContentID<ORKContentLayout>[]
			{
				new ContentID<ORKContentLayout>(contentID, new ORKContentLayout(contentText))
			};
		}

		public ORKButtonContentLayout(string[] contentID, string[] contentText)
		{
			this.additionalContent = new ContentID<ORKContentLayout>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<ORKContentLayout>(contentID[i],
					new ORKContentLayout(i < contentText.Length ? contentText[i] : ""));
			}
		}


		/*
		============================================================================
		Contains functions
		============================================================================
		*/
		public virtual bool Contains(string text)
		{
			if(this.mainContentLayout.Contains(text))
			{
				return true;
			}
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				if(this.additionalContent[i].content.Contains(text))
				{
					return true;
				}
			}
			return false;
		}

		public virtual bool ContainsReuseTime()
		{
			return this.Contains("<reuse");
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public virtual void UpdateContent(UIButtonInputContent button, IShortcut content, Combatant combatant, string info)
		{
			IContent typeContent = TypeContentHelper.Get(content);
			if(button.mainContent != null)
			{
				this.mainContentLayout.UpdateContent(button.mainContent, content, typeContent, combatant, info);
			}
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				UIText tmp = null;
				if(button.additionalContent == null ||
					!button.additionalContent.TryGetValue(this.additionalContent[i].contentID, out tmp))
				{
					tmp = new UIText(button.mainContent);
					button.AddAdditionalContent(this.additionalContent[i].contentID, tmp);
				}
				this.additionalContent[i].content.UpdateContent(tmp, content, typeContent, combatant, info);
			}
			this.customInput.Use(button);
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual UIButtonInputContent GetContentForObject(object content)
		{
			if(content is UIButtonInputContent)
			{
				return this.GetContent((UIButtonInputContent)content);
			}
			else if(content is IShortcut)
			{
				return this.GetContent((IShortcut)content, ORK.Game.ActiveGroup.Leader);
			}
			else if(content is Combatant)
			{
				return this.GetContent((Combatant)content);
			}
			else if(content is IContent)
			{
				return this.GetContent((IContent)content);
			}
			else if(content is GameObject)
			{
				return this.GetContent(((GameObject)content).name, null);
			}
			else if(content is Component)
			{
				return this.GetContent(((Component)content).name, null);
			}
			else if(content is string)
			{
				return this.GetContent((string)content, null);
			}
			return this.GetContent("");
		}

		public virtual UIButtonInputContent GetContent(string content)
		{
			return this.GetContent(content, null);
		}

		public virtual UIButtonInputContent GetContent(string content, object hudUser)
		{
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(content, hudUser));
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(content, hudUser));
			}
			return buttonInputContent;
		}

		public virtual UIButtonInputContent GetContent(IShortcut content, Combatant combatant)
		{
			return this.GetContent(content, combatant, content.GetDrag(combatant), CombatantContentHelper.Get(content, combatant));
		}

		public virtual UIButtonInputContent GetContent(IShortcut content, Combatant combatant, DragShortcutWrapper wrapper)
		{
			return this.GetContent(content, combatant, wrapper, CombatantContentHelper.Get(content, combatant));
		}

		public virtual UIButtonInputContent GetContent(IShortcut content, Combatant combatant, DragShortcutWrapper wrapper, string info)
		{
			IContent typeContent = TypeContentHelper.Get(content);
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(content, typeContent, combatant, wrapper, info),
				content.GetDescription());
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(content, typeContent, combatant, wrapper, info));
			}
			return buttonInputContent;
		}

		public virtual UIButtonInputContent GetContent(Combatant content)
		{
			IContent typeContent = TypeContentHelper.Get(content);
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(content, typeContent),
				content.GetDescription());
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(content, typeContent));
			}
			return buttonInputContent;
		}

		public virtual UIButtonInputContent GetContent(BestiaryEntry content)
		{
			IContent typeContent = TypeContentHelper.Get(content);
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(content, typeContent),
				content.GetDescription());
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(content, typeContent));
			}
			return buttonInputContent;
		}

		public virtual UIButtonInputContent GetContent(ResearchItem content, Combatant combatant)
		{
			IContent typeContent = TypeContentHelper.Get(content);
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(content, typeContent, combatant),
				content.GetDescription());
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(content, typeContent, combatant));
			}
			return buttonInputContent;
		}
	}
}
