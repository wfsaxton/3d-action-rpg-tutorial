﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Class Slot Equipped", "A defined class slot must or mustn't be available.")]
	public class ClassSlotEquippedStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Class Slot", "Select the class slot that will be check.", "")]
		public AssetSelection<ClassSlotAsset> classSlot = new AssetSelection<ClassSlotAsset>();

		[EditorHelp("Is Equipped", "The class slot must be have a class equipped.\n" +
			"If disabled, the class slot must be empty.", "")]
		public bool isEquipped = true;


		public ClassSlotEquippedStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.classSlot.ToString() + (this.isEquipped ? " is equipped" : " not equipped");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.classSlot.StoredAsset != null)
			{
				ClassSlot slot = combatant.Class.GetSlot(this.classSlot.StoredAsset.Settings);
				return slot != null && (slot.Equipped == this.isEquipped);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassSlotsChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassSlotsChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassSlotsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassSlotsChangedSimple -= notify;
		}
	}
}
